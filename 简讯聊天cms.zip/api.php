<?php
// 简讯APP API接口
// 关闭mysqli异常模式，兼容PHP 8+（必须在任何mysqli操作前执行）
mysqli_report(MYSQLI_REPORT_OFF);

// 开启输出缓冲，防止任何意外输出干扰JSON响应
ob_start();

// 关闭错误显示，确保JSON响应干净
ini_set('display_errors', 0);
error_reporting(0);

// 致命错误捕获 - 确保始终返回JSON
function _fatal_error_handler() {
    $error = error_get_last();
    if ($error && in_array($error['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR])) {
        if (ob_get_length()) ob_clean();
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['code' => 0, 'msg' => '服务器错误：' . $error['message'], 'data' => []], JSON_UNESCAPED_UNICODE);
        exit;
    }
}
register_shutdown_function('_fatal_error_handler');

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

require_once 'config.php';

// 兜底定义：确保上传相关常量存在（防止config加载异常）
if (!defined('UPLOAD_DIR')) define('UPLOAD_DIR', __DIR__ . '/uploads');
if (!defined('UPLOAD_URL')) define('UPLOAD_URL', 'uploads');
if (!defined('MAX_UPLOAD_SIZE')) define('MAX_UPLOAD_SIZE', 1000 * 1024 * 1024); // 默认1000MB
if (!defined('ALLOWED_IMAGE_TYPES')) define('ALLOWED_IMAGE_TYPES', ['jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp']);
if (!defined('ALLOWED_VIDEO_TYPES')) define('ALLOWED_VIDEO_TYPES', ['mp4', 'webm', 'mov', 'avi', 'mkv', 'flv']);

// 兜底定义：确保朋友圈表创建函数存在（防止config.php版本不一致）
if (!function_exists('ensure_moments_tables')) {
    function ensure_moments_tables() {
        try {
            $conn = @new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
            if ($conn->connect_error) return;
            $conn->set_charset("utf8mb4");
            $conn->query("CREATE TABLE IF NOT EXISTS moments (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_id INT NOT NULL COMMENT '发布者ID',
                content TEXT COMMENT '文字内容',
                images TEXT COMMENT '图片URL，JSON数组',
                likes TEXT DEFAULT NULL COMMENT '点赞用户ID，逗号分隔',
                comments_count INT DEFAULT 0 COMMENT '评论数',
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '发布时间',
                INDEX idx_user (user_id),
                INDEX idx_created (created_at)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='朋友圈动态'");
            $conn->query("CREATE TABLE IF NOT EXISTS moment_comments (
                id INT AUTO_INCREMENT PRIMARY KEY,
                moment_id INT NOT NULL COMMENT '动态ID',
                user_id INT NOT NULL COMMENT '评论者ID',
                content TEXT NOT NULL COMMENT '评论内容',
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                INDEX idx_moment (moment_id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='朋友圈评论'");
            $conn->close();
        } catch (Exception $e) {}
    }
}

if (!is_installed()) {
    json_response(-1, '请先安装程序', ['redirect' => 'install.php']);
}

$action = $_GET['action'] ?? $_POST['action'] ?? '';

function json_response($code, $msg, $data = []) {
    // 清除之前的所有输出，确保只返回JSON
    while (ob_get_level()) {
        ob_end_clean();
    }
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['code' => $code, 'msg' => $msg, 'data' => $data], JSON_UNESCAPED_UNICODE);
    exit;
}

function get_json_input() {
    $input = file_get_contents('php://input');
    return json_decode($input, true) ?: [];
}

// 检查登录中间件
function require_login() {
    if (!isset($_SESSION['user_id'])) {
        json_response(401, '请先登录');
    }
}

// 检查管理员中间件
function require_admin() {
    $conn = db_connect();
    $stmt = $conn->prepare("SELECT role FROM users WHERE id = ?");
    $stmt->bind_param("i", $_SESSION['user_id']);
    $stmt->execute();
    $result = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    $conn->close();
    if (!$result || $result['role'] != 1) {
        json_response(403, '无权限访问');
    }
}

switch ($action) {
    // ========== 认证相关 ==========
    case 'login':
        $input = get_json_input();
        $username = trim($input['username'] ?? '');
        $password = $input['password'] ?? '';
        
        if (empty($username) || empty($password)) {
            json_response(0, '请输入用户名和密码');
        }
        
        $conn = db_connect();
        $stmt = $conn->prepare("SELECT id, username, password, status FROM users WHERE username = ? OR email = ?");
        $stmt->bind_param("ss", $username, $username);
        $stmt->execute();
        $result = $stmt->get_result();
        $user = $result->fetch_assoc();
        $stmt->close();
        $conn->close();
        
        if (!$user) json_response(0, '用户不存在');
        if ($user['status'] != 1) json_response(0, '账号已被禁用');
        if (!password_verify($password, $user['password'])) json_response(0, '密码错误');
        
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $user['username'];
        json_response(1, '登录成功', ['redirect' => '#/home']);
        break;

    case 'register':
        $input = get_json_input();
        $username = trim($input['username'] ?? '');
        $nickname = trim($input['nickname'] ?? '');
        $email = trim($input['email'] ?? '');
        $password = $input['password'] ?? '';
        $confirm_password = $input['confirm_password'] ?? '';
        
        if (empty($username) || empty($password) || empty($email)) {
            json_response(0, '请填写所有必填项');
        }
        if (strlen($username) < 3 || strlen($username) > 20) {
            json_response(0, '用户名长度应为3-20个字符');
        }
        if (!preg_match('/^[a-zA-Z0-9_]+$/', $username)) {
            json_response(0, '用户名只能包含字母、数字和下划线');
        }
        if (strlen($password) < 6) json_response(0, '密码长度不能少于6位');
        if ($password !== $confirm_password) json_response(0, '两次密码不一致');
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) json_response(0, '邮箱格式不正确');
        
        $conn = db_connect();
        $stmt = $conn->prepare("SELECT id FROM users WHERE username = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        if ($stmt->get_result()->num_rows > 0) {
            $stmt->close();
            $conn->close();
            json_response(0, '用户名已被注册');
        }
        $stmt->close();
        
        $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        if ($stmt->get_result()->num_rows > 0) {
            $stmt->close();
            $conn->close();
            json_response(0, '邮箱已被注册');
        }
        $stmt->close();
        
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        $avatar = 'https://api.dicebear.com/7.x/thumbs/svg?seed=' . urlencode($username);
        if (empty($nickname)) $nickname = $username;
        
        $stmt = $conn->prepare("INSERT INTO users (username, nickname, email, password, avatar) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("sssss", $username, $nickname, $email, $hashed_password, $avatar);
        
        if ($stmt->execute()) {
            json_response(1, '注册成功，请登录');
        } else {
            json_response(0, '注册失败：' . $stmt->error);
        }
        $stmt->close();
        $conn->close();
        break;

    case 'logout':
        session_destroy();
        json_response(1, '已退出登录', ['redirect' => '#/login']);
        break;

    case 'check_login':
        if (isset($_SESSION['user_id'])) {
            $conn = db_connect();
            $stmt = $conn->prepare("SELECT id, username, nickname, avatar, email, signature, real_name, id_card, is_verified, role, moment_visible, allow_search, allow_add_friend, show_moment_in_discover FROM users WHERE id = ?");
            $stmt->bind_param("i", $_SESSION['user_id']);
            $stmt->execute();
            $result = $stmt->get_result();
            $user = $result->fetch_assoc();
            $stmt->close();
            $conn->close();
            // 身份证号脱敏显示
            if (!empty($user['id_card']) && strlen($user['id_card']) == 18) {
                $user['id_card_masked'] = substr($user['id_card'], 0, 6) . '********' . substr($user['id_card'], -4);
            } else {
                $user['id_card_masked'] = '';
            }
            json_response(1, '已登录', ['user' => $user]);
        } else {
            json_response(0, '未登录');
        }
        break;

    case 'forgot_password':
        $input = get_json_input();
        $email = trim($input['email'] ?? '');
        if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            json_response(0, '请输入正确的邮箱');
        }
        $conn = db_connect();
        $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        if ($stmt->get_result()->num_rows == 0) {
            $stmt->close();
            $conn->close();
            json_response(0, '该邮箱未注册');
        }
        $stmt->close();
        // 简化版：直接返回重置码（实际项目应发送邮件）
        $token = substr(md5(time() . $email), 0, 8);
        $expires = date('Y-m-d H:i:s', time() + 3600);
        $stmt = $conn->prepare("INSERT INTO password_resets (email, token, expires_at) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $email, $token, $expires);
        $stmt->execute();
        $stmt->close();
        $conn->close();
        json_response(1, '重置码已生成（演示模式）', ['token' => $token]);
        break;

    case 'reset_password':
        $input = get_json_input();
        $email = trim($input['email'] ?? '');
        $token = trim($input['token'] ?? '');
        $new_password = $input['new_password'] ?? '';
        
        if (strlen($new_password) < 6) json_response(0, '密码长度不能少于6位');
        
        $conn = db_connect();
        $stmt = $conn->prepare("SELECT id FROM password_resets WHERE email = ? AND token = ? AND expires_at > NOW() ORDER BY id DESC LIMIT 1");
        $stmt->bind_param("ss", $email, $token);
        $stmt->execute();
        if ($stmt->get_result()->num_rows == 0) {
            $stmt->close();
            $conn->close();
            json_response(0, '重置码无效或已过期');
        }
        $stmt->close();
        
        $hashed = password_hash($new_password, PASSWORD_DEFAULT);
        $stmt = $conn->prepare("UPDATE users SET password = ? WHERE email = ?");
        $stmt->bind_param("ss", $hashed, $email);
        $stmt->execute();
        $stmt->close();
        $conn->close();
        json_response(1, '密码重置成功，请登录');
        break;

    // ========== 用户相关 ==========
    case 'user_info':
        require_login();
        $conn = db_connect();
        $stmt = $conn->prepare("SELECT id, username, nickname, avatar, email, signature, real_name, id_card, is_verified, role, created_at FROM users WHERE id = ?");
        $stmt->bind_param("i", $_SESSION['user_id']);
        $stmt->execute();
        $user = $stmt->get_result()->fetch_assoc();
        // 身份证号脱敏显示
        if (!empty($user['id_card']) && strlen($user['id_card']) == 18) {
            $user['id_card_masked'] = substr($user['id_card'], 0, 6) . '********' . substr($user['id_card'], -4);
        } else {
            $user['id_card_masked'] = '';
        }
        $stmt->close();
        $conn->close();
        json_response(1, 'success', ['user' => $user]);
        break;

    case 'update_profile':
        require_login();
        $input = get_json_input();
        $nickname = trim($input['nickname'] ?? '');
        $signature = trim($input['signature'] ?? '');
        $avatar = trim($input['avatar'] ?? '');
        $old_password = $input['old_password'] ?? '';
        $new_password = $input['new_password'] ?? '';
        
        $conn = db_connect();
        
        // 如果要修改密码，先验证旧密码
        if (!empty($new_password)) {
            if (empty($old_password)) {
                $conn->close();
                json_response(0, '请输入旧密码');
            }
            $stmt = $conn->prepare("SELECT password FROM users WHERE id = ?");
            $stmt->bind_param("i", $_SESSION['user_id']);
            $stmt->execute();
            $result = $stmt->get_result()->fetch_assoc();
            $stmt->close();
            if (!$result || !password_verify($old_password, $result['password'])) {
                $conn->close();
                json_response(0, '旧密码错误');
            }
            if (strlen($new_password) < 6) {
                $conn->close();
                json_response(0, '新密码长度不能少于6位');
            }
        }
        
        $fields = [];
        $params = [];
        $types = '';
        if ($nickname !== '') { $fields[] = 'nickname=?'; $params[] = $nickname; $types .= 's'; }
        if ($signature !== '') { $fields[] = 'signature=?'; $params[] = $signature; $types .= 's'; }
        if ($avatar !== '') { $fields[] = 'avatar=?'; $params[] = $avatar; $types .= 's'; }
        if (!empty($new_password)) {
            $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
            $fields[] = 'password=?';
            $params[] = $hashed_password;
            $types .= 's';
        }
        
        if (empty($fields)) {
            $conn->close();
            json_response(0, '没有要更新的内容');
        }
        
        $params[] = $_SESSION['user_id'];
        $types .= 'i';
        $sql = "UPDATE users SET " . implode(',', $fields) . " WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param($types, ...$params);
        $result = $stmt->execute();
        $stmt->close();
        $conn->close();
        json_response($result ? 1 : 0, $result ? '更新成功' : '更新失败');
        break;

    // 实名认证
    case 'verify_identity':
        require_login();
        $input = get_json_input();
        $real_name = trim($input['real_name'] ?? '');
        $id_card = trim($input['id_card'] ?? '');
        
        if (empty($real_name)) json_response(0, '请输入真实姓名');
        if (empty($id_card)) json_response(0, '请输入身份证号');
        if (mb_strlen($real_name) < 2) json_response(0, '真实姓名至少2个字符');
        
        // 简单身份证格式校验（18位）
        if (!preg_match('/^[1-9]\d{5}(18|19|20)\d{2}(0[1-9]|1[0-2])(0[1-9]|[12]\d|3[01])\d{3}[\dXx]$/', $id_card)) {
            json_response(0, '身份证号格式不正确');
        }
        
        $conn = db_connect();
        
        // 检查是否已认证
        $stmt = $conn->prepare("SELECT is_verified FROM users WHERE id = ?");
        $stmt->bind_param("i", $_SESSION['user_id']);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        
        if ($result && $result['is_verified'] == 1) {
            $conn->close();
            json_response(0, '您已完成实名认证，不可重复认证');
        }
        
        // 检查身份证是否已被使用
        $stmt = $conn->prepare("SELECT id FROM users WHERE id_card = ? AND id != ?");
        $stmt->bind_param("si", $id_card, $_SESSION['user_id']);
        $stmt->execute();
        $stmt->store_result();
        if ($stmt->num_rows > 0) {
            $stmt->close();
            $conn->close();
            json_response(0, '该身份证号已被其他账号绑定');
        }
        $stmt->close();
        
        // 更新实名认证信息
        $stmt = $conn->prepare("UPDATE users SET real_name = ?, id_card = ?, is_verified = 1 WHERE id = ?");
        $stmt->bind_param("ssi", $real_name, $id_card, $_SESSION['user_id']);
        $result = $stmt->execute();
        $stmt->close();
        $conn->close();
        
        json_response($result ? 1 : 0, $result ? '实名认证成功' : '实名认证失败');
        break;

    // ========== 管理后台 ==========
    // 检查是否管理员
    case 'check_admin':
        require_login();
        $conn = db_connect();
        $stmt = $conn->prepare("SELECT role FROM users WHERE id = ?");
        $stmt->bind_param("i", $_SESSION['user_id']);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        $conn->close();
        $is_admin = $result && $result['role'] == 1;
        json_response($is_admin ? 1 : 0, $is_admin ? '是管理员' : '普通用户', ['is_admin' => $is_admin]);
        break;

    // 管理后台统计数据
    case 'admin_stats':
        require_login();
        require_admin();
        $conn = db_connect();
        
        // 用户总数
        $result = $conn->query("SELECT COUNT(*) as total FROM users");
        $total_users = $result->fetch_assoc()['total'];
        
        // 今日新增用户
        $result = $conn->query("SELECT COUNT(*) as today FROM users WHERE DATE(created_at) = CURDATE()");
        $today_users = $result->fetch_assoc()['today'];
        
        // 已认证用户
        $result = $conn->query("SELECT COUNT(*) as verified FROM users WHERE is_verified = 1");
        $verified_users = $result->fetch_assoc()['verified'];
        
        // 禁用用户
        $result = $conn->query("SELECT COUNT(*) as banned FROM users WHERE status = 0");
        $banned_users = $result->fetch_assoc()['banned'];
        
        // 消息总数
        $result = $conn->query("SELECT COUNT(*) as total FROM messages");
        $total_messages = $result->fetch_assoc()['total'];
        
        // 今日消息
        $result = $conn->query("SELECT COUNT(*) as today FROM messages WHERE DATE(created_at) = CURDATE()");
        $today_messages = $result->fetch_assoc()['today'];
        
        // 好友关系总数
        $result = $conn->query("SELECT COUNT(*) as total FROM friends WHERE status = 1");
        $total_friends = $result->fetch_assoc()['total'];
        
        $conn->close();
        
        json_response(1, 'success', [
            'total_users' => $total_users,
            'today_users' => $today_users,
            'verified_users' => $verified_users,
            'banned_users' => $banned_users,
            'total_messages' => $total_messages,
            'today_messages' => $today_messages,
            'total_friends' => $total_friends
        ]);
        break;

    // 用户列表
    case 'admin_user_list':
        require_login();
        require_admin();
        $conn = db_connect();
        
        $page = max(1, (int)($_GET['page'] ?? 1));
        $page_size = 20;
        $offset = ($page - 1) * $page_size;
        $keyword = trim($_GET['keyword'] ?? '');
        
        $where = '';
        $params = [];
        $types = '';
        if ($keyword) {
            $where = "WHERE username LIKE ? OR nickname LIKE ? OR email LIKE ?";
            $kw = '%' . $keyword . '%';
            $params = [$kw, $kw, $kw];
            $types = 'sss';
        }
        
        // 总数
        $count_sql = "SELECT COUNT(*) as total FROM users " . $where;
        $stmt = $conn->prepare($count_sql);
        if ($params) $stmt->bind_param($types, ...$params);
        $stmt->execute();
        $total = $stmt->get_result()->fetch_assoc()['total'];
        $stmt->close();
        
        // 列表
        $sql = "SELECT id, username, nickname, avatar, email, signature, real_name, is_verified, role, status, created_at 
                FROM users " . $where . " ORDER BY id DESC LIMIT ? OFFSET ?";
        $stmt = $conn->prepare($sql);
        $all_params = array_merge($params, [$page_size, $offset]);
        $all_types = $types . 'ii';
        $stmt->bind_param($all_types, ...$all_params);
        $stmt->execute();
        $result = $stmt->get_result();
        $users = [];
        while ($row = $result->fetch_assoc()) {
            $users[] = $row;
        }
        $stmt->close();
        $conn->close();
        
        json_response(1, 'success', [
            'list' => $users,
            'total' => $total,
            'page' => $page,
            'page_size' => $page_size,
            'total_pages' => ceil($total / $page_size)
        ]);
        break;

    // 禁用/启用用户
    case 'admin_toggle_user':
        require_login();
        require_admin();
        $input = get_json_input();
        $user_id = (int)($input['user_id'] ?? 0);
        
        if (!$user_id) json_response(0, '用户ID不能为空');
        if ($user_id == $_SESSION['user_id']) json_response(0, '不能操作自己');
        
        $conn = db_connect();
        
        // 获取当前状态
        $stmt = $conn->prepare("SELECT status, role FROM users WHERE id = ?");
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $user = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        
        if (!$user) {
            $conn->close();
            json_response(0, '用户不存在');
        }
        if ($user['role'] == 1) {
            $conn->close();
            json_response(0, '不能操作管理员账号');
        }
        
        $new_status = $user['status'] == 1 ? 0 : 1;
        $stmt = $conn->prepare("UPDATE users SET status = ? WHERE id = ?");
        $stmt->bind_param("ii", $new_status, $user_id);
        $result = $stmt->execute();
        $stmt->close();
        $conn->close();
        
        json_response($result ? 1 : 0, $result ? ($new_status == 1 ? '已启用' : '已禁用') : '操作失败');
        break;

    // 重置用户密码
    case 'admin_reset_password':
        require_login();
        require_admin();
        $input = get_json_input();
        $user_id = (int)($input['user_id'] ?? 0);
        $new_password = $input['new_password'] ?? '123456';
        
        if (!$user_id) json_response(0, '用户ID不能为空');
        if (strlen($new_password) < 6) json_response(0, '密码长度不能少于6位');
        if ($user_id == $_SESSION['user_id']) json_response(0, '请在个人设置中修改自己的密码');
        
        $conn = db_connect();
        
        // 检查是否是管理员
        $stmt = $conn->prepare("SELECT role FROM users WHERE id = ?");
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $user = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        
        if ($user && $user['role'] == 1) {
            $conn->close();
            json_response(0, '不能操作管理员账号');
        }
        
        $hashed = password_hash($new_password, PASSWORD_DEFAULT);
        $stmt = $conn->prepare("UPDATE users SET password = ? WHERE id = ?");
        $stmt->bind_param("si", $hashed, $user_id);
        $result = $stmt->execute();
        $stmt->close();
        $conn->close();
        
        json_response($result ? 1 : 0, $result ? '密码重置成功' : '重置失败');
        break;

    // 设置/取消管理员
    case 'admin_set_role':
        require_login();
        require_admin();
        $input = get_json_input();
        $user_id = (int)($input['user_id'] ?? 0);
        $role = (int)($input['role'] ?? 0);
        
        if (!$user_id) json_response(0, '用户ID不能为空');
        if ($user_id == $_SESSION['user_id']) json_response(0, '不能修改自己的角色');
        if (!in_array($role, [0, 1])) json_response(0, '无效的角色');
        
        $conn = db_connect();
        $stmt = $conn->prepare("UPDATE users SET role = ? WHERE id = ?");
        $stmt->bind_param("ii", $role, $user_id);
        $result = $stmt->execute();
        $stmt->close();
        $conn->close();
        
        json_response($result ? 1 : 0, $result ? ($role == 1 ? '已设为管理员' : '已取消管理员') : '操作失败');
        break;

    // 删除用户（删除所有数据和文件）
    case 'admin_delete_user':
        require_login();
        require_admin();
        $input = get_json_input();
        $user_id = (int)($input['user_id'] ?? 0);
        
        if (!$user_id) json_response(0, '用户ID不能为空');
        if ($user_id == $_SESSION['user_id']) json_response(0, '不能删除自己');
        
        $conn = db_connect();
        
        // 检查是否是管理员
        $stmt = $conn->prepare("SELECT role, avatar FROM users WHERE id = ?");
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $user = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        
        if (!$user) {
            $conn->close();
            json_response(0, '用户不存在');
        }
        if ($user['role'] == 1) {
            $conn->close();
            json_response(0, '不能删除管理员账号');
        }
        
        // 收集需要删除的文件路径
        $files_to_delete = [];
        
        // 删除用户头像
        if (!empty($user['avatar'])) {
            $avatar_path = UPLOAD_DIR . '/' . ltrim(parse_url($user['avatar'], PHP_URL_PATH), '/');
            // 如果是相对路径，直接拼接
            if (strpos($user['avatar'], UPLOAD_URL) === 0) {
                $avatar_path = UPLOAD_DIR . '/' . substr($user['avatar'], strlen(UPLOAD_URL) + 1);
            }
            if (file_exists($avatar_path) && is_file($avatar_path)) {
                $files_to_delete[] = $avatar_path;
            }
        }
        
        // 查找用户所有消息中的媒体文件
        $stmt = $conn->prepare("SELECT content, type FROM messages WHERE from_user_id = ? OR to_user_id = ?");
        $stmt->bind_param("ii", $user_id, $user_id);
        $stmt->execute();
        $result = $stmt->get_result();
        while ($row = $result->fetch_assoc()) {
            if ($row['type'] == 2 || $row['type'] == 3) {
                $file_path = $row['content'];
                if (strpos($file_path, UPLOAD_URL) === 0) {
                    $full_path = UPLOAD_DIR . '/' . substr($file_path, strlen(UPLOAD_URL) + 1);
                    if (file_exists($full_path) && is_file($full_path)) {
                        $files_to_delete[] = $full_path;
                    }
                }
            }
        }
        $stmt->close();
        
        // 删除文件
        foreach ($files_to_delete as $file) {
            @unlink($file);
        }
        
        // 删除聊天记录
        $conn->query("DELETE FROM messages WHERE from_user_id = {$user_id} OR to_user_id = {$user_id}");
        
        // 删除好友关系
        $conn->query("DELETE FROM friends WHERE user_id = {$user_id} OR friend_id = {$user_id}");
        
        // 删除密码重置记录
        $conn->query("DELETE FROM password_resets WHERE email = (SELECT email FROM users WHERE id = {$user_id})");
        
        // 删除用户
        $stmt = $conn->prepare("DELETE FROM users WHERE id = ?");
        $stmt->bind_param("i", $user_id);
        $result = $stmt->execute();
        $stmt->close();
        $conn->close();
        
        json_response($result ? 1 : 0, $result ? '用户已删除' : '删除失败');
        break;

    // 用户详情（管理员查看）
    case 'admin_user_detail':
        require_login();
        require_admin();
        $target_id = (int)($_GET['user_id'] ?? 0);
        if (!$target_id) json_response(0, '用户ID不能为空');

        $conn = db_connect();

        // 基本信息
        $stmt = $conn->prepare("SELECT id, username, nickname, avatar, email, signature,
            real_name, id_card, is_verified, role, status,
            moment_visible, allow_search, allow_add_friend, show_moment_in_discover,
            created_at FROM users WHERE id = ?");
        $stmt->bind_param("i", $target_id);
        $stmt->execute();
        $userInfo = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if (!$userInfo) {
            $conn->close();
            json_response(0, '用户不存在');
        }

        // 管理员查看详情：身份证号完整显示（不脱敏）

        // 好友数
        $friendCount = 0;
        $r = $conn->query("SELECT COUNT(*) as cnt FROM friends WHERE (user_id = {$target_id} OR friend_id = {$target_id}) AND status = 1");
        if ($r) $friendCount = (int)$r->fetch_assoc()['cnt'];

        // 消息数（发送+接收）
        $msgCount = 0;
        $r = $conn->query("SELECT COUNT(*) as cnt FROM messages WHERE from_user_id = {$target_id} OR to_user_id = {$target_id}");
        if ($r) $msgCount = (int)$r->fetch_assoc()['cnt'];

        // 朋友圈动态
        $moments = [];
        ensure_moments_tables();
        $stmt = $conn->prepare("SELECT id, content, images, likes, created_at FROM moments WHERE user_id = ? ORDER BY id DESC LIMIT 50");
        $stmt->bind_param("i", $target_id);
        $stmt->execute();
        $resM = $stmt->get_result();
        while ($row = $resM->fetch_assoc()) {
            $row['images'] = $row['images'] ? json_decode($row['images'], true) : [];
            $likeArr = $row['likes'] ? explode(',', $row['likes']) : [];
            $row['like_count'] = count($likeArr);
            unset($row['likes']);
            // 评论数
            $mid = (int)$row['id'];
            $rc = $conn->query("SELECT COUNT(*) as cnt FROM moment_comments WHERE moment_id = {$mid}");
            $row['comment_count'] = $rc ? (int)$rc->fetch_assoc()['cnt'] : 0;
            $moments[] = $row;
        }
        $stmt->close();

        $conn->close();

        json_response(1, 'success', [
            'user' => $userInfo,
            'friend_count' => $friendCount,
            'msg_count' => $msgCount,
            'moment_count' => count($moments),
            'moments' => $moments
        ]);
        break;

    // ========== 聊天相关 ==========
    case 'chat_list':
        require_login();
        $user_id = $_SESSION['user_id'];
        $conn = db_connect();
        
        // 获取最近会话列表
        $sql = "SELECT 
            u.id as friend_id, u.nickname, u.avatar,
            m.content as last_msg, m.created_at as last_time, m.from_user_id, m.type,
            (SELECT COUNT(*) FROM messages WHERE to_user_id = ? AND from_user_id = u.id AND is_read = 0) as unread
        FROM users u
        INNER JOIN messages m ON 
            (m.from_user_id = u.id AND m.to_user_id = ?) OR 
            (m.from_user_id = ? AND m.to_user_id = u.id)
        WHERE m.id = (
            SELECT MAX(id) FROM messages 
            WHERE (from_user_id = u.id AND to_user_id = ?) OR (from_user_id = ? AND to_user_id = u.id)
        )
        ORDER BY m.id DESC";
        
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("iiiii", $user_id, $user_id, $user_id, $user_id, $user_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $chats = [];
        while ($row = $result->fetch_assoc()) {
            // 处理消息类型显示
            if ($row['type'] == 2) {
                $row['last_msg'] = '[图片]';
            } elseif ($row['type'] == 3) {
                $row['last_msg'] = '[视频]';
            }
            $chats[] = $row;
        }
        $stmt->close();
        $conn->close();
        json_response(1, 'success', ['chats' => $chats]);
        break;

    case 'get_messages':
        require_login();
        $input = get_json_input();
        $friend_id = (int)($input['friend_id'] ?? 0);
        $user_id = $_SESSION['user_id'];
        
        if (!$friend_id) json_response(0, '参数错误');
        
        $conn = db_connect();
        // 标记为已读
        $conn->query("UPDATE messages SET is_read = 1 WHERE from_user_id = {$friend_id} AND to_user_id = {$user_id}");
        
        $stmt = $conn->prepare("SELECT id, from_user_id, to_user_id, content, type, file_name, file_size, created_at, is_read 
            FROM messages 
            WHERE (from_user_id = ? AND to_user_id = ?) OR (from_user_id = ? AND to_user_id = ?)
            ORDER BY id DESC LIMIT 50");
        $stmt->bind_param("iiii", $user_id, $friend_id, $friend_id, $user_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $messages = [];
        while ($row = $result->fetch_assoc()) {
            // 图片和视频消息的content是相对路径，转换为完整URL
            if ($row['type'] == 2 || $row['type'] == 3) {
                $row['content'] = UPLOAD_URL . '/' . $row['content'];
            }
            array_unshift($messages, $row);
        }
        $stmt->close();
        
        // 获取好友信息
        $stmt = $conn->prepare("SELECT id, nickname, avatar, signature FROM users WHERE id = ?");
        $stmt->bind_param("i", $friend_id);
        $stmt->execute();
        $friend = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        $conn->close();
        
        json_response(1, 'success', ['messages' => $messages, 'friend' => $friend]);
        break;

    case 'send_message':
        require_login();
        $input = get_json_input();
        $to_user_id = (int)($input['to_user_id'] ?? 0);
        $content = trim($input['content'] ?? '');
        $type = (int)($input['type'] ?? 1);
        $file_name = $input['file_name'] ?? null;
        $file_size = (int)($input['file_size'] ?? 0);
        $user_id = $_SESSION['user_id'];
        
        if (!$to_user_id || empty($content)) json_response(0, '参数错误');
        if ($to_user_id == $user_id) json_response(0, '不能给自己发消息');
        
        $conn = db_connect();
        $stmt = $conn->prepare("INSERT INTO messages (from_user_id, to_user_id, content, type, file_name, file_size) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("iisisi", $user_id, $to_user_id, $content, $type, $file_name, $file_size);
        $result = $stmt->execute();
        $msg_id = $stmt->insert_id;
        $stmt->close();
        $conn->close();
        
        if ($result) {
            json_response(1, '发送成功', ['msg_id' => $msg_id, 'time' => date('Y-m-d H:i:s')]);
        } else {
            json_response(0, '发送失败');
        }
        break;

    case 'upload_file':
        try {
            // 上传可能需要较长时间，取消时间限制
            @set_time_limit(0);
            @ini_set('memory_limit', '256M');
            
            require_login();
            $user_id = (int)$_SESSION['user_id'];
            $type = isset($_GET['file_type']) ? $_GET['file_type'] : 'image';
            
            // 释放session锁，防止上传过程中阻塞其他请求
            session_write_close();
            
            // 检查是否有文件上传
            if (empty($_FILES) && $_SERVER['REQUEST_METHOD'] === 'POST') {
                $post_max = ini_get('post_max_size');
                json_response(0, '文件过大，超过服务器 post_max_size 限制（当前限制：' . $post_max . '），请修改 php.ini 后重试');
            }
            
            if (!isset($_FILES['file'])) {
                json_response(0, '请选择要上传的文件');
            }
            
            $file = $_FILES['file'];
            
            // 检查上传错误
            $upload_errors = [
                UPLOAD_ERR_INI_SIZE => '文件大小超过服务器限制（php.ini upload_max_filesize）',
                UPLOAD_ERR_FORM_SIZE => '文件大小超过表单限制',
                UPLOAD_ERR_PARTIAL => '文件只有部分被上传',
                UPLOAD_ERR_NO_FILE => '没有文件被上传',
                UPLOAD_ERR_NO_TMP_DIR => '找不到临时文件夹',
                UPLOAD_ERR_CANT_WRITE => '文件写入失败',
                UPLOAD_ERR_EXTENSION => 'PHP扩展停止了文件上传',
            ];
            
            if ($file['error'] !== UPLOAD_ERR_OK) {
                $err_msg = isset($upload_errors[$file['error']]) 
                    ? $upload_errors[$file['error']] 
                    : '上传错误，错误码：' . $file['error'];
                json_response(0, $err_msg);
            }
            
            // 检查文件大小
            if ($file['size'] > MAX_UPLOAD_SIZE) {
                json_response(0, '文件大小不能超过' . round(MAX_UPLOAD_SIZE / 1024 / 1024) . 'MB');
            }
            
            if ($file['size'] == 0) {
                json_response(0, '文件为空');
            }
            
            // 获取文件扩展名
            $file_name_raw = isset($file['name']) ? $file['name'] : '';
            $ext = strtolower(pathinfo($file_name_raw, PATHINFO_EXTENSION));
            
            if (empty($ext)) {
                json_response(0, '无法识别文件类型');
            }
            
            // 验证文件类型
            $msg_type = 0;
            if ($type === 'image') {
                if (!in_array($ext, ALLOWED_IMAGE_TYPES)) {
                    json_response(0, '不支持的图片格式，支持：' . implode(', ', ALLOWED_IMAGE_TYPES));
                }
                $msg_type = 2;
            } elseif ($type === 'video') {
                if (!in_array($ext, ALLOWED_VIDEO_TYPES)) {
                    json_response(0, '不支持的视频格式，支持：' . implode(', ', ALLOWED_VIDEO_TYPES));
                }
                $msg_type = 3;
            } else {
                json_response(0, '无效的文件类型参数');
            }
            
            // 创建上传目录（按日期分子目录）
            $sub_dir = date('Ymd');
            $upload_path = UPLOAD_DIR . DIRECTORY_SEPARATOR . $sub_dir;
            if (!is_dir($upload_path)) {
                if (!@mkdir($upload_path, 0755, true)) {
                    json_response(0, '上传目录创建失败，请检查 ' . UPLOAD_DIR . ' 目录权限');
                }
            }
            if (!is_writable($upload_path)) {
                json_response(0, '上传目录不可写，请检查目录权限');
            }
            
            // 生成唯一文件名
            $new_file_name = uniqid() . '_' . time() . '.' . $ext;
            $dest_path = $upload_path . DIRECTORY_SEPARATOR . $new_file_name;
            $relative_path = $sub_dir . '/' . $new_file_name;
            $file_url = UPLOAD_URL . '/' . $relative_path;
            
            // 移动上传文件
            if (@move_uploaded_file($file['tmp_name'], $dest_path)) {
                @chmod($dest_path, 0644);
                json_response(1, '上传成功', [
                    'url' => $file_url,
                    'path' => $relative_path,
                    'name' => $file_name_raw,
                    'size' => $file['size'],
                    'type' => $msg_type,
                    'ext' => $ext
                ]);
            } else {
                json_response(0, '文件保存失败，请检查服务器配置');
            }
        } catch (Throwable $e) {
            json_response(0, '上传异常：' . $e->getMessage());
        }
        break;

    // ========== 好友/联系人 ==========
    case 'friend_list':
        require_login();
        $user_id = $_SESSION['user_id'];
        $conn = db_connect();
        $stmt = $conn->prepare("SELECT u.id, u.username, u.nickname, u.avatar, u.signature, f.remark 
            FROM friends f 
            JOIN users u ON f.friend_id = u.id 
            WHERE f.user_id = ? AND f.status = 1
            ORDER BY u.nickname");
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $friends = [];
        while ($row = $result->fetch_assoc()) {
            $friends[] = $row;
        }
        $stmt->close();
        $conn->close();
        json_response(1, 'success', ['friends' => $friends]);
        break;

    case 'search_user':
        require_login();
        $keyword = trim($_GET['keyword'] ?? '');
        if (empty($keyword)) json_response(0, '请输入搜索关键词');
        
        $conn = db_connect();
        // 只搜索允许被搜索的用户
        $stmt = $conn->prepare("SELECT id, username, nickname, avatar, signature FROM users 
            WHERE (username LIKE ? OR nickname LIKE ?) AND allow_search = 1 LIMIT 20");
        $kw = "%{$keyword}%";
        $stmt->bind_param("ss", $kw, $kw);
        $stmt->execute();
        $result = $stmt->get_result();
        $users = [];
        while ($row = $result->fetch_assoc()) {
            if ($row['id'] != $_SESSION['user_id']) $users[] = $row;
        }
        $stmt->close();
        $conn->close();
        json_response(1, 'success', ['users' => $users]);
        break;

    case 'add_friend':
        require_login();
        $input = get_json_input();
        $friend_id = (int)($input['friend_id'] ?? 0);
        $user_id = $_SESSION['user_id'];
        if (!$friend_id) json_response(0, '参数错误');
        if ($friend_id == $user_id) json_response(0, '不能添加自己');
        
        $conn = db_connect();
        // 检查对方是否允许被添加好友
        $stmt = $conn->prepare("SELECT allow_add_friend FROM users WHERE id = ?");
        $stmt->bind_param("i", $friend_id);
        $stmt->execute();
        $targetUser = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        if ($targetUser && $targetUser['allow_add_friend'] == 0) {
            $conn->close();
            json_response(0, '对方已关闭好友添加');
        }
        
        // 检查是否已是好友
        $stmt = $conn->prepare("SELECT id, status FROM friends WHERE 
            (user_id = ? AND friend_id = ?) OR (user_id = ? AND friend_id = ?)");
        $stmt->bind_param("iiii", $user_id, $friend_id, $friend_id, $user_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $existing = null;
        while ($row = $result->fetch_assoc()) {
            if ($row['status'] == 1) { $existing = $row; break; }
            if ($row['user_id'] == $user_id && $row['status'] == 0) { $existing = $row; }
        }
        $stmt->close();
        
        if ($existing) {
            if ($existing['status'] == 1) json_response(0, '已经是好友了');
            json_response(0, '已发送过好友申请');
        }
        
        // 只插入一条申请记录（发起方 → 接收方）
        $stmt = $conn->prepare("INSERT INTO friends (user_id, friend_id, status) VALUES (?, ?, 0)");
        $stmt->bind_param("ii", $user_id, $friend_id);
        $stmt->execute();
        $stmt->close();
        $conn->close();
        json_response(1, '好友申请已发送');
        break;

    case 'friend_requests':
        require_login();
        $user_id = $_SESSION['user_id'];
        $conn = db_connect();
        // 获取收到的好友申请（status=0 且对方是发起方）
        $stmt = $conn->prepare("SELECT f.id, f.user_id as from_id, f.created_at, 
            u.nickname, u.avatar, u.signature
            FROM friends f 
            JOIN users u ON f.user_id = u.id 
            WHERE f.friend_id = ? AND f.status = 0
            ORDER BY f.id DESC");
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $requests = [];
        while ($row = $result->fetch_assoc()) {
            $requests[] = $row;
        }
        $stmt->close();
        $conn->close();
        json_response(1, 'success', ['requests' => $requests, 'count' => count($requests)]);
        break;

    case 'handle_friend_request':
        require_login();
        $input = get_json_input();
        $request_id = (int)($input['request_id'] ?? 0);
        $action = $input['action'] ?? ''; // accept / reject
        $user_id = $_SESSION['user_id'];
        
        if (!$request_id || !in_array($action, ['accept', 'reject'])) {
            json_response(0, '参数错误');
        }
        
        $conn = db_connect();
        // 验证申请
        $stmt = $conn->prepare("SELECT id, user_id, friend_id, status FROM friends WHERE id = ? AND friend_id = ?");
        $stmt->bind_param("ii", $request_id, $user_id);
        $stmt->execute();
        $request = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        
        if (!$request) json_response(0, '申请不存在');
        if ($request['status'] != 0) json_response(0, '申请已处理');
        
        $new_status = $action === 'accept' ? 1 : 2;
        $from_id = $request['user_id'];
        
        // 更新自己这边的记录
        $stmt = $conn->prepare("UPDATE friends SET status = ? WHERE id = ?");
        $stmt->bind_param("ii", $new_status, $request_id);
        $stmt->execute();
        $stmt->close();
        
        if ($action === 'accept') {
            // 如果接受，插入反向好友关系（接收方 → 发起方）
            $stmt = $conn->prepare("INSERT INTO friends (user_id, friend_id, status) VALUES (?, ?, 1)");
            $stmt->bind_param("ii", $user_id, $from_id);
            $stmt->execute();
            $stmt->close();
        }
        
        $conn->close();
        json_response(1, $action === 'accept' ? '已接受' : '已拒绝');
        break;

    case 'delete_friend':
        require_login();
        $input = get_json_input();
        $friend_id = (int)($input['friend_id'] ?? 0);
        $user_id = $_SESSION['user_id'];
        if (!$friend_id || $friend_id == $user_id) json_response(0, '参数错误');
        
        $conn = db_connect();
        
        // 先查询所有图片/视频消息的文件路径，用于删除物理文件
        $result = $conn->query("SELECT content, type FROM messages 
            WHERE ((from_user_id = {$user_id} AND to_user_id = {$friend_id}) OR (from_user_id = {$friend_id} AND to_user_id = {$user_id}))
            AND type IN (2, 3)");
        $files_to_delete = [];
        while ($row = $result->fetch_assoc()) {
            $files_to_delete[] = $row['content'];
        }
        $result->close();
        
        // 双向删除好友关系
        $conn->query("DELETE FROM friends WHERE (user_id = {$user_id} AND friend_id = {$friend_id}) OR (user_id = {$friend_id} AND friend_id = {$user_id})");
        // 删除双方聊天记录
        $conn->query("DELETE FROM messages WHERE (from_user_id = {$user_id} AND to_user_id = {$friend_id}) OR (from_user_id = {$friend_id} AND to_user_id = {$user_id})");
        $conn->close();
        
        // 删除物理文件
        foreach ($files_to_delete as $file_path) {
            $full_path = UPLOAD_DIR . '/' . $file_path;
            if (file_exists($full_path) && is_file($full_path)) {
                @unlink($full_path);
            }
        }
        
        json_response(1, '已删除好友');
        break;

    case 'unread_count':
        require_login();
        $user_id = $_SESSION['user_id'];
        $conn = db_connect();
        // 总未读数
        $result = $conn->query("SELECT COUNT(*) as total FROM messages WHERE to_user_id = {$user_id} AND is_read = 0");
        $total = $result->fetch_assoc()['total'];
        
        // 按会话分组的未读数
        $result2 = $conn->query("SELECT from_user_id as friend_id, COUNT(*) as unread FROM messages WHERE to_user_id = {$user_id} AND is_read = 0 GROUP BY from_user_id");
        $per_chat = [];
        while ($row = $result2->fetch_assoc()) {
            $per_chat[$row['friend_id']] = $row['unread'];
        }
        
        // 获取最新消息列表（用于消息列表页）
        $sql = "SELECT 
            u.id as friend_id, u.nickname, u.avatar,
            m.content as last_msg, m.created_at as last_time, m.from_user_id, m.type,
            (SELECT COUNT(*) FROM messages WHERE to_user_id = ? AND from_user_id = u.id AND is_read = 0) as unread
        FROM users u
        INNER JOIN messages m ON 
            (m.from_user_id = u.id AND m.to_user_id = ?) OR 
            (m.from_user_id = ? AND m.to_user_id = u.id)
        WHERE m.id = (
            SELECT MAX(id) FROM messages 
            WHERE (from_user_id = u.id AND to_user_id = ?) OR (from_user_id = ? AND to_user_id = u.id)
        )
        ORDER BY m.id DESC";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("iiiii", $user_id, $user_id, $user_id, $user_id, $user_id);
        $stmt->execute();
        $chats = [];
        $result3 = $stmt->get_result();
        while ($row = $result3->fetch_assoc()) {
            // 处理消息类型显示
            if ($row['type'] == 2) {
                $row['last_msg'] = '[图片]';
            } elseif ($row['type'] == 3) {
                $row['last_msg'] = '[视频]';
            }
            $chats[] = $row;
        }
        $stmt->close();
        $conn->close();
        
        json_response(1, 'success', ['total' => (int)$total, 'per_chat' => $per_chat, 'chats' => $chats]);
        break;

    // ========== 发现页 ==========
    case 'discover_list':
        // 朋友圈列表
        require_login();
        ensure_moments_tables();
        try {
            $conn = db_connect();
            $page = max(1, (int)($_GET['page'] ?? 1));
            $page_size = 10;
            $offset = ($page - 1) * $page_size;
            $current_uid = $_SESSION['user_id'];

            // 获取当前用户的好友ID列表
            $friendIds = [];
            $stmtF = $conn->prepare("SELECT friend_id FROM friends WHERE user_id = ? AND status = 1");
            $stmtF->bind_param("i", $current_uid);
            $stmtF->execute();
            $resF = $stmtF->get_result();
            while ($r = $resF->fetch_assoc()) {
                $friendIds[] = (int)$r['friend_id'];
            }
            $stmtF->close();

            // 查询所有动态，根据发布者的隐私设置过滤
            $sql = "SELECT m.*, u.username, u.nickname, u.avatar, u.moment_visible, u.show_moment_in_discover
                    FROM moments m
                    JOIN users u ON m.user_id = u.id
                    ORDER BY m.id DESC LIMIT ? OFFSET ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ii", $page_size, $offset);
            $stmt->execute();
            $result = $stmt->get_result();
            $list = [];
            while ($row = $result->fetch_assoc()) {
                // 跳过关闭发现页展示的用户的动态（自己的动态除外）
                if ($row['show_moment_in_discover'] == 0 && $row['user_id'] != $current_uid) continue;

                // 根据发布者的朋友圈权限过滤
                if ($row['user_id'] != $current_uid) {
                    // moment_visible: 0=所有人可见, 1=仅好友可见, 2=仅自己可见
                    if ($row['moment_visible'] == 2) continue; // 仅自己可见，跳过
                    if ($row['moment_visible'] == 1 && !in_array((int)$row['user_id'], $friendIds)) continue; // 仅好友可见
                }

                $row['images'] = $row['images'] ? json_decode($row['images'], true) : [];
                $row['likes'] = $row['likes'] ? explode(',', $row['likes']) : [];
                $row['liked'] = in_array($current_uid, $row['likes']);
                $row['like_count'] = count($row['likes']);
                // 移除隐私字段，不暴露给前端
                unset($row['moment_visible'], $row['show_moment_in_discover']);
                $list[] = $row;
            }
            $stmt->close();
            $conn->close();
            json_response(1, 'success', ['items' => $list]);
        } catch (Exception $e) {
            json_response(0, '加载失败：' . $e->getMessage());
        }
        break;

    // 发布朋友圈
    case 'publish_moment':
        require_login();
        ensure_moments_tables();
        $input = get_json_input();
        $content = trim($input['content'] ?? '');
        $images = $input['images'] ?? [];
        
        if ($content === '' && empty($images)) {
            json_response(0, '请输入内容或选择图片');
        }
        
        try {
            $conn = db_connect();
            $images_json = !empty($images) ? json_encode($images) : null;
            $stmt = $conn->prepare("INSERT INTO moments (user_id, content, images) VALUES (?, ?, ?)");
            $stmt->bind_param("iss", $_SESSION['user_id'], $content, $images_json);
            $result = $stmt->execute();
            $moment_id = $stmt->insert_id;
            $stmt->close();
            $conn->close();
            
            json_response($result ? 1 : 0, $result ? '发布成功' : '发布失败', ['id' => $moment_id]);
        } catch (Exception $e) {
            json_response(0, '发布失败：' . $e->getMessage());
        }
        break;

    // 点赞/取消点赞
    case 'toggle_like':
        require_login();
        ensure_moments_tables();
        $input = get_json_input();
        $moment_id = (int)($input['moment_id'] ?? 0);
        
        if (!$moment_id) json_response(0, '参数错误');
        
        try {
            $conn = db_connect();
            $stmt = $conn->prepare("SELECT likes FROM moments WHERE id = ?");
            $stmt->bind_param("i", $moment_id);
            $stmt->execute();
            $result = $stmt->get_result();
            $row = $result->fetch_assoc();
            $stmt->close();
            
            if (!$row) {
                $conn->close();
                json_response(0, '动态不存在');
            }
            
            $likes = $row['likes'] ? explode(',', $row['likes']) : [];
            $uid = $_SESSION['user_id'];
            $liked = in_array($uid, $likes);
            
            if ($liked) {
                $likes = array_diff($likes, [$uid]);
            } else {
                $likes[] = $uid;
            }
            $likes_str = implode(',', $likes);
            
            $stmt = $conn->prepare("UPDATE moments SET likes = ? WHERE id = ?");
            $stmt->bind_param("si", $likes_str, $moment_id);
            $result = $stmt->execute();
            $stmt->close();
            $conn->close();
            
            json_response(1, $liked ? '取消点赞' : '点赞成功', ['liked' => !$liked, 'like_count' => count($likes)]);
        } catch (Exception $e) {
            json_response(0, '操作失败：' . $e->getMessage());
        }
        break;

    // 获取评论
    case 'moment_comments':
        require_login();
        ensure_moments_tables();
        $moment_id = (int)($_GET['moment_id'] ?? 0);
        if (!$moment_id) json_response(0, '参数错误');
        
        try {
            $conn = db_connect();
            $sql = "SELECT c.*, u.nickname, u.avatar FROM moment_comments c 
                    JOIN users u ON c.user_id = u.id 
                    WHERE c.moment_id = ? ORDER BY c.id ASC";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("i", $moment_id);
            $stmt->execute();
            $result = $stmt->get_result();
            $comments = [];
            while ($row = $result->fetch_assoc()) {
                $comments[] = $row;
            }
            $stmt->close();
            $conn->close();
            json_response(1, 'success', ['comments' => $comments]);
        } catch (Exception $e) {
            json_response(0, '获取评论失败：' . $e->getMessage());
        }
        break;

    // 发表评论
    case 'moment_comment':
        require_login();
        ensure_moments_tables();
        $input = get_json_input();
        $moment_id = (int)($input['moment_id'] ?? 0);
        $content = trim($input['content'] ?? '');
        
        if (!$moment_id || $content === '') json_response(0, '参数错误');
        
        try {
            $conn = db_connect();
            $stmt = $conn->prepare("INSERT INTO moment_comments (moment_id, user_id, content) VALUES (?, ?, ?)");
            $stmt->bind_param("iis", $moment_id, $_SESSION['user_id'], $content);
            $result = $stmt->execute();
            $comment_id = $stmt->insert_id;
            $stmt->close();
            
            if ($result) {
                $conn->query("UPDATE moments SET comments_count = comments_count + 1 WHERE id = {$moment_id}");
            }
            $conn->close();
            
            json_response($result ? 1 : 0, $result ? '评论成功' : '评论失败');
        } catch (Exception $e) {
            json_response(0, '评论失败：' . $e->getMessage());
        }
        break;

    // 删除朋友圈
    case 'delete_moment':
        require_login();
        ensure_moments_tables();
        $input = get_json_input();
        $moment_id = (int)($input['moment_id'] ?? 0);
        
        try {
            $conn = db_connect();
            // 验证所有权
            $stmt = $conn->prepare("SELECT user_id, images FROM moments WHERE id = ?");
            $stmt->bind_param("i", $moment_id);
            $stmt->execute();
            $row = $stmt->get_result()->fetch_assoc();
            $stmt->close();
            
            if (!$row) {
                $conn->close();
                json_response(0, '动态不存在');
            }
            if ($row['user_id'] != $_SESSION['user_id']) {
                $conn->close();
                json_response(0, '无权删除');
            }
            
            // 删除关联图片文件
            if ($row['images']) {
                $images = json_decode($row['images'], true);
                if (is_array($images)) {
                    foreach ($images as $img) {
                        if (strpos($img, UPLOAD_URL) === 0) {
                            $path = UPLOAD_DIR . '/' . substr($img, strlen(UPLOAD_URL) + 1);
                            if (file_exists($path)) @unlink($path);
                        }
                    }
                }
            }
            
            $conn->query("DELETE FROM moment_comments WHERE moment_id = {$moment_id}");
            $stmt = $conn->prepare("DELETE FROM moments WHERE id = ?");
            $stmt->bind_param("i", $moment_id);
            $result = $stmt->execute();
            $stmt->close();
            $conn->close();
            
            json_response($result ? 1 : 0, $result ? '删除成功' : '删除失败');
        } catch (Exception $e) {
            json_response(0, '删除失败：' . $e->getMessage());
        }
        break;

    // ========== 隐私设置 ==========
    case 'get_privacy_settings':
        require_login();
        try {
            $conn = db_connect();
            $stmt = $conn->prepare("SELECT moment_visible, allow_search, allow_add_friend, show_moment_in_discover FROM users WHERE id = ?");
            $stmt->bind_param("i", $_SESSION['user_id']);
            $stmt->execute();
            $result = $stmt->get_result();
            $settings = $result->fetch_assoc();
            $stmt->close();
            $conn->close();
            json_response(1, 'success', ['settings' => $settings]);
        } catch (Exception $e) {
            json_response(0, '获取设置失败：' . $e->getMessage());
        }
        break;

    case 'update_privacy_settings':
        require_login();
        $input = get_json_input();
        $moment_visible = (int)($input['moment_visible'] ?? 1);
        $allow_search = (int)($input['allow_search'] ?? 1);
        $allow_add_friend = (int)($input['allow_add_friend'] ?? 1);
        $show_moment_in_discover = (int)($input['show_moment_in_discover'] ?? 1);

        // 限制范围
        if ($moment_visible < 0 || $moment_visible > 2) $moment_visible = 1;
        if ($allow_search < 0 || $allow_search > 1) $allow_search = 1;
        if ($allow_add_friend < 0 || $allow_add_friend > 1) $allow_add_friend = 1;
        if ($show_moment_in_discover < 0 || $show_moment_in_discover > 1) $show_moment_in_discover = 1;

        try {
            $conn = db_connect();
            $stmt = $conn->prepare("UPDATE users SET moment_visible = ?, allow_search = ?, allow_add_friend = ?, show_moment_in_discover = ? WHERE id = ?");
            $stmt->bind_param("iiiii", $moment_visible, $allow_search, $allow_add_friend, $show_moment_in_discover, $_SESSION['user_id']);
            $result = $stmt->execute();
            $stmt->close();
            $conn->close();
            json_response($result ? 1 : 0, $result ? '设置已保存' : '保存失败');
        } catch (Exception $e) {
            json_response(0, '保存失败：' . $e->getMessage());
        }
        break;

    default:
        json_response(-2, '未知接口: ' . $action);
        break;
}
