<?php
require_once 'config.php';
if (!is_installed()) {
    header('Location: install.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>简讯</title>
    <!-- ===== 外部库已全部本地化到 assets/ 目录（download_assets.py 下载） ===== -->
    <!-- Remix Icon（原 CDN: https://cdn.jsdelivr.net/npm/remixicon@3.5.0/fonts/remixicon.css） -->
    <link href="assets/css/remixicon.css" rel="stylesheet">
    <!-- Vant UI（原 CDN: https://unpkg.com/vant@4/lib/index.css） -->
    <link rel="stylesheet" href="assets/css/vant.css">
    <!-- Vue 3（原 CDN: https://unpkg.com/vue@3/dist/vue.global.prod.js） -->
    <script src="assets/js/vue.global.prod.js"></script>
    <!-- Vant JS（原 CDN: https://unpkg.com/vant@4/lib/vant.min.js） -->
    <script src="assets/js/vant.min.js"></script>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; -webkit-tap-highlight-color: transparent; }
        html, body { height: 100%; overflow: hidden; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'PingFang SC', 'Hiragino Sans GB', 'Microsoft YaHei', sans-serif;
            background: #FDB59F;
            color: #333;
            font-size: 14px;
        }
        #app { height: 100%; width: 100%; max-width: 480px; margin: 0 auto; position: relative; background: #FDB59F; overflow: hidden; }

        /* ===== 页面切换动画 ===== */
        .page-enter-active, .page-leave-active { transition: all 0.3s ease; }
        .page-enter-from { opacity: 0; transform: translateX(30px); }
        .page-leave-to { opacity: 0; transform: translateX(-30px); }

        /* ===== 通用页面容器 ===== */
        .page {
            position: absolute;
            top: 0; left: 0; right: 0; bottom: 0;
            overflow-y: auto;
            overflow-x: hidden;
            -webkit-overflow-scrolling: touch;
        }
        .page::-webkit-scrollbar { width: 0; }

        /* ===== 登录注册页渐变背景 ===== */
        .auth-bg {
            background: #FDB59F;
            height: calc(var(--vh, 1vh) * 100);
            width: 100%;
            position: fixed;
            top: 0; left: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
            overflow: hidden;
            z-index: 10;
        }
        .page.auth-bg { overflow: hidden; }
        .auth-decoration {
            position: absolute;
            width: 200px; height: 200px;
            border-radius: 50%;
            background: rgba(255,255,255,0.15);
            filter: blur(40px);
        }
        .auth-decoration.d1 { top: -50px; left: -50px; }
        .auth-decoration.d2 { bottom: -50px; right: -50px; background: rgba(255,182,193,0.3); }

        .auth-card {
            width: 100%;
            max-width: 380px;
            background: transparent;
            backdrop-filter: none;
            -webkit-backdrop-filter: none;
            border: none;
            border-radius: 0;
            padding: 0;
            box-shadow: none;
            position: relative;
            z-index: 1;
            animation: slideUp 0.5s ease;
        }
        @keyframes slideUp { from { opacity: 0; transform: translateY(30px);} to { opacity: 1; transform: translateY(0);} }

        .auth-logo { text-align: center; margin-bottom: 30px; }
        .auth-logo-icon {
            width: 72px; height: 72px;
            margin: 0 auto 12px;
            background: linear-gradient(135deg, #ff9a9e 0%, #fecfef 50%, #ff9a9e 100%);
            border-radius: 22px;
            display: flex; align-items: center; justify-content: center;
            box-shadow: 0 10px 30px rgba(255,107,157,0.4);
            animation: float 3s ease-in-out infinite;
        }
        @keyframes float { 0%,100%{transform:translateY(0);} 50%{transform:translateY(-6px);} }
        .auth-logo-icon i { font-size: 38px; color: #fff; }
        .auth-logo h1 {
            font-size: 26px;
            color: #fff;
            text-shadow: 0 2px 10px rgba(255,107,157,0.3);
        }
        .auth-logo p { color: rgba(255,255,255,0.8); font-size: 12px; margin-top: 4px; }

        .auth-title { text-align: center; font-size: 18px; font-weight: 600; margin-bottom: 22px; color: #fff; }

        .auth-input {
            position: relative;
            margin-bottom: 0;
            padding: 14px 0;
            border-bottom: 1px solid rgba(255,255,255,0.3);
        }
        .auth-input i {
            position: absolute; left: 8px; top: 50%; transform: translateY(-50%);
            color: rgba(255,255,255,0.9); font-size: 18px; z-index: 2;
        }
        .auth-input input {
            width: 100%; height: 36px;
            padding: 0 10px 0 40px;
            border: none;
            border-radius: 0;
            font-size: 15px;
            transition: all 0.3s;
            outline: none;
            background: transparent;
            color: #fff;
        }
        .auth-input input:focus {
            background: transparent;
            box-shadow: none;
        }
        .auth-input input::placeholder { color: rgba(255,255,255,0.7); }

        .auth-btn {
            width: 100%; height: 52px;
            background: linear-gradient(135deg, #ff9a9e 0%, #ff6b9d 100%);
            color: #fff;
            border: none;
            border-radius: 14px;
            font-size: 16px; font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            box-shadow: 0 8px 25px rgba(255,107,157,0.35);
            margin-top: 8px;
        }
        .auth-btn:active { transform: scale(0.98); }

        .auth-link { text-align: center; margin-top: 18px; font-size: 13px; color: rgba(255,255,255,0.8); }
        .auth-link a { color: #fff; text-decoration: none; font-weight: 600; cursor: pointer; }
        .auth-options { display: flex; justify-content: space-between; align-items: center; margin: 20px 0; font-size: 13px; }
        .auth-options label { display: flex; align-items: center; color: rgba(255,255,255,0.85); cursor: pointer; }
        .auth-options input { margin-right: 6px; accent-color: #fff; }
        .auth-options a { color: #fff; text-decoration: none; cursor: pointer; }

        .password-strength { display: flex; gap: 4px; margin: -8px 0 16px; }
        .strength-bar { flex: 1; height: 4px; background: #eee; border-radius: 2px; transition: all 0.3s; }
        .strength-bar.weak { background: #ff4757; }
        .strength-bar.medium { background: #ffa502; }
        .strength-bar.strong { background: #2ed573; }

        .auth-divider { display: flex; align-items: center; margin: 22px 0 18px; }
        .auth-divider::before, .auth-divider::after { content:''; flex:1; height:1px; background: rgba(255,255,255,0.3); }
        .auth-divider span { padding: 0 12px; color: rgba(255,255,255,0.7); font-size: 12px; }

        .quick-login { display: flex; justify-content: center; gap: 22px; }
        .quick-btn {
            width: 44px; height: 44px;
            border-radius: 50%;
            display: flex; align-items: center; justify-content: center;
            font-size: 20px;
            cursor: pointer;
            border: none;
            background: rgba(255,255,255,0.4);
            backdrop-filter: blur(10px);
            transition: all 0.3s;
        }
        .quick-btn:active { transform: scale(0.9); }
        .quick-btn.qq { color: #fff; }
        .quick-btn.wechat { color: #fff; }
        .quick-btn.weibo { color: #fff; }

        /* ===== 顶部导航栏 ===== */
        .app-header {
            position: absolute;
            top: 0; left: 0; right: 0;
            height: 50px;
            background: #FDB59F;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 16px;
            z-index: 100;
            border-bottom: 1px solid rgba(255,255,255,0.5);
        }
        .app-header .title {
            color: #fff;
            font-size: 17px;
            font-weight: 600;
            text-align: center;
            flex: 1;
        }
        .app-header .icon-btn {
            width: 32px; height: 32px;
            display: flex; align-items: center; justify-content: center;
            color: #fff;
            font-size: 20px;
            cursor: pointer;
            border-radius: 50%;
            transition: background 0.2s;
        }
        .app-header .icon-btn:active { background: rgba(255,255,255,0.2); }

        /* ===== 底部导航栏 ===== */
        .app-tabbar {
            position: absolute;
            bottom: 0; left: 0; right: 0;
            height: 56px;
            background: #FDB59F;
            display: flex;
            border-top: 1px solid rgba(255,255,255,0.5);
            z-index: 100;
            padding-bottom: env(safe-area-inset-bottom);
        }
        .tab-item {
            flex: 1;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.2s;
            position: relative;
        }
        .tab-item i {
            font-size: 22px;
            color: #999;
            transition: all 0.2s;
        }
        .tab-item span {
            font-size: 11px;
            color: #999;
            margin-top: 2px;
            transition: all 0.2s;
        }
        .tab-item.active i, .tab-item.active span {
            color: #ff6b9d;
        }
        .tab-item.active i {
            transform: scale(1.1);
        }
        .tab-badge {
            position: absolute;
            top: 4px;
            right: 50%;
            transform: translateX(16px);
            min-width: 16px;
            height: 16px;
            background: #ff4757;
            color: #fff;
            font-size: 10px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 0 4px;
        }

        /* ===== 主内容区 ===== */
        .main-content {
            position: absolute;
            top: 50px;
            bottom: 56px;
            left: 0; right: 0;
            overflow-y: auto;
            overflow-x: hidden;
            -webkit-overflow-scrolling: touch;
            background: #FDB59F;
        }
        .main-content::-webkit-scrollbar { width: 0; }

        /* ===== 聊天列表 ===== */
        .chat-item {
            display: flex;
            align-items: center;
            padding: 12px 16px;
            background: #fff;
            border-bottom: 1px solid #f5f5f5;
            cursor: pointer;
            transition: background 0.2s;
        }
        .chat-item:active { background: #f9f9f9; }
        .chat-avatar {
            width: 48px; height: 48px;
            border-radius: 14px;
            margin-right: 12px;
            background: linear-gradient(135deg, #ff9a9e, #fecfef);
            display: flex; align-items: center; justify-content: center;
            font-size: 20px; color: #fff;
            flex-shrink: 0;
            overflow: hidden;
            position: relative;
        }
        .chat-avatar img { width: 100%; height: 100%; object-fit: cover; }
        .chat-info { flex: 1; min-width: 0; }
        .chat-top { display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px; }
        .chat-name { font-size: 15px; font-weight: 500; color: #333; }
        .chat-time { font-size: 11px; color: #bbb; flex-shrink: 0; }
        .chat-bottom { display: flex; justify-content: space-between; align-items: center; }
        .chat-msg { font-size: 13px; color: #999; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; flex: 1; }
        .chat-unread {
            min-width: 18px; height: 18px;
            background: #ff4757;
            color: #fff;
            font-size: 11px;
            border-radius: 9px;
            display: flex; align-items: center; justify-content: center;
            padding: 0 5px;
            margin-left: 8px;
            flex-shrink: 0;
        }

        /* ===== 聊天页面 ===== */
        .chat-page {
            background: #FDB59F;
            position: absolute;
            top: 0; left: 0; right: 0; bottom: 0;
            width: 100%;
            height: 100%;
            overflow: hidden;
            z-index: 100;
        }
        .chat-header {
            position: absolute; top: 0; left: 0; right: 0;
            height: 50px;
            background: #FDB59F;
            display: flex; align-items: center;
            padding: 0 12px;
            z-index: 100;
            color: #fff;
        }
        .chat-header .back { width: 32px; height: 32px; display: flex; align-items: center; justify-content: center; font-size: 22px; cursor: pointer; }
        .chat-header .friend-info { flex: 1; text-align: center; }
        .chat-header .friend-name { font-size: 16px; font-weight: 600; }
        .chat-header .more { width: 32px; height: 32px; display: flex; align-items: center; justify-content: center; font-size: 20px; cursor: pointer; }
        
        .chat-messages {
            position: absolute;
            top: 50px; bottom: 60px;
            left: 0; right: 0;
            padding: 12px;
            overflow-y: auto;
            -webkit-overflow-scrolling: touch;
        }
        .chat-messages::-webkit-scrollbar { width: 0; }
        
        .msg-row { display: flex; margin-bottom: 14px; }
        .msg-row.mine { flex-direction: row-reverse; }
        .msg-avatar {
            width: 36px; height: 36px;
            border-radius: 10px;
            background: linear-gradient(135deg, #ff9a9e, #fecfef);
            display: flex; align-items: center; justify-content: center;
            font-size: 16px; color: #fff;
            flex-shrink: 0;
            overflow: hidden;
        }
        .msg-avatar img { width: 100%; height: 100%; object-fit: cover; }
        .msg-bubble {
            max-width: 70%;
            padding: 10px 14px;
            border-radius: 16px;
            font-size: 14px;
            line-height: 1.5;
            word-wrap: break-word;
            margin: 0 8px;
            position: relative;
        }
        .msg-row:not(.mine) .msg-bubble {
            background: #fff;
            color: #333;
            border-top-left-radius: 4px;
        }
        .msg-row.mine .msg-bubble {
            background: linear-gradient(135deg, #ff9a9e 0%, #ff6b9d 100%);
            color: #fff;
            border-top-right-radius: 4px;
        }
        .msg-time { text-align: center; color: #ccc; font-size: 11px; margin: 8px 0; }
        
        /* 图片消息 */
        .msg-bubble.msg-image {
            padding: 0;
            background: transparent;
            max-width: 70%;
            border-radius: 12px;
            overflow: hidden;
        }
        .msg-bubble.msg-image .img-wrap {
            position: relative;
            display: block;
        }
        .msg-bubble.msg-image img {
            max-width: 100%;
            max-height: 300px;
            display: block;
            cursor: pointer;
        }
        .msg-row.mine .msg-bubble.msg-image {
            background: transparent;
        }
        .msg-row:not(.mine) .msg-bubble.msg-image {
            background: transparent;
        }
        
        /* 视频消息 */
        .msg-bubble.msg-video {
            padding: 0;
            background: #000;
            max-width: 75%;
            border-radius: 12px;
            overflow: hidden;
        }
        .msg-bubble.msg-video .video-wrap {
            position: relative;
        }
        .msg-bubble.msg-video video {
            max-width: 100%;
            max-height: 300px;
            display: block;
            background: #000;
            width: 100%;
        }
        .msg-bubble.msg-video .video-name {
            font-size: 12px;
            color: #ccc;
            padding: 6px 10px;
            text-align: center;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            background: rgba(0,0,0,0.3);
        }
        .msg-row.mine .msg-bubble.msg-video {
            background: #000;
        }
        
        /* 上传中遮罩 */
        .uploading-mask {
            position: absolute;
            top: 0; left: 0; right: 0; bottom: 0;
            background: rgba(0,0,0,0.5);
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            color: #fff;
            font-size: 13px;
            gap: 8px;
        }
        .uploading-spinner {
            width: 24px; height: 24px;
            border: 2px solid rgba(255,255,255,0.3);
            border-top-color: #fff;
            border-radius: 50%;
            animation: spin 0.8s linear infinite;
        }
        @keyframes spin { to { transform: rotate(360deg); } }

        .chat-input-bar {
            position: absolute;
            bottom: 0; left: 0; right: 0;
            height: 60px;
            background: #fff;
            border-top: 1px solid #eee;
            display: flex;
            align-items: center;
            padding: 0 10px;
            gap: 8px;
        }
        .chat-input-bar .icon-btn {
            width: 36px; height: 36px;
            display: flex; align-items: center; justify-content: center;
            font-size: 22px;
            color: #999;
            cursor: pointer;
            flex-shrink: 0;
        }
        .chat-input-bar input {
            flex: 1;
            height: 40px;
            border: none;
            background: #f5f5f5;
            border-radius: 20px;
            padding: 0 16px;
            font-size: 14px;
            outline: none;
        }
        .send-btn {
            background: linear-gradient(135deg, #ff9a9e 0%, #ff6b9d 100%);
            color: #fff;
            border: none;
            padding: 8px 16px;
            border-radius: 20px;
            font-size: 14px;
            cursor: pointer;
            flex-shrink: 0;
        }
        .send-btn:disabled { opacity: 0.5; }

        /* ===== 联系人页面 ===== */
        .search-bar {
            padding: 10px 16px;
            background: #fff;
            border-bottom: 1px solid #f0f0f0;
            position: sticky;
            top: 0;
            z-index: 10;
        }
        .search-box {
            background: #f5f5f5;
            border-radius: 20px;
            height: 36px;
            display: flex;
            align-items: center;
            padding: 0 14px;
        }
        .search-box i { color: #bbb; margin-right: 8px; font-size: 16px; }
        .search-box input { flex: 1; border: none; background: transparent; outline: none; font-size: 14px; }

        .contact-group-title {
            padding: 8px 16px;
            font-size: 13px;
            color: #999;
            background: #f7f8fa;
        }
        .contact-item {
            display: flex;
            align-items: center;
            padding: 12px 16px;
            background: #fff;
            border-bottom: 1px solid #f5f5f5;
            cursor: pointer;
        }
        .contact-item:active { background: #f9f9f9; }
        .contact-avatar {
            width: 42px; height: 42px;
            border-radius: 12px;
            margin-right: 12px;
            background: linear-gradient(135deg, #a8edea, #fed6e3);
            display: flex; align-items: center; justify-content: center;
            font-size: 18px; color: #fff;
            flex-shrink: 0;
            overflow: hidden;
        }
        .contact-avatar img { width: 100%; height: 100%; object-fit: cover; }
        .contact-info { flex: 1; min-width: 0; }
        .contact-name { font-size: 15px; color: #333; }
        .contact-sign { font-size: 12px; color: #bbb; margin-top: 3px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
        .contact-actions { display: flex; gap: 6px; flex-shrink: 0; }
        .c-btn {
            width: 32px; height: 32px;
            border-radius: 8px;
            border: none;
            cursor: pointer;
            display: flex; align-items: center; justify-content: center;
            font-size: 16px;
            transition: all 0.2s;
        }
        .c-btn.chat-btn { background: #fff0f3; color: #ff6b9d; }
        .c-btn.chat-btn:active { background: #ffe4ec; }
        .c-btn.delete-btn { background: #f5f5f5; color: #999; }
        .c-btn.delete-btn:active { background: #eee; color: #ff4757; }

        /* ===== 发现页面 ===== */
        .discover-banner {
            margin: 16px;
            height: 140px;
            border-radius: 18px;
            /* banner 图已本地化（原 https://picsum.photos/seed/jianxun-discover/480/280） */
            background: url('assets/img/discover-banner.jpg') center/cover no-repeat;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #fff;
            font-size: 18px;
            font-weight: 600;
            box-shadow: 0 10px 30px rgba(253,181,159,0.25);
            position: relative;
            overflow: hidden;
        }
        .discover-banner::after {
            content: '';
            position: absolute;
            inset: 0;
            background: rgba(0,0,0,0.2);
        }
        .discover-section { margin: 0 16px 16px; background: #fff; border-radius: 16px; overflow: hidden; }
        .discover-item {
            display: flex;
            align-items: center;
            padding: 14px 16px;
            border-bottom: 1px solid #f5f5f5;
            cursor: pointer;
        }
        .discover-item:last-child { border-bottom: none; }
        .discover-item:active { background: #f9f9f9; }
        .discover-icon {
            width: 36px; height: 36px;
            border-radius: 10px;
            display: flex; align-items: center; justify-content: center;
            font-size: 18px;
            color: #fff;
            margin-right: 12px;
            flex-shrink: 0;
        }
        .discover-text { flex: 1; }
        .discover-title { font-size: 15px; color: #333; }
        .discover-desc { font-size: 12px; color: #bbb; margin-top: 2px; }
        .discover-arrow { color: #ccc; font-size: 16px; }
        .discover-badge {
            background: #ff4757;
            color: #fff;
            font-size: 10px;
            padding: 2px 6px;
            border-radius: 8px;
            margin-right: 6px;
        }

        /* ===== 朋友圈 ===== */
        .moment-list {
            padding: 12px 14px 24px;
        }
        .moment-item {
            margin-bottom: 16px;
        }
        .moment-card {
            background: rgba(255,255,255,0.18);
            backdrop-filter: blur(12px);
            -webkit-backdrop-filter: blur(12px);
            border: 1px solid rgba(255,255,255,0.28);
            border-radius: 18px;
            padding: 16px 16px 14px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.06);
        }
        .moment-user {
            display: flex;
            align-items: center;
            margin-bottom: 8px;
            padding: 4px 4px 8px;
        }
        .moment-avatar {
            width: 42px; height: 42px;
            border-radius: 50%;
            background: rgba(255,255,255,0.2);
            display: flex; align-items: center; justify-content: center;
            font-size: 18px;
            color: #fff;
            margin-right: 12px;
            overflow: hidden;
            flex-shrink: 0;
            border: 2px solid rgba(255,255,255,0.3);
        }
        .moment-avatar img { width: 100%; height: 100%; object-fit: cover; }
        .moment-name {
            font-size: 15px;
            font-weight: 600;
            color: #fff;
            line-height: 1.3;
        }
        .moment-time {
            font-size: 12px;
            color: rgba(255,255,255,0.55);
            margin-top: 3px;
        }
        .moment-content {
            font-size: 14px;
            color: rgba(255,255,255,0.9);
            line-height: 1.65;
            margin-bottom: 12px;
            word-wrap: break-word;
        }
        .moment-images {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 5px;
            margin-bottom: 12px;
        }
        .moment-images.one { grid-template-columns: 1fr; max-width: 220px; }
        .moment-images.two { grid-template-columns: repeat(2, 1fr); max-width: 280px; }
        .moment-img {
            width: 100%;
            aspect-ratio: 1;
            border-radius: 10px;
            overflow: hidden;
            background: rgba(0,0,0,0.1);
            cursor: pointer;
        }
        .moment-images.one .moment-img { aspect-ratio: 4/3; }
        .moment-images.two .moment-img { aspect-ratio: 1; }
        .moment-img img { width: 100%; height: 100%; object-fit: cover; }
        .moment-actions {
            display: flex;
            align-items: center;
            gap: 24px;
            padding-top: 10px;
            border-top: 1px solid rgba(255,255,255,0.12);
        }
        .moment-action {
            display: flex;
            align-items: center;
            gap: 5px;
            font-size: 13px;
            color: rgba(255,255,255,0.65);
            cursor: pointer;
            line-height: 1;
        }
        .moment-action:active { opacity: 0.7; }
        .moment-action.liked { color: #ff6b9d; }
        .moment-action i { font-size: 17px; line-height: 1; }
        .moment-action span { line-height: 1; }
        .moment-action-delete {
            margin-left: auto;
            color: rgba(255,255,255,0.45);
        }
        .moment-empty {
            text-align: center;
            padding: 80px 20px;
            color: rgba(255,255,255,0.5);
        }
        .moment-empty i { font-size: 52px; margin-bottom: 16px; display: block; }
        .moment-empty p { font-size: 14px; line-height: 1.8; }
        .moment-comments {
            margin-top: 10px;
            padding: 10px 14px;
            background: rgba(0,0,0,0.1);
            border-radius: 12px;
        }
        .moment-comment-item {
            font-size: 13px;
            color: rgba(255,255,255,0.75);
            line-height: 1.7;
            padding: 4px 0;
        }
        .moment-comment-item .cname {
            color: rgba(255,255,255,0.95);
            font-weight: 500;
            margin-right: 4px;
        }
        .moment-comment-input {
            display: flex;
            gap: 8px;
            margin-top: 10px;
            align-items: center;
        }
        .moment-comment-input input {
            flex: 1;
            height: 36px;
            background: rgba(255,255,255,0.18);
            border: 1px solid rgba(255,255,255,0.28);
            border-radius: 18px;
            padding: 0 16px;
            font-size: 13px;
            color: #fff;
            outline: none;
        }
        .moment-comment-input input::placeholder { color: rgba(255,255,255,0.5); }
        .moment-comment-input button {
            padding: 0 16px;
            height: 36px;
            background: #ff6b9d;
            color: #fff;
            border: none;
            border-radius: 18px;
            font-size: 13px;
            cursor: pointer;
            white-space: nowrap;
            flex-shrink: 0;
        }
        .moment-comment-input button:active { opacity: 0.8; }

        /* 发布朋友圈页面 */
        .publish-panel {
            width: 100%;
            max-width: 480px;
            height: 100%;
            background: #FDB59F;
            display: flex;
            flex-direction: column;
            animation: slideDown 0.3s ease;
        }
        .publish-content {
            flex: 1;
            overflow-y: auto;
            padding: 20px;
        }
        .publish-textarea {
            width: 100%;
            min-height: 130px;
            background: rgba(255,255,255,0.18);
            backdrop-filter: blur(12px);
            -webkit-backdrop-filter: blur(12px);
            border: 1px solid rgba(255,255,255,0.28);
            border-radius: 16px;
            padding: 16px;
            font-size: 15px;
            color: #fff;
            outline: none;
            resize: none;
            font-family: inherit;
            line-height: 1.6;
        }
        .publish-textarea::placeholder { color: rgba(255,255,255,0.45); }
        .publish-images {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 8px;
            margin-top: 16px;
        }
        .publish-img-item {
            aspect-ratio: 1;
            border-radius: 12px;
            overflow: hidden;
            position: relative;
        }
        .publish-img-item img { width: 100%; height: 100%; object-fit: cover; }
        .publish-img-del {
            position: absolute;
            top: 5px; right: 5px;
            width: 22px; height: 22px;
            background: rgba(0,0,0,0.55);
            border-radius: 50%;
            display: flex; align-items: center; justify-content: center;
            color: #fff;
            font-size: 13px;
            cursor: pointer;
        }
        .publish-img-add {
            aspect-ratio: 1;
            border: 2px dashed rgba(255,255,255,0.35);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 28px;
            color: rgba(255,255,255,0.45);
            cursor: pointer;
        }
        .publish-img-add:active { background: rgba(255,255,255,0.05); }
        .publish-tip {
            margin-top: 20px;
            font-size: 12px;
            color: rgba(255,255,255,0.5);
            text-align: center;
        }

        /* ===== 设置页面 ===== */
        .settings-panel {
            width: 100%;
            max-width: 480px;
            height: 100%;
            background: #FDB59F;
            display: flex;
            flex-direction: column;
            animation: slideDown 0.3s ease;
        }
        .settings-content {
            flex: 1;
            overflow-y: auto;
            -webkit-overflow-scrolling: touch;
            padding: 16px;
        }
        .settings-section-title {
            font-size: 13px;
            font-weight: 600;
            color: rgba(255,255,255,0.7);
            margin: 16px 4px 8px;
        }
        .settings-group {
            background: rgba(255,255,255,0.18);
            backdrop-filter: blur(12px);
            -webkit-backdrop-filter: blur(12px);
            border: 1px solid rgba(255,255,255,0.28);
            border-radius: 16px;
            overflow: hidden;
            margin-bottom: 4px;
        }
        .settings-item {
            display: flex;
            align-items: center;
            padding: 14px 16px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
            cursor: pointer;
        }
        .settings-item:last-child { border-bottom: none; }
        .settings-item:active { background: rgba(255,255,255,0.05); }
        .settings-item-left {
            display: flex;
            align-items: center;
            flex: 1;
            min-width: 0;
        }
        .settings-item-icon {
            width: 32px; height: 32px;
            border-radius: 9px;
            display: flex; align-items: center; justify-content: center;
            font-size: 17px;
            color: #fff;
            margin-right: 12px;
            flex-shrink: 0;
        }
        .settings-item-name {
            font-size: 15px;
            color: #fff;
            font-weight: 500;
        }
        .settings-item-desc {
            font-size: 12px;
            color: rgba(255,255,255,0.5);
            margin-top: 3px;
            line-height: 1.4;
        }
        .settings-arrow {
            color: rgba(255,255,255,0.4);
            font-size: 18px;
            flex-shrink: 0;
            margin-left: 8px;
        }
        /* 分段选择器 */
        .settings-segmented {
            display: flex;
            background: rgba(0,0,0,0.12);
            border-radius: 8px;
            padding: 2px;
            flex-shrink: 0;
            margin-left: 12px;
        }
        .seg-item {
            font-size: 12px;
            padding: 5px 10px;
            border-radius: 6px;
            color: rgba(255,255,255,0.6);
            cursor: pointer;
            white-space: nowrap;
            transition: all 0.2s;
        }
        .seg-item.active {
            background: #ff6b9d;
            color: #fff;
            font-weight: 500;
        }
        /* 开关 */
        .settings-switch {
            width: 46px; height: 26px;
            background: rgba(0,0,0,0.2);
            border-radius: 13px;
            position: relative;
            cursor: pointer;
            flex-shrink: 0;
            transition: background 0.25s;
            margin-left: 12px;
        }
        .settings-switch.on {
            background: #ff6b9d;
        }
        .switch-knob {
            position: absolute;
            top: 3px; left: 3px;
            width: 20px; height: 20px;
            background: #fff;
            border-radius: 50%;
            transition: transform 0.25s;
            box-shadow: 0 1px 3px rgba(0,0,0,0.2);
        }
        .settings-switch.on .switch-knob {
            transform: translateX(20px);
        }
        .settings-save-btn {
            width: 100%;
            height: 48px;
            background: #ff6b9d;
            color: #fff;
            border: none;
            border-radius: 14px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            margin-top: 24px;
        }
        .settings-save-btn:active { opacity: 0.85; }
        .settings-save-btn:disabled { opacity: 0.5; }
        .settings-tip {
            text-align: center;
            font-size: 12px;
            color: rgba(255,255,255,0.4);
            margin-top: 10px;
            margin-bottom: 30px;
        }

        /* ===== 个人中心 ===== */
        .profile-header {
            background: #FDB59F;
            padding: 30px 20px 50px;
            color: #fff;
            position: relative;
        }
        .profile-user { display: flex; align-items: center; }
        .profile-avatar {
            width: 64px; height: 64px;
            border-radius: 20px;
            background: rgba(255,255,255,0.3);
            display: flex; align-items: center; justify-content: center;
            font-size: 28px;
            margin-right: 14px;
            border: 3px solid rgba(255,255,255,0.4);
            overflow: hidden;
        }
        .profile-avatar img { width: 100%; height: 100%; object-fit: cover; }
        .profile-info h2 { font-size: 18px; font-weight: 600; margin-bottom: 4px; }
        .profile-info p { font-size: 13px; opacity: 0.9; }
        .profile-qr { position: absolute; right: 20px; top: 40px; font-size: 22px; cursor: pointer; }

        .profile-stats {
            display: flex;
            background: #fff;
            margin: -25px 16px 16px;
            border-radius: 16px;
            padding: 16px 0;
            box-shadow: 0 4px 15px rgba(0,0,0,0.06);
            position: relative;
            z-index: 2;
        }
        .stat-item {
            flex: 1;
            text-align: center;
            cursor: pointer;
        }
        .stat-num { font-size: 18px; font-weight: 600; color: #333; }
        .stat-label { font-size: 12px; color: #999; margin-top: 2px; }
        .stat-item + .stat-item { border-left: 1px solid #f0f0f0; }

        .profile-menu { margin: 0 16px 16px; background: #fff; border-radius: 16px; overflow: hidden; }
        .menu-item {
            display: flex;
            align-items: center;
            padding: 14px 16px;
            border-bottom: 1px solid #f5f5f5;
            cursor: pointer;
        }
        .menu-item:last-child { border-bottom: none; }
        .menu-item:active { background: #f9f9f9; }
        .menu-icon {
            width: 32px; height: 32px;
            border-radius: 8px;
            display: flex; align-items: center; justify-content: center;
            font-size: 16px;
            color: #fff;
            margin-right: 12px;
        }
        .menu-text { flex: 1; font-size: 15px; color: #333; }
        .menu-arrow { color: #ccc; font-size: 14px; }

        .logout-btn {
            margin: 20px 16px;
            height: 48px;
            background: #fff;
            border: none;
            border-radius: 14px;
            color: #ff4757;
            font-size: 15px;
            font-weight: 500;
            cursor: pointer;
            width: calc(100% - 32px);
        }
        .logout-btn:active { background: #f9f9f9; }

        .menu-right-text {
            font-size: 13px;
            color: #999;
            margin-right: 4px;
        }
        .verified-badge {
            display: inline-flex;
            align-items: center;
            font-size: 12px;
            color: #07c160;
        }
        .verified-badge i { margin-right: 2px; }

        /* ===== 编辑资料弹层 ===== */
        .edit-profile-popup {
            position: fixed;
            top: 0; left: 0; right: 0; bottom: 0;
            background: rgba(0,0,0,0.5);
            z-index: 200;
            display: flex;
            align-items: flex-start;
            justify-content: center;
            animation: fadeIn 0.25s ease;
        }
        .edit-profile-panel {
            width: 100%;
            max-width: 480px;
            height: 100%;
            background: #FDB59F;
            display: flex;
            flex-direction: column;
            animation: slideDown 0.3s ease;
        }
        .ep-header {
            display: flex;
            align-items: center;
            padding: 10px 16px;
            background: #FDB59F;
            border-bottom: 1px solid rgba(255,255,255,0.5);
            gap: 10px;
            position: sticky;
            top: 0;
            z-index: 10;
        }
        .ep-back {
            width: 32px; height: 32px;
            display: flex; align-items: center; justify-content: center;
            font-size: 22px;
            color: #fff;
            cursor: pointer;
        }
        .ep-title {
            flex: 1;
            text-align: center;
            font-size: 17px;
            font-weight: 600;
            color: #fff;
        }
        .ep-save {
            color: #fff;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            padding: 6px 14px;
            background: #ff6b9d;
            border-radius: 16px;
        }
        .ep-save:disabled { opacity: 0.5; cursor: not-allowed; }

        .ep-content {
            flex: 1;
            overflow-y: auto;
            -webkit-overflow-scrolling: touch;
            padding: 12px 0;
        }
        .ep-content::-webkit-scrollbar { width: 0; }

        .ep-section {
            background: #fff;
            margin-bottom: 12px;
        }
        .ep-section-title {
            padding: 8px 16px;
            font-size: 12px;
            color: #999;
        }
        .ep-item {
            display: flex;
            align-items: center;
            padding: 14px 16px;
            border-bottom: 1px solid #f5f5f5;
        }
        .ep-item:last-child { border-bottom: none; }
        .ep-label {
            width: 80px;
            font-size: 14px;
            color: #333;
            flex-shrink: 0;
        }
        .ep-input {
            flex: 1;
            border: none;
            outline: none;
            font-size: 14px;
            color: #333;
            background: transparent;
            text-align: right;
        }
        .ep-input::placeholder { color: #ccc; }
        .ep-value {
            flex: 1;
            text-align: right;
            font-size: 14px;
            color: #999;
        }
        .ep-avatar-wrap {
            flex: 1;
            display: flex;
            justify-content: flex-end;
        }
        .ep-avatar {
            width: 48px; height: 48px;
            border-radius: 14px;
            overflow: hidden;
            background: #f0f0f0;
            display: flex; align-items: center; justify-content: center;
            font-size: 22px;
            color: #ccc;
            cursor: pointer;
        }
        .ep-avatar img { width: 100%; height: 100%; object-fit: cover; }
        .ep-arrow { color: #ccc; font-size: 14px; margin-left: 4px; }

        .ep-tip {
            padding: 10px 16px;
            font-size: 12px;
            color: #999;
            line-height: 1.5;
        }
        .ep-tip.warn { color: #ff6b9d; }

        /* ===== 管理后台 ===== */
        .admin-panel {
            width: 100%;
            max-width: 480px;
            height: 100%;
            background: #FDB59F;
            display: flex;
            flex-direction: column;
            animation: slideDown 0.3s ease;
        }
        .admin-header {
            display: flex;
            align-items: center;
            padding: 10px 12px;
            background: #FDB59F;
            color: #fff;
            gap: 10px;
            position: sticky;
            top: 0;
            z-index: 10;
        }
        .admin-back {
            width: 32px; height: 32px;
            display: flex; align-items: center; justify-content: center;
            font-size: 22px;
            color: #fff;
            cursor: pointer;
        }
        .admin-title {
            flex: 1;
            text-align: center;
            font-size: 16px;
            font-weight: 600;
        }
        .admin-content {
            flex: 1;
            overflow-y: auto;
            -webkit-overflow-scrolling: touch;
            padding: 12px 0;
        }
        .admin-content::-webkit-scrollbar { width: 0; }

        .admin-stats {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 10px;
            padding: 0 16px 12px;
        }
        .admin-stat-card {
            background: #fff;
            border-radius: 12px;
            padding: 14px;
            display: flex;
            flex-direction: column;
        }
        .admin-stat-num {
            font-size: 22px;
            font-weight: 600;
            color: #333;
        }
        .admin-stat-label {
            font-size: 12px;
            color: #999;
            margin-top: 4px;
        }
        .admin-stat-card.primary .admin-stat-num { color: #667eea; }
        .admin-stat-card.success .admin-stat-num { color: #07c160; }
        .admin-stat-card.warning .admin-stat-num { color: #ff9500; }
        .admin-stat-card.danger .admin-stat-num { color: #ff4757; }

        .admin-section {
            background: #fff;
            margin: 0 16px 12px;
            border-radius: 12px;
        }
        .admin-section-title {
            padding: 12px 16px;
            font-size: 14px;
            font-weight: 600;
            color: #333;
            border-bottom: 1px solid #f5f5f5;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }
        .admin-section-title i { margin-right: 6px; color: #667eea; }

        .admin-user-item {
            display: flex;
            align-items: center;
            padding: 12px 16px;
            border-bottom: 1px solid #f5f5f5;
        }
        .admin-user-item:last-child { border-bottom: none; }
        .admin-user-avatar {
            width: 40px; height: 40px;
            border-radius: 12px;
            background: #f0f0f0;
            display: flex; align-items: center; justify-content: center;
            font-size: 18px;
            color: #ccc;
            margin-right: 12px;
            overflow: hidden;
            flex-shrink: 0;
        }
        .admin-user-avatar img { width: 100%; height: 100%; object-fit: cover; }
        .admin-user-info {
            flex: 1;
            min-width: 0;
        }
        .admin-user-name {
            font-size: 14px;
            font-weight: 500;
            color: #333;
            display: flex;
            align-items: center;
            gap: 6px;
        }
        .admin-user-account {
            font-size: 12px;
            color: #999;
            margin-top: 2px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        .admin-user-badge {
            font-size: 10px;
            padding: 1px 6px;
            border-radius: 4px;
            display: inline-block;
        }
        .admin-user-badge.admin { background: #667eea; color: #fff; }
        .admin-user-badge.verified { background: #e8f8f0; color: #07c160; }
        .admin-user-badge.banned { background: #ffecec; color: #ff4757; }

        .admin-user-actions {
            display: flex;
            gap: 6px;
            flex-shrink: 0;
        }
        .admin-action-btn {
            padding: 4px 10px;
            font-size: 12px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            background: #f5f5f5;
            color: #666;
        }
        .admin-action-btn:active { opacity: 0.7; }
        .admin-action-btn.danger { background: #ffecec; color: #ff4757; }
        .admin-action-btn.primary { background: #eef0ff; color: #667eea; }
        .admin-action-btn.success { background: #e8f8f0; color: #07c160; }

        .admin-search {
            padding: 10px 16px;
            background: #fff;
            border-bottom: 1px solid #f5f5f5;
            display: flex;
            gap: 8px;
        }
        .admin-search-input {
            flex: 1;
            height: 34px;
            background: #f5f5f5;
            border: none;
            border-radius: 17px;
            padding: 0 14px;
            font-size: 13px;
            outline: none;
        }
        .admin-search-btn {
            padding: 0 14px;
            height: 34px;
            background: #667eea;
            color: #fff;
            border: none;
            border-radius: 17px;
            font-size: 13px;
            cursor: pointer;
        }

        .admin-load-more {
            text-align: center;
            padding: 14px;
            color: #999;
            font-size: 13px;
            cursor: pointer;
        }
        .admin-load-more:active { opacity: 0.7; }

        .admin-empty {
            text-align: center;
            padding: 40px 20px;
            color: #ccc;
        }
        .admin-empty i { font-size: 40px; margin-bottom: 10px; display: block; }
        .admin-empty p { font-size: 13px; }

        .admin-menu-item {
            display: flex;
            align-items: center;
            padding: 14px 16px;
            border-bottom: 1px solid #f5f5f5;
            cursor: pointer;
        }
        .admin-menu-item:last-child { border-bottom: none; }
        .admin-menu-item:active { background: #f9f9f9; }
        .admin-menu-icon {
            width: 32px; height: 32px;
            border-radius: 8px;
            display: flex; align-items: center; justify-content: center;
            font-size: 16px;
            color: #fff;
            margin-right: 12px;
        }
        .admin-menu-text { flex: 1; font-size: 15px; color: #333; }
        .admin-menu-arrow { color: #ccc; font-size: 14px; }

        /* 下拉菜单 */
        .admin-action-wrap {
            position: relative;
            flex-shrink: 0;
        }
        .admin-more-btn {
            width: 32px;
            height: 32px;
            border: none;
            background: #f5f5f5;
            border-radius: 8px;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 16px;
            color: #666;
        }
        .admin-more-btn:active { opacity: 0.7; }
        .admin-dropdown {
            position: absolute;
            top: 36px;
            right: 0;
            background: #fff;
            border-radius: 10px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.12);
            min-width: 120px;
            overflow: hidden;
            z-index: 20;
            animation: dropdownIn 0.2s ease;
        }
        @keyframes dropdownIn {
            from { opacity: 0; transform: translateY(-6px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .admin-dropdown-item {
            padding: 10px 14px;
            font-size: 13px;
            color: #333;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 6px;
            border-bottom: 1px solid #f5f5f5;
        }
        .admin-dropdown-item:last-child { border-bottom: none; }
        .admin-dropdown-item:active { background: #f9f9f9; }
        .admin-dropdown-item i { font-size: 14px; }
        .admin-dropdown-item.danger { color: #ff4757; }
        .admin-dropdown-item.primary { color: #667eea; }
        .admin-dropdown-item.success { color: #07c160; }

        /* ===== 用户详情页 ===== */
        .ud-profile-card {
            display: flex;
            align-items: center;
            margin: 0 16px 16px;
            padding: 16px;
            background: rgba(255,255,255,0.2);
            backdrop-filter: blur(12px);
            -webkit-backdrop-filter: blur(12px);
            border: 1px solid rgba(255,255,255,0.3);
            border-radius: 16px;
        }
        .ud-avatar {
            width: 56px; height: 56px;
            border-radius: 50%;
            background: rgba(255,255,255,0.2);
            display: flex; align-items: center; justify-content: center;
            font-size: 24px;
            color: #fff;
            overflow: hidden;
            flex-shrink: 0;
            margin-right: 14px;
            border: 2px solid rgba(255,255,255,0.3);
        }
        .ud-avatar img { width: 100%; height: 100%; object-fit: cover; }
        .ud-profile-info { flex: 1; min-width: 0; }
        .ud-profile-name {
            font-size: 16px;
            font-weight: 600;
            color: #fff;
            display: flex;
            align-items: center;
            gap: 6px;
            flex-wrap: wrap;
        }
        .ud-profile-account {
            font-size: 13px;
            color: rgba(255,255,255,0.6);
            margin-top: 4px;
        }
        .ud-profile-email {
            font-size: 12px;
            color: rgba(255,255,255,0.5);
            margin-top: 2px;
        }
        .ud-stats {
            display: flex;
            margin: 0 16px 16px;
            background: rgba(255,255,255,0.2);
            backdrop-filter: blur(12px);
            -webkit-backdrop-filter: blur(12px);
            border: 1px solid rgba(255,255,255,0.3);
            border-radius: 16px;
            padding: 16px 0;
        }
        .ud-stat-item {
            flex: 1;
            text-align: center;
        }
        .ud-stat-item + .ud-stat-item {
            border-left: 1px solid rgba(255,255,255,0.15);
        }
        .ud-stat-num {
            font-size: 22px;
            font-weight: 700;
            color: #fff;
        }
        .ud-stat-label {
            font-size: 12px;
            color: rgba(255,255,255,0.55);
            margin-top: 4px;
        }
        .ud-section-title {
            font-size: 13px;
            font-weight: 600;
            color: rgba(255,255,255,0.7);
            margin: 16px 20px 8px;
        }
        .ud-info-group {
            margin: 0 16px 8px;
            background: rgba(255,255,255,0.2);
            backdrop-filter: blur(12px);
            -webkit-backdrop-filter: blur(12px);
            border: 1px solid rgba(255,255,255,0.3);
            border-radius: 16px;
            overflow: hidden;
        }
        .ud-info-row {
            display: flex;
            align-items: flex-start;
            padding: 12px 16px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        .ud-info-row:last-child { border-bottom: none; }
        .ud-info-label {
            font-size: 14px;
            color: rgba(255,255,255,0.55);
            width: 100px;
            flex-shrink: 0;
        }
        .ud-info-value {
            font-size: 14px;
            color: #fff;
            flex: 1;
            word-break: break-all;
        }
        .ud-moment-list {
            margin: 0 16px 30px;
        }
        .ud-moment-item {
            background: rgba(255,255,255,0.2);
            backdrop-filter: blur(12px);
            -webkit-backdrop-filter: blur(12px);
            border: 1px solid rgba(255,255,255,0.3);
            border-radius: 14px;
            padding: 14px 16px;
            margin-bottom: 10px;
        }
        .ud-moment-content {
            font-size: 14px;
            color: rgba(255,255,255,0.9);
            line-height: 1.6;
            margin-bottom: 8px;
        }
        .ud-moment-images {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 4px;
            margin-bottom: 8px;
        }
        .ud-moment-img {
            aspect-ratio: 1;
            border-radius: 8px;
            overflow: hidden;
        }
        .ud-moment-img img { width: 100%; height: 100%; object-fit: cover; }
        .ud-moment-meta {
            display: flex;
            align-items: center;
            gap: 16px;
            font-size: 12px;
            color: rgba(255,255,255,0.5);
            padding-top: 8px;
            border-top: 1px solid rgba(255,255,255,0.1);
        }
        .ud-moment-meta i { margin-right: 3px; }
        .ud-moment-time { margin-left: auto; }
        .ud-moment-empty {
            text-align: center;
            padding: 40px 20px;
            color: rgba(255,255,255,0.4);
        }
        .ud-moment-empty i { font-size: 40px; display: block; margin-bottom: 10px; }
        .ud-moment-empty p { font-size: 13px; }

        /* ===== 信息页面 ===== */
        .info-panel {
            width: 100%;
            max-width: 480px;
            height: 100%;
            background: #FDB59F;
            display: flex;
            flex-direction: column;
            animation: slideDown 0.3s ease;
        }
        .info-content {
            flex: 1;
            overflow-y: auto;
            -webkit-overflow-scrolling: touch;
            padding: 20px 20px 40px;
        }
        .info-content::-webkit-scrollbar { width: 0; }
        .info-card {
            background: rgba(255,255,255,0.15);
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            border: 1px solid rgba(255,255,255,0.25);
            border-radius: 16px;
            padding: 24px 20px;
            margin-bottom: 16px;
        }
        .info-logo {
            text-align: center;
            margin-bottom: 20px;
        }
        .info-logo-icon {
            width: 72px; height: 72px;
            margin: 0 auto 12px;
            background: rgba(255,255,255,0.2);
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            border: 1px solid rgba(255,255,255,0.3);
            border-radius: 22px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 36px;
            color: #fff;
        }
        .info-logo h2 {
            font-size: 20px;
            color: #fff;
            margin-bottom: 4px;
        }
        .info-logo p {
            font-size: 13px;
            color: rgba(255,255,255,0.7);
        }
        .info-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 12px 0;
            border-bottom: 1px solid rgba(255,255,255,0.15);
        }
        .info-row:last-child { border-bottom: none; }
        .info-row-label {
            font-size: 14px;
            color: rgba(255,255,255,0.6);
        }
        .info-row-value {
            font-size: 14px;
            color: #fff;
            font-weight: 500;
        }
        .info-section-title {
            font-size: 15px;
            font-weight: 600;
            color: #fff;
            margin: 20px 0 10px;
            display: flex;
            align-items: center;
            gap: 6px;
        }
        .info-section-title i { color: rgba(255,255,255,0.9); font-size: 18px; }
        .info-text {
            font-size: 14px;
            color: rgba(255,255,255,0.75);
            line-height: 1.8;
            margin-bottom: 8px;
        }
        .info-text strong { color: #fff; }
        .info-text .highlight { color: #fff; font-weight: 500; }
        .info-list {
            padding-left: 0;
            list-style: none;
        }
        .info-list li {
            font-size: 14px;
            color: rgba(255,255,255,0.75);
            line-height: 1.8;
            padding: 6px 0;
            padding-left: 20px;
            position: relative;
        }
        .info-list li::before {
            content: '';
            position: absolute;
            left: 6px;
            top: 14px;
            width: 5px;
            height: 5px;
            border-radius: 50%;
            background: rgba(255,255,255,0.6);
        }
        .info-step {
            display: flex;
            gap: 12px;
            margin-bottom: 16px;
        }
        .info-step-num {
            width: 24px; height: 24px;
            border-radius: 50%;
            background: rgba(255,255,255,0.25);
            color: #fff;
            font-size: 12px;
            font-weight: 600;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-shrink: 0;
        }
        .info-step-content {
            flex: 1;
        }
        .info-step-title {
            font-size: 14px;
            font-weight: 500;
            color: #fff;
            margin-bottom: 4px;
        }
        .info-step-desc {
            font-size: 13px;
            color: rgba(255,255,255,0.65);
            line-height: 1.6;
        }
        .info-footer {
            text-align: center;
            padding: 20px 0;
            color: rgba(255,255,255,0.8);
            font-size: 12px;
        }
        .info-footer p { margin: 4px 0; }

        /* ===== 加载动画 ===== */
        .loading-mask {
            position: fixed;
            top: 0; left: 0; right: 0; bottom: 0;
            background: rgba(255,255,255,0.8);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 9999;
        }
        .loading-spinner {
            width: 40px; height: 40px;
            border: 3px solid #ffe4ec;
            border-top-color: #ff6b9d;
            border-radius: 50%;
            animation: spin 0.8s linear infinite;
        }
        @keyframes spin { to { transform: rotate(360deg); } }

        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: #ccc;
        }
        .empty-state i { font-size: 60px; margin-bottom: 12px; display: block; }
        .empty-state p { font-size: 14px; }

        /* Toast */
        .toast {
            position: fixed;
            top: 50%; left: 50%;
            transform: translate(-50%, -50%);
            background: rgba(0,0,0,0.75);
            color: #fff;
            padding: 12px 20px;
            border-radius: 10px;
            font-size: 14px;
            z-index: 10000;
            animation: toastIn 0.3s;
            max-width: 80%;
            text-align: center;
        }
        @keyframes toastIn { from { opacity: 0; transform: translate(-50%, -40%); } to { opacity: 1; transform: translate(-50%, -50%); } }

        /* ===== 添加好友弹层 ===== */
        .add-friend-popup {
            position: fixed;
            top: 0; left: 0; right: 0; bottom: 0;
            background: rgba(0,0,0,0.5);
            z-index: 200;
            display: flex;
            align-items: flex-start;
            justify-content: center;
            animation: fadeIn 0.25s ease;
        }
        @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
        .add-friend-panel {
            width: 100%;
            max-width: 480px;
            height: 100%;
            background: #fff;
            display: flex;
            flex-direction: column;
            animation: slideDown 0.3s ease;
        }
        @keyframes slideDown { from { transform: translateY(-20px); opacity: 0; } to { transform: translateY(0); opacity: 1; } }
        .add-friend-header {
            display: flex;
            align-items: center;
            padding: 10px 12px;
            background: #fff;
            border-bottom: 1px solid #f0f0f0;
            gap: 10px;
        }
        .af-back {
            width: 32px; height: 32px;
            display: flex; align-items: center; justify-content: center;
            font-size: 22px;
            color: #333;
            cursor: pointer;
        }
        .af-search {
            flex: 1;
            height: 36px;
            background: #f5f5f5;
            border-radius: 18px;
            display: flex;
            align-items: center;
            padding: 0 14px;
        }
        .af-search i { color: #bbb; margin-right: 8px; font-size: 16px; }
        .af-search input {
            flex: 1;
            border: none;
            background: transparent;
            outline: none;
            font-size: 14px;
        }
        .af-cancel {
            color: #ff6b9d;
            font-size: 14px;
            cursor: pointer;
            padding: 0 4px;
        }
        .add-friend-results {
            flex: 1;
            overflow-y: auto;
            -webkit-overflow-scrolling: touch;
        }
        .add-friend-results::-webkit-scrollbar { width: 0; }
        .af-empty {
            text-align: center;
            padding: 80px 20px;
            color: #ccc;
        }
        .af-empty i { font-size: 50px; margin-bottom: 12px; display: block; }
        .af-empty p { font-size: 14px; }
        .af-user-item {
            display: flex;
            align-items: center;
            padding: 12px 16px;
            border-bottom: 1px solid #f5f5f5;
        }
        .af-avatar {
            width: 44px; height: 44px;
            border-radius: 12px;
            margin-right: 12px;
            background: linear-gradient(135deg, #a8edea, #fed6e3);
            display: flex; align-items: center; justify-content: center;
            font-size: 18px; color: #fff;
            flex-shrink: 0;
            overflow: hidden;
        }
        .af-avatar img { width: 100%; height: 100%; object-fit: cover; }
        .af-info { flex: 1; min-width: 0; }
        .af-name { font-size: 15px; color: #333; font-weight: 500; }
        .af-sign { font-size: 12px; color: #bbb; margin-top: 3px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
        .af-add-btn {
            background: linear-gradient(135deg, #ff9a9e 0%, #ff6b9d 100%);
            color: #fff;
            border: none;
            padding: 6px 14px;
            border-radius: 14px;
            font-size: 13px;
            cursor: pointer;
            flex-shrink: 0;
            display: flex;
            align-items: center;
            gap: 4px;
        }
        .af-add-btn:active { opacity: 0.8; }

        /* 新朋友入口 */
        .new-friend-entry {
            display: flex;
            align-items: center;
            padding: 14px 16px;
            background: #fff;
            border-bottom: 1px solid #f5f5f5;
            cursor: pointer;
        }
        .new-friend-entry:active { background: #f9f9f9; }
        .nf-icon {
            width: 40px; height: 40px;
            border-radius: 12px;
            background: linear-gradient(135deg, #ff9a9e, #ff6b9d);
            display: flex; align-items: center; justify-content: center;
            font-size: 18px; color: #fff;
            margin-right: 12px;
            flex-shrink: 0;
        }
        .nf-text { flex: 1; font-size: 15px; color: #333; }
        .nf-badge {
            min-width: 18px; height: 18px;
            background: #ff4757;
            color: #fff;
            font-size: 11px;
            border-radius: 9px;
            display: flex; align-items: center; justify-content: center;
            padding: 0 5px;
            margin-right: 6px;
        }
        .nf-arrow { color: #ccc; font-size: 18px; }

        /* 好友申请项 */
        .request-item {
            display: flex;
            align-items: center;
            padding: 12px 16px;
            border-bottom: 1px solid #f5f5f5;
        }
        .request-actions {
            display: flex;
            gap: 8px;
            flex-shrink: 0;
        }
        .req-btn {
            padding: 6px 12px;
            border-radius: 14px;
            font-size: 13px;
            cursor: pointer;
            border: none;
            display: flex;
            align-items: center;
            gap: 2px;
        }
        .req-btn.accept {
            background: linear-gradient(135deg, #ff9a9e 0%, #ff6b9d 100%);
            color: #fff;
        }
        .req-btn.reject {
            background: #f5f5f5;
            color: #999;
        }
        .req-btn:active { opacity: 0.8; }
    </style>
</head>
<body>
    <div id="app">
        <!-- 加载遮罩 -->
        <div class="loading-mask" v-if="loading">
            <div class="loading-spinner"></div>
        </div>

        <!-- Toast提示 -->
        <div class="toast" v-if="toast.show" v-html="toast.msg"></div>

        <!-- 添加好友弹层 -->
        <div class="add-friend-popup" v-if="showAddFriend" @click.self="showAddFriend = false">
            <div class="add-friend-panel">
                <div class="add-friend-header">
                    <div class="af-back" @click="showAddFriend = false"><i class="ri-arrow-left-line"></i></div>
                    <div class="af-search">
                        <i class="ri-search-line"></i>
                        <input type="text" v-model="addFriendKeyword" placeholder="搜索用户昵称/用户名" @input="searchAddFriend" autofocus>
                    </div>
                    <div class="af-cancel" @click="showAddFriend = false">取消</div>
                </div>
                <div class="add-friend-results">
                    <div class="af-empty" v-if="addFriendResults.length === 0 && !addFriendKeyword.trim()">
                        <i class="ri-user-add-line"></i>
                        <p>输入关键词搜索用户</p>
                    </div>
                    <div class="af-empty" v-if="addFriendResults.length === 0 && addFriendKeyword.trim()">
                        <i class="ri-search-line"></i>
                        <p>没有找到相关用户</p>
                    </div>
                    <div class="af-user-item" v-for="u in addFriendResults" :key="u.id">
                        <div class="af-avatar">
                            <img v-if="u.avatar" :src="u.avatar">
                            <i v-else class="ri-user-3-fill"></i>
                        </div>
                        <div class="af-info">
                            <div class="af-name">{{ u.nickname }}</div>
                            <div class="af-sign">{{ u.signature || '这个人很懒，什么都没留下' }}</div>
                        </div>
                        <button class="af-add-btn" @click="doAddFriend(u)">
                            <i class="ri-user-add-line"></i> 添加
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <!-- 好友申请列表弹层 -->
        <div class="add-friend-popup" v-if="showFriendRequests" @click.self="showFriendRequests = false">
            <div class="add-friend-panel">
                <div class="add-friend-header">
                    <div class="af-back" @click="showFriendRequests = false"><i class="ri-arrow-left-line"></i></div>
                    <div style="flex:1;text-align:center;font-size:16px;font-weight:600;color:#333;">新朋友</div>
                    <div class="af-cancel" style="visibility:hidden">取消</div>
                </div>
                <div class="add-friend-results">
                    <div class="af-empty" v-if="friendRequests.length === 0">
                        <i class="ri-user-heart-line"></i>
                        <p>暂无好友申请</p>
                    </div>
                    <div class="request-item" v-for="req in friendRequests" :key="req.id">
                        <div class="af-avatar">
                            <img v-if="req.avatar" :src="req.avatar">
                            <i v-else class="ri-user-3-fill"></i>
                        </div>
                        <div class="af-info">
                            <div class="af-name">{{ req.nickname }}</div>
                            <div class="af-sign">{{ req.signature || '请求添加你为好友' }}</div>
                        </div>
                        <div class="request-actions">
                            <button class="req-btn accept" @click="handleRequest(req, 'accept')">
                                <i class="ri-check-line"></i> 接受
                            </button>
                            <button class="req-btn reject" @click="handleRequest(req, 'reject')">
                                <i class="ri-close-line"></i>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- 编辑资料弹层 -->
        <div class="edit-profile-popup" v-if="showEditProfile" @click.self="closeEditProfile">
            <div class="edit-profile-panel">
                <div class="ep-header">
                    <div class="ep-back" @click="closeEditProfile"><i class="ri-arrow-left-line"></i></div>
                    <div class="ep-title">编辑资料</div>
                    <div class="ep-save" @click="saveProfile" :disabled="savingProfile">
                        {{ savingProfile ? '保存中...' : '保存' }}
                    </div>
                </div>
                <div class="ep-content">
                    <div class="ep-section">
                        <div class="ep-item">
                            <div class="ep-label">头像</div>
                            <div class="ep-avatar-wrap">
                                <div class="ep-avatar" @click="triggerAvatarUpload">
                                    <img v-if="editForm.avatar" :src="editForm.avatar">
                                    <i v-else class="ri-user-3-fill"></i>
                                </div>
                            </div>
                            <input type="file" ref="avatarInput" accept="image/*" style="display:none" @change="handleAvatarUpload">
                        </div>
                        <div class="ep-item">
                            <div class="ep-label">昵称</div>
                            <input type="text" class="ep-input" v-model="editForm.nickname" placeholder="请输入昵称" maxlength="20">
                        </div>
                        <div class="ep-item">
                            <div class="ep-label">账号</div>
                            <div class="ep-value">{{ currentUser.username }}</div>
                        </div>
                        <div class="ep-item">
                            <div class="ep-label">邮箱</div>
                            <div class="ep-value">{{ currentUser.email }}</div>
                        </div>
                    </div>

                    <div class="ep-section-title">修改密码</div>
                    <div class="ep-section">
                        <div class="ep-item">
                            <div class="ep-label">旧密码</div>
                            <input type="password" class="ep-input" v-model="editForm.old_password" placeholder="请输入旧密码">
                        </div>
                        <div class="ep-item">
                            <div class="ep-label">新密码</div>
                            <input type="password" class="ep-input" v-model="editForm.new_password" placeholder="请输入新密码">
                        </div>
                        <div class="ep-item">
                            <div class="ep-label">确认密码</div>
                            <input type="password" class="ep-input" v-model="editForm.confirm_password" placeholder="请再次输入新密码">
                        </div>
                    </div>
                    <div class="ep-tip">不修改密码请留空，新密码长度不少于6位</div>
                </div>
            </div>
        </div>

        <!-- 实名认证弹层 -->
        <div class="edit-profile-popup" v-if="showVerifyPopup" @click.self="closeVerifyPopup">
            <div class="edit-profile-panel">
                <div class="ep-header">
                    <div class="ep-back" @click="closeVerifyPopup"><i class="ri-arrow-left-line"></i></div>
                    <div class="ep-title">实名认证</div>
                    <div class="ep-save" @click="submitVerify" :disabled="verifying">
                        {{ verifying ? '提交中...' : '提交' }}
                    </div>
                </div>
                <div class="ep-content">
                    <div class="ep-tip warn" v-if="currentUser.is_verified">
                        <i class="ri-shield-check-fill"></i> 您已完成实名认证
                    </div>
                    <div class="ep-section" v-if="currentUser.is_verified">
                        <div class="ep-item">
                            <div class="ep-label">真实姓名</div>
                            <div class="ep-value">{{ currentUser.real_name }}</div>
                        </div>
                        <div class="ep-item">
                            <div class="ep-label">身份证号</div>
                            <div class="ep-value">{{ currentUser.id_card_masked }}</div>
                        </div>
                        <div class="ep-item">
                            <div class="ep-label">绑定邮箱</div>
                            <div class="ep-value">{{ currentUser.email }}</div>
                        </div>
                    </div>

                    <template v-else>
                        <div class="ep-tip">
                            实名认证后将绑定您的账号邮箱，请确保信息真实有效
                        </div>
                        <div class="ep-section">
                            <div class="ep-item">
                                <div class="ep-label">真实姓名</div>
                                <input type="text" class="ep-input" v-model="verifyForm.real_name" placeholder="请输入真实姓名">
                            </div>
                            <div class="ep-item">
                                <div class="ep-label">身份证号</div>
                                <input type="text" class="ep-input" v-model="verifyForm.id_card" placeholder="请输入18位身份证号" maxlength="18">
                            </div>
                            <div class="ep-item">
                                <div class="ep-label">绑定邮箱</div>
                                <div class="ep-value">{{ currentUser.email }}</div>
                            </div>
                        </div>
                        <div class="ep-tip warn">
                            <i class="ri-information-line"></i> 为响应国家的法律法规，本程序实行实名认证系统，本实名认证功能已接入国家信息人口备案系统， 实名认证成功后不可修改，请谨慎填写。
                        </div>
                    </template>
                </div>
            </div>
        </div>

        <!-- 管理后台弹层 -->
        <div class="edit-profile-popup" v-if="showAdminPanel" @click.self="closeAdminPanel">
            <div class="admin-panel">
                <div class="admin-header">
                    <div class="admin-back" @click="closeAdminPanel"><i class="ri-arrow-left-line"></i></div>
                    <div class="admin-title">管理后台</div>
                    <div style="width:32px"></div>
                </div>
                <div class="admin-content" @click="closeAdminMenu">
                    <!-- 数据统计 -->
                    <div class="admin-stats">
                        <div class="admin-stat-card primary">
                            <div class="admin-stat-num">{{ adminStats.total_users || 0 }}</div>
                            <div class="admin-stat-label">用户总数</div>
                        </div>
                        <div class="admin-stat-card success">
                            <div class="admin-stat-num">{{ adminStats.today_users || 0 }}</div>
                            <div class="admin-stat-label">今日新增</div>
                        </div>
                        <div class="admin-stat-card warning">
                            <div class="admin-stat-num">{{ adminStats.verified_users || 0 }}</div>
                            <div class="admin-stat-label">已认证</div>
                        </div>
                        <div class="admin-stat-card danger">
                            <div class="admin-stat-num">{{ adminStats.banned_users || 0 }}</div>
                            <div class="admin-stat-label">已禁用</div>
                        </div>
                        <div class="admin-stat-card primary">
                            <div class="admin-stat-num">{{ adminStats.total_messages || 0 }}</div>
                            <div class="admin-stat-label">消息总数</div>
                        </div>
                        <div class="admin-stat-card success">
                            <div class="admin-stat-num">{{ adminStats.today_messages || 0 }}</div>
                            <div class="admin-stat-label">今日消息</div>
                        </div>
                    </div>

                    <!-- 用户管理 -->
                    <div class="admin-section">
                        <div class="admin-section-title">
                            <span><i class="ri-user-settings-fill"></i>用户管理</span>
                        </div>
                        <div class="admin-search">
                            <input type="text" class="admin-search-input" v-model="adminSearchKw" placeholder="搜索用户名/昵称/邮箱" @keyup.enter="searchAdminUsers">
                            <button class="admin-search-btn" @click="searchAdminUsers">搜索</button>
                        </div>
                        <div v-if="adminUserList.length === 0 && !adminLoading">
                            <div class="admin-empty">
                                <i class="ri-user-search-line"></i>
                                <p>暂无用户数据</p>
                            </div>
                        </div>
                        <div class="admin-user-item" v-for="u in adminUserList" :key="u.id">
                            <div class="admin-user-avatar">
                                <img v-if="u.avatar" :src="u.avatar">
                                <i v-else class="ri-user-3-fill"></i>
                            </div>
                            <div class="admin-user-info">
                                <div class="admin-user-name">
                                    {{ u.nickname }}
                                    <span class="admin-user-badge admin" v-if="u.role == 1">管理员</span>
                                    <span class="admin-user-badge verified" v-if="u.is_verified == 1">已认证</span>
                                    <span class="admin-user-badge banned" v-if="u.status == 0">已禁用</span>
                                </div>
                                <div class="admin-user-account">{{ u.username }} · {{ u.email }}</div>
                            </div>
                            <div class="admin-user-actions">
                                <div class="admin-action-wrap" @click.stop>
                                    <button class="admin-more-btn" @click="toggleAdminMenu(u.id)">
                                        <i class="ri-more-2-fill"></i>
                                    </button>
                                    <div class="admin-dropdown" v-if="expandedMenuId === u.id">
                                        <div class="admin-dropdown-item" @click.stop="openUserDetail(u.id)">
                                            <i class="ri-user-search-line"></i> 查看详情
                                        </div>
                                        <div class="admin-dropdown-item primary" v-if="u.role != 1" @click.stop="adminToggleUser(u)">
                                            <i :class="u.status == 1 ? 'ri-forbid-line' : 'ri-checkbox-circle-line'"></i>
                                            {{ u.status == 1 ? '禁用用户' : '启用用户' }}
                                        </div>
                                        <div class="admin-dropdown-item success" v-if="u.role != 1" @click.stop="adminResetPwd(u)">
                                            <i class="ri-lock-unlock-line"></i> 重置密码
                                        </div>
                                        <div class="admin-dropdown-item" v-if="u.role != 1" @click.stop="adminSetRole(u, 1)">
                                            <i class="ri-shield-user-line"></i> 设为管理员
                                        </div>
                                        <div class="admin-dropdown-item" v-if="u.role == 1 && u.id != currentUser.id" @click.stop="adminSetRole(u, 0)">
                                            <i class="ri-shield-user-line"></i> 取消管理员
                                        </div>
                                        <div class="admin-dropdown-item danger" v-if="u.role != 1" @click.stop="adminDeleteUser(u)">
                                            <i class="ri-delete-bin-line"></i> 删除用户
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div v-if="adminLoading" style="text-align:center;padding:20px;color:#999;font-size:13px;">加载中...</div>
                        <div class="admin-load-more" v-if="adminHasMore && !adminLoading" @click="loadMoreAdminUsers">加载更多</div>
                    </div>
                </div>
            </div>
        </div>

        <!-- 用户详情弹层（管理员查看用户全部信息） -->
        <div class="edit-profile-popup" v-if="showUserDetail" @click.self="closeUserDetail">
            <div class="admin-panel">
                <div class="admin-header">
                    <div class="admin-back" @click="closeUserDetail"><i class="ri-arrow-left-line"></i></div>
                    <div class="admin-title">用户详情</div>
                    <div class="admin-back" style="visibility:hidden"><i class="ri-arrow-left-line"></i></div>
                </div>
                <div class="admin-content" v-if="userDetailLoading" style="display:flex;align-items:center;justify-content:center;">
                    <div style="color:#fff;font-size:14px;">加载中...</div>
                </div>
                <div class="admin-content" v-else-if="userDetailData">
                    <!-- 用户基本信息卡片 -->
                    <div class="ud-profile-card">
                        <div class="ud-avatar">
                            <img v-if="userDetailData.user.avatar" :src="userDetailData.user.avatar">
                            <i v-else class="ri-user-3-fill"></i>
                        </div>
                        <div class="ud-profile-info">
                            <div class="ud-profile-name">
                                {{ userDetailData.user.nickname || userDetailData.user.username }}
                                <span class="admin-user-badge admin" v-if="userDetailData.user.role == 1">管理员</span>
                                <span class="admin-user-badge verified" v-if="userDetailData.user.is_verified == 1">已认证</span>
                                <span class="admin-user-badge banned" v-if="userDetailData.user.status == 0">已禁用</span>
                            </div>
                            <div class="ud-profile-account">@{{ userDetailData.user.username }}</div>
                            <div class="ud-profile-email">{{ userDetailData.user.email }}</div>
                        </div>
                    </div>

                    <!-- 统计数据 -->
                    <div class="ud-stats">
                        <div class="ud-stat-item">
                            <div class="ud-stat-num">{{ userDetailData.friend_count }}</div>
                            <div class="ud-stat-label">好友</div>
                        </div>
                        <div class="ud-stat-item">
                            <div class="ud-stat-num">{{ userDetailData.msg_count }}</div>
                            <div class="ud-stat-label">消息</div>
                        </div>
                        <div class="ud-stat-item">
                            <div class="ud-stat-num">{{ userDetailData.moment_count }}</div>
                            <div class="ud-stat-label">动态</div>
                        </div>
                    </div>

                    <!-- 详细信息 -->
                    <div class="ud-section-title">基本信息</div>
                    <div class="ud-info-group">
                        <div class="ud-info-row">
                            <span class="ud-info-label">用户名</span>
                            <span class="ud-info-value">{{ userDetailData.user.username }}</span>
                        </div>
                        <div class="ud-info-row">
                            <span class="ud-info-label">昵称</span>
                            <span class="ud-info-value">{{ userDetailData.user.nickname || '未设置' }}</span>
                        </div>
                        <div class="ud-info-row">
                            <span class="ud-info-label">邮箱</span>
                            <span class="ud-info-value">{{ userDetailData.user.email }}</span>
                        </div>
                        <div class="ud-info-row">
                            <span class="ud-info-label">个性签名</span>
                            <span class="ud-info-value">{{ userDetailData.user.signature || '未设置' }}</span>
                        </div>
                        <div class="ud-info-row">
                            <span class="ud-info-label">注册时间</span>
                            <span class="ud-info-value">{{ userDetailData.user.created_at }}</span>
                        </div>
                    </div>

                    <!-- 实名认证信息 -->
                    <div class="ud-section-title">实名认证</div>
                    <div class="ud-info-group">
                        <div class="ud-info-row">
                            <span class="ud-info-label">认证状态</span>
                            <span class="ud-info-value">
                                <span v-if="userDetailData.user.is_verified == 1" style="color:#07c160">已认证</span>
                                <span v-else style="color:#999">未认证</span>
                            </span>
                        </div>
                        <div class="ud-info-row" v-if="userDetailData.user.is_verified == 1">
                            <span class="ud-info-label">真实姓名</span>
                            <span class="ud-info-value">{{ userDetailData.user.real_name }}</span>
                        </div>
                        <div class="ud-info-row" v-if="userDetailData.user.is_verified == 1">
                            <span class="ud-info-label">身份证号</span>
                            <span class="ud-info-value">{{ userDetailData.user.id_card }}</span>
                        </div>
                    </div>

                    <!-- 隐私设置 -->
                    <div class="ud-section-title">隐私设置</div>
                    <div class="ud-info-group">
                        <div class="ud-info-row">
                            <span class="ud-info-label">朋友圈权限</span>
                            <span class="ud-info-value">{{ ['所有人可见', '仅好友可见', '仅自己可见'][userDetailData.user.moment_visible] }}</span>
                        </div>
                        <div class="ud-info-row">
                            <span class="ud-info-label">允许被搜索</span>
                            <span class="ud-info-value">{{ userDetailData.user.allow_search ? '是' : '否' }}</span>
                        </div>
                        <div class="ud-info-row">
                            <span class="ud-info-label">允许被添加好友</span>
                            <span class="ud-info-value">{{ userDetailData.user.allow_add_friend ? '是' : '否' }}</span>
                        </div>
                        <div class="ud-info-row">
                            <span class="ud-info-label">发现页展示朋友圈</span>
                            <span class="ud-info-value">{{ userDetailData.user.show_moment_in_discover ? '是' : '否' }}</span>
                        </div>
                    </div>

                    <!-- 朋友圈动态 -->
                    <div class="ud-section-title">朋友圈动态 ({{ userDetailData.moment_count }})</div>
                    <div class="ud-moment-list" v-if="userDetailData.moments && userDetailData.moments.length > 0">
                        <div class="ud-moment-item" v-for="m in userDetailData.moments" :key="m.id">
                            <div class="ud-moment-content" v-if="m.content">{{ m.content }}</div>
                            <div class="ud-moment-images" v-if="m.images && m.images.length > 0">
                                <div class="ud-moment-img" v-for="(img, i) in m.images" :key="i">
                                    <img :src="img" @error="$event.target.style.display='none'">
                                </div>
                            </div>
                            <div class="ud-moment-meta">
                                <span><i class="ri-heart-line"></i> {{ m.like_count }}</span>
                                <span><i class="ri-chat-3-line"></i> {{ m.comment_count }}</span>
                                <span class="ud-moment-time">{{ m.created_at }}</span>
                            </div>
                        </div>
                    </div>
                    <div class="ud-moment-empty" v-else>
                        <i class="ri-chat-4-line"></i>
                        <p>暂无朋友圈动态</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- 信息页面弹层（关于简讯/隐私政策/用户手册） -->
        <div class="edit-profile-popup" v-if="showInfoPage" @click.self="closeInfoPage">
            <div class="info-panel">
                <!-- 头部导航 -->
                <div class="ep-header">
                    <div class="ep-back" @click="closeInfoPage"><i class="ri-arrow-left-line"></i></div>
                    <div class="ep-title">{{ infoPageTitle }}</div>
                    <div style="width:32px"></div>
                </div>
                <div class="info-content">
                    <!-- 关于简讯 -->
                    <template v-if="infoPageType === 'about'">
                        <div class="info-card">
                            <div class="info-logo">
                                <div class="info-logo-icon"><i class="ri-chat-smile-3-fill"></i></div>
                                <h2>简讯</h2>
                                <p>版本 1.0.0</p>
                            </div>
                            <div class="info-row">
                                <span class="info-row-label">应用名称</span>
                                <span class="info-row-value">简讯</span>
                            </div>
                            <div class="info-row">
                                <span class="info-row-label">开发者</span>
                                <span class="info-row-value">不见桃花不见秋</span>
                            </div>
                            <div class="info-row">
                                <span class="info-row-label">开发时间</span>
                                <span class="info-row-value">2026年9月3日</span>
                            </div>
                            <div class="info-row">
                                <span class="info-row-label">技术栈</span>
                                <span class="info-row-value">后端PHP 8.0+ + MySQL</span>
                            </div>
                            <div class="info-row">
                                <span class="info-row-label">适用平台</span>
                                <span class="info-row-value">移动端</span>
                            </div>
                        </div>
                        <div class="info-card">
                            <div class="info-section-title"><i class="ri-information-line"></i>应用简介</div>
                            <p class="info-text">简讯是一款轻量级即时通讯应用，采用单页SPA架构，支持实时消息收发、图片视频分享、好友管理等功能。界面采用甜美唯美设计风格，操作简洁直观。</p>
                        </div>
                        <div class="info-card">
                            <div class="info-section-title"><i class="ri-star-line"></i>核心功能</div>
                            <ul class="info-list">
                                <li>用户注册、登录、密码找回</li>
                                <li>实时聊天与消息轮询</li>
                                <li>图片和视频发送（最大1000MB）</li>
                                <li>好友搜索、添加与管理</li>
                                <li>实名认证系统</li>
                                <li>个人资料编辑与头像上传</li>
                                <li>管理员后台用户管理</li>
                            </ul>
                        </div>
                        <div class="info-card">
                            <div class="info-section-title"><i class="ri-copyright-line"></i>版权信息</div>
                            <p class="info-text">本应用由 <strong>不见桃花不见秋</strong> 独立开发完成。</p>
                            <p class="info-text">开发起始日期：<strong>2026年9月3日</strong></p>
                            <p class="info-text">未经授权不得用于商业用途。</p>
                        </div>
                        <div class="info-footer">
                            <p>简讯 v1.0.0</p>
                            <p>Made with care by 不见桃花不见秋</p>
                            <p>© 2026 All Rights Reserved</p>
                        </div>
                    </template>

                    <!-- 隐私政策 -->
                    <template v-if="infoPageType === 'privacy'">
                        <div class="info-card">
                            <div class="info-section-title"><i class="ri-shield-keyhole-line"></i>隐私政策</div>
                            <p class="info-text">简讯（以下简称"本应用"）非常重视用户隐私保护。本隐私政策说明了我们如何收集、使用和保护您的个人信息。</p>
                            <p class="info-text" style="color:#bbb;font-size:12px;">更新日期：2026年9月3日</p>
                        </div>
                        <div class="info-card">
                            <div class="info-section-title"><i class="ri-database-2-line"></i>一、信息收集</div>
                            <p class="info-text">本应用在您使用过程中会收集以下信息：</p>
                            <ul class="info-list">
                                <li><strong>账号信息</strong>：用户名、昵称、邮箱地址</li>
                                <li><strong>认证信息</strong>：真实姓名、身份证号（仅用于实名认证）</li>
                                <li><strong>消息内容</strong>：您发送的文字、图片、视频等</li>
                                <li><strong>设备信息</strong>：浏览器类型、操作系统信息</li>
                            </ul>
                        </div>
                        <div class="info-card">
                            <div class="info-section-title"><i class="ri-tools-line"></i>二、信息使用</div>
                            <p class="info-text">收集的信息将用于以下目的：</p>
                            <ul class="info-list">
                                <li>提供即时通讯服务，包括消息收发和好友管理</li>
                                <li>验证用户身份，保障账号安全</li>
                                <li>实名认证，满足相关法律法规要求</li>
                                <li>改善和优化应用功能与用户体验</li>
                                <li>防止违规内容和恶意行为</li>
                            </ul>
                        </div>
                        <div class="info-card">
                            <div class="info-section-title"><i class="ri-lock-2-line"></i>三、信息保护</div>
                            <p class="info-text">我们采取以下措施保护您的信息安全：</p>
                            <ul class="info-list">
                                <li>用户密码使用 <strong>bcrypt</strong> 加密存储，不可逆</li>
                                <li>身份证号在数据库中加密存储</li>
                                <li>会话采用 PHP Session 机制，防止会话劫持</li>
                                <li>文件上传进行类型和大小校验，防止恶意文件</li>
                                <li>管理员操作需身份验证，普通用户无权访问后台</li>
                            </ul>
                        </div>
                        <div class="info-card">
                            <div class="info-section-title"><i class="ri-share-forward-line"></i>四、信息共享</div>
                            <p class="info-text">本应用 <strong>不会向任何第三方共享、出售或出租</strong> 您的个人信息。除以下情况外：</p>
                            <ul class="info-list">
                                <li>获得您的明确同意</li>
                                <li>法律法规要求或司法机关强制要求</li>
                                <li>为维护本应用的合法权益（如防止欺诈）</li>
                            </ul>
                        </div>
                        <div class="info-card">
                            <div class="info-section-title"><i class="ri-delete-bin-line"></i>五、数据删除</div>
                            <p class="info-text">在以下情况下，您的数据将被删除：</p>
                            <ul class="info-list">
                                <li>您主动删除聊天记录时，相关消息和媒体文件将被永久删除</li>
                                <li>删除好友时，双方聊天记录和媒体文件同步删除</li>
                                <li>管理员删除用户时，该用户的所有数据、文件、好友关系将被彻底清除</li>
                            </ul>
                        </div>
                        <div class="info-card">
                            <div class="info-section-title"><i class="ri-user-settings-line"></i>六、用户权利</div>
                            <p class="info-text">您拥有以下权利：</p>
                            <ul class="info-list">
                                <li><strong>知情权</strong>：了解本应用如何处理您的数据</li>
                                <li><strong>更正权</strong>：随时修改昵称、头像、密码等个人信息</li>
                                <li><strong>删除权</strong>：主动删除聊天记录和好友关系</li>
                                <li><strong>退出权</strong>：随时退出登录，停止使用本应用</li>
                            </ul>
                        </div>
                        <div class="info-card">
                            <div class="info-section-title"><i class="ri-update-line"></i>七、政策更新</div>
                            <p class="info-text">本隐私政策可能会不定期更新。更新后的政策将在应用内公布，不再单独通知用户。继续使用本应用即视为您同意更新后的隐私政策。</p>
                        </div>
                        <div class="info-footer">
                            <p>简讯 隐私政策</p>
                            <p>开发者：不见桃花不见秋</p>
                            <p>© 2026 All Rights Reserved</p>
                        </div>
                    </template>

                    <!-- 用户手册 -->
                    <template v-if="infoPageType === 'manual'">
                        <div class="info-card">
                            <div class="info-section-title"><i class="ri-book-open-line"></i>用户手册</div>
                            <p class="info-text">欢迎使用简讯！本手册将帮助您快速上手使用各项功能。</p>
                        </div>
                        <div class="info-card">
                            <div class="info-section-title"><i class="ri-user-add-line"></i>一、注册与登录</div>
                            <div class="info-step">
                                <div class="info-step-num">1</div>
                                <div class="info-step-content">
                                    <div class="info-step-title">注册账号</div>
                                    <div class="info-step-desc">打开应用后点击"注册"，填写用户名、昵称、邮箱和密码即可完成注册。管理员账号为 admin，在安装时自动创建。</div>
                                </div>
                            </div>
                            <div class="info-step">
                                <div class="info-step-num">2</div>
                                <div class="info-step-content">
                                    <div class="info-step-title">登录</div>
                                    <div class="info-step-desc">输入用户名和密码点击登录即可进入应用。登录后底部导航栏有消息、联系人、发现、我的四个页面。</div>
                                </div>
                            </div>
                            <div class="info-step">
                                <div class="info-step-num">3</div>
                                <div class="info-step-content">
                                    <div class="info-step-title">忘记密码</div>
                                    <div class="info-step-desc">点击登录页的"忘记密码"，输入注册邮箱后设置新密码即可。</div>
                                </div>
                            </div>
                        </div>
                        <div class="info-card">
                            <div class="info-section-title"><i class="ri-chat-3-line"></i>二、消息与聊天</div>
                            <div class="info-step">
                                <div class="info-step-num">1</div>
                                <div class="info-step-content">
                                    <div class="info-step-title">发起聊天</div>
                                    <div class="info-step-desc">在"联系人"页面找到好友，点击右侧粉色聊天气泡图标即可打开聊天窗口。</div>
                                </div>
                            </div>
                            <div class="info-step">
                                <div class="info-step-num">2</div>
                                <div class="info-step-content">
                                    <div class="info-step-title">发送消息</div>
                                    <div class="info-step-desc">在聊天底部输入框输入文字，点击发送按钮即可。消息每秒自动轮询，实时显示新消息。</div>
                                </div>
                            </div>
                            <div class="info-step">
                                <div class="info-step-num">3</div>
                                <div class="info-step-content">
                                    <div class="info-step-title">发送图片/视频</div>
                                    <div class="info-step-desc">点击输入框左侧的图片或视频图标，选择文件即可发送。支持最大1000MB的文件。发送后自动显示上传进度。</div>
                                </div>
                            </div>
                            <div class="info-step">
                                <div class="info-step-num">4</div>
                                <div class="info-step-content">
                                    <div class="info-step-title">消息列表</div>
                                    <div class="info-step-desc">"消息"页面显示所有聊天会话，包含最新消息、时间和未读数。未读数超过99显示为99+。</div>
                                </div>
                            </div>
                        </div>
                        <div class="info-card">
                            <div class="info-section-title"><i class="ri-contacts-line"></i>三、好友管理</div>
                            <div class="info-step">
                                <div class="info-step-num">1</div>
                                <div class="info-step-content">
                                    <div class="info-step-title">添加好友</div>
                                    <div class="info-step-desc">在"联系人"页面点击右上角"+"图标，搜索用户名或昵称，找到后点击"添加"发送好友申请。</div>
                                </div>
                            </div>
                            <div class="info-step">
                                <div class="info-step-num">2</div>
                                <div class="info-step-content">
                                    <div class="info-step-title">处理好友申请</div>
                                    <div class="info-step-desc">新的好友申请会实时轮询提醒。在"新朋友"页面可以接受或拒绝好友申请。</div>
                                </div>
                            </div>
                            <div class="info-step">
                                <div class="info-step-num">3</div>
                                <div class="info-step-content">
                                    <div class="info-step-title">删除好友</div>
                                    <div class="info-step-desc">在联系人列表中，点击好友右侧的灰色删除图标，确认后删除好友，同时清除双方聊天记录和媒体文件。</div>
                                </div>
                            </div>
                            <div class="info-step">
                                <div class="info-step-num">4</div>
                                <div class="info-step-content">
                                    <div class="info-step-title">搜索好友</div>
                                    <div class="info-step-desc">联系人页面顶部搜索框可快速搜索已添加的好友。</div>
                                </div>
                            </div>
                        </div>
                        <div class="info-card">
                            <div class="info-section-title"><i class="ri-user-line"></i>四、个人资料</div>
                            <div class="info-step">
                                <div class="info-step-num">1</div>
                                <div class="info-step-content">
                                    <div class="info-step-title">编辑资料</div>
                                    <div class="info-step-desc">在"我的"页面点击账号区域，可修改头像、昵称和密码。邮箱不可修改。</div>
                                </div>
                            </div>
                            <div class="info-step">
                                <div class="info-step-num">2</div>
                                <div class="info-step-content">
                                    <div class="info-step-title">实名认证</div>
                                    <div class="info-step-desc">在"我的"页面点击"实名认证"，填写真实姓名和身份证号即可完成认证。认证后不可修改。</div>
                                </div>
                            </div>
                        </div>
                        <div class="info-card">
                            <div class="info-section-title"><i class="ri-compass-line"></i>五、发现页</div>
                            <p class="info-text">发现页展示应用内的动态内容入口，包括朋友圈、扫一扫、摇一摇等功能入口。</p>
                        </div>
                        <div class="info-card">
                            <div class="info-section-title"><i class="ri-dashboard-line"></i>六、管理后台（仅管理员）</div>
                            <p class="info-text">管理员账号（admin）在"我的"页面可看到"管理后台"入口，普通用户不可见。</p>
                            <ul class="info-list">
                                <li>查看用户统计（用户总数、今日新增、消息数量等）</li>
                                <li>搜索和管理所有用户</li>
                                <li>禁用/启用用户账号</li>
                                <li>重置用户密码</li>
                                <li>设置/取消管理员</li>
                                <li>删除用户及其所有数据</li>
                            </ul>
                        </div>
                        <div class="info-card">
                            <div class="info-section-title"><i class="ri-question-line"></i>七、常见问题</div>
                            <div class="info-step">
                                <div class="info-step-num">Q</div>
                                <div class="info-step-content">
                                    <div class="info-step-title">收不到消息？</div>
                                    <div class="info-step-desc">请检查网络连接，消息每秒轮询一次。如果页面在后台，轮询会暂停，回到前台后自动恢复。</div>
                                </div>
                            </div>
                            <div class="info-step">
                                <div class="info-step-num">Q</div>
                                <div class="info-step-content">
                                    <div class="info-step-title">上传失败？</div>
                                    <div class="info-step-desc">请检查文件大小是否超过1000MB，文件格式是否支持。图片支持jpg/png/gif/webp等，视频支持mp4/webm/mov等。</div>
                                </div>
                            </div>
                            <div class="info-step">
                                <div class="info-step-num">Q</div>
                                <div class="info-step-content">
                                    <div class="info-step-title">按返回键退出？</div>
                                    <div class="info-step-desc">本应用所有页面切换均使用历史记录替换，按返回键会直接退出应用而非返回上一页。</div>
                                </div>
                            </div>
                        </div>
                        <div class="info-footer">
                            <p>简讯 用户手册</p>
                            <p>开发者：不见桃花不见秋</p>
                            <p>© 2026 All Rights Reserved</p>
                        </div>
                    </template>
                </div>
            </div>
        </div>

        <!-- 发布朋友圈弹层 -->
        <div class="edit-profile-popup" v-if="showPublishPanel" @click.self="closePublishPanel">
            <div class="publish-panel">
                <div class="ep-header">
                    <div class="ep-back" @click="closePublishPanel"><i class="ri-close-line"></i></div>
                    <div class="ep-title">发布朋友圈</div>
                    <div class="ep-save" @click="publishMoment" :disabled="publishing">
                        {{ publishing ? '发布中...' : '发布' }}
                    </div>
                </div>
                <div class="publish-content">
                    <textarea class="publish-textarea" v-model="momentForm.content" placeholder="这一刻的想法..." rows="5"></textarea>
                    <div class="publish-images">
                        <div class="publish-img-item" v-for="(img, i) in momentForm.images" :key="i">
                            <img :src="img">
                            <div class="publish-img-del" @click="removeMomentImage(i)"><i class="ri-close-line"></i></div>
                        </div>
                        <div class="publish-img-add" v-if="momentForm.images.length < 9" @click="$refs.momentImageInput.click()">
                            <i class="ri-add-line"></i>
                        </div>
                    </div>
                    <input type="file" ref="momentImageInput" accept="image/*" multiple style="display:none" @change="handleMomentImageUpload">
                    <div class="publish-tip">最多选择9张图片</div>
                </div>
            </div>
        </div>

        <!-- 设置页面弹层 -->
        <div class="edit-profile-popup" v-if="showSettingsPanel" @click.self="closeSettingsPanel">
            <div class="settings-panel">
                <div class="ep-header">
                    <div class="ep-back" @click="closeSettingsPanel"><i class="ri-arrow-left-line"></i></div>
                    <div class="ep-title">设置</div>
                    <div class="ep-back" style="visibility:hidden"><i class="ri-arrow-left-line"></i></div>
                </div>
                <div class="settings-content">
                    <!-- 朋友圈隐私设置 -->
                    <div class="settings-section-title">朋友圈隐私</div>
                    <div class="settings-group">
                        <div class="settings-item">
                            <div class="settings-item-left">
                                <div class="settings-item-icon" style="background:#ff6b9d"><i class="ri-eye-line"></i></div>
                                <div>
                                    <div class="settings-item-name">谁可以看我的朋友圈</div>
                                    <div class="settings-item-desc">控制谁能查看你发布的朋友圈动态</div>
                                </div>
                            </div>
                            <div class="settings-segmented">
                                <div class="seg-item" :class="{active: privacySettings.moment_visible === 0}" @click="privacySettings.moment_visible = 0">所有人</div>
                                <div class="seg-item" :class="{active: privacySettings.moment_visible === 1}" @click="privacySettings.moment_visible = 1">仅好友</div>
                                <div class="seg-item" :class="{active: privacySettings.moment_visible === 2}" @click="privacySettings.moment_visible = 2">仅自己</div>
                            </div>
                        </div>
                        <div class="settings-item">
                            <div class="settings-item-left">
                                <div class="settings-item-icon" style="background:#5764f5"><i class="ri-compass-line"></i></div>
                                <div>
                                    <div class="settings-item-name">在发现页展示我的朋友圈</div>
                                    <div class="settings-item-desc">关闭后，你的动态不会出现在发现页列表中</div>
                                </div>
                            </div>
                            <div class="settings-switch" :class="{on: privacySettings.show_moment_in_discover === 1}" @click="privacySettings.show_moment_in_discover = privacySettings.show_moment_in_discover ? 0 : 1">
                                <div class="switch-knob"></div>
                            </div>
                        </div>
                    </div>

                    <!-- 账号隐私设置 -->
                    <div class="settings-section-title">账号隐私</div>
                    <div class="settings-group">
                        <div class="settings-item">
                            <div class="settings-item-left">
                                <div class="settings-item-icon" style="background:#07c160"><i class="ri-search-line"></i></div>
                                <div>
                                    <div class="settings-item-name">允许通过搜索找到我</div>
                                    <div class="settings-item-desc">关闭后，其他用户搜索用户名或昵称时不会找到你</div>
                                </div>
                            </div>
                            <div class="settings-switch" :class="{on: privacySettings.allow_search === 1}" @click="privacySettings.allow_search = privacySettings.allow_search ? 0 : 1">
                                <div class="switch-knob"></div>
                            </div>
                        </div>
                        <div class="settings-item">
                            <div class="settings-item-left">
                                <div class="settings-item-icon" style="background:#ffa502"><i class="ri-user-add-line"></i></div>
                                <div>
                                    <div class="settings-item-name">允许他人添加我为好友</div>
                                    <div class="settings-item-desc">关闭后，其他用户将无法向你发送好友申请</div>
                                </div>
                            </div>
                            <div class="settings-switch" :class="{on: privacySettings.allow_add_friend === 1}" @click="privacySettings.allow_add_friend = privacySettings.allow_add_friend ? 0 : 1">
                                <div class="switch-knob"></div>
                            </div>
                        </div>
                    </div>

                    <!-- 通用设置 -->
                    <div class="settings-section-title">通用</div>
                    <div class="settings-group">
                        <div class="settings-item" @click="openInfoPage('about'); showSettingsPanel = false">
                            <div class="settings-item-left">
                                <div class="settings-item-icon" style="background:#57606f"><i class="ri-information-line"></i></div>
                                <div class="settings-item-name">关于简讯</div>
                            </div>
                            <i class="ri-arrow-right-s-line settings-arrow"></i>
                        </div>
                        <div class="settings-item" @click="openInfoPage('privacy'); showSettingsPanel = false">
                            <div class="settings-item-left">
                                <div class="settings-item-icon" style="background:#3742fa"><i class="ri-shield-keyhole-line"></i></div>
                                <div class="settings-item-name">隐私政策</div>
                            </div>
                            <i class="ri-arrow-right-s-line settings-arrow"></i>
                        </div>
                        <div class="settings-item" @click="openInfoPage('manual'); showSettingsPanel = false">
                            <div class="settings-item-left">
                                <div class="settings-item-icon" style="background:#ee5a24"><i class="ri-book-open-line"></i></div>
                                <div class="settings-item-name">用户手册</div>
                            </div>
                            <i class="ri-arrow-right-s-line settings-arrow"></i>
                        </div>
                    </div>

                    <button class="settings-save-btn" @click="savePrivacySettings" :disabled="savingPrivacy">
                        {{ savingPrivacy ? '保存中...' : '保存设置' }}
                    </button>
                    <div class="settings-tip">修改后请点击保存按钮生效</div>
                </div>
            </div>
        </div>

        <!-- 登录注册等认证页面（无底部导航） -->
        <template v-if="!isLoggedIn">
            <!-- 登录页 -->
            <div class="page auth-bg" v-if="currentRoute === 'login'">
                <div class="auth-decoration d1"></div>
                <div class="auth-decoration d2"></div>
                <div class="auth-card">
                    <div class="auth-logo">
                        <div class="auth-logo-icon"><i class="ri-chat-heart-fill"></i></div>
                        <h1>简讯</h1>
                        <p>甜美好时光，从简讯开始</p>
                    </div>
                    <div class="auth-title">欢迎回来 💕</div>
                    <div class="auth-input">
                        <i class="ri-user-line"></i>
                        <input type="text" v-model="loginForm.username" placeholder="用户名/邮箱" @keyup.enter="doLogin">
                    </div>
                    <div class="auth-input">
                        <i class="ri-lock-line"></i>
                        <input type="password" v-model="loginForm.password" placeholder="请输入密码" @keyup.enter="doLogin">
                    </div>
                    <div class="auth-options">
                        <label><input type="checkbox" v-model="loginForm.remember"> 记住我</label>
                        <a @click="navigate('forgot')">忘记密码？</a>
                    </div>
                    <button class="auth-btn" @click="doLogin" :disabled="logining">
                        {{ logining ? '登录中...' : '登 录' }}
                    </button>
                    <div class="auth-divider"><span>其他登录方式</span></div>
                    <div class="quick-login">
                        <div class="quick-btn qq"><i class="ri-qq-fill"></i></div>
                        <div class="quick-btn wechat"><i class="ri-wechat-fill"></i></div>
                        <div class="quick-btn weibo"><i class="ri-weibo-fill"></i></div>
                    </div>
                    <div class="auth-link">
                        还没有账号？<a @click="navigate('register')">立即注册</a>
                    </div>
                </div>
            </div>

            <!-- 注册页 -->
            <div class="page auth-bg" v-if="currentRoute === 'register'" style="background: #FDB59F;">
                <div class="auth-card">
                    <div class="auth-logo">
                        <div class="auth-logo-icon" style="background: linear-gradient(135deg, #a8edea, #fed6e3);">
                            <i class="ri-user-heart-fill"></i>
                        </div>
                        <h1 style="background: linear-gradient(135deg, #667eea, #764ba2); -webkit-background-clip: text; -webkit-text-fill-color: transparent;">加入简讯</h1>
                    </div>
                    <div class="auth-title">创建你的账号 ✨</div>
                    <div class="auth-input">
                        <i class="ri-user-line" style="color:#96ceb4"></i>
                        <input type="text" v-model="registerForm.username" placeholder="用户名（3-20位字母数字）">
                    </div>
                    <div class="auth-input">
                        <i class="ri-emotion-line" style="color:#96ceb4"></i>
                        <input type="text" v-model="registerForm.nickname" placeholder="昵称（选填）">
                    </div>
                    <div class="auth-input">
                        <i class="ri-mail-line" style="color:#96ceb4"></i>
                        <input type="email" v-model="registerForm.email" placeholder="邮箱地址">
                    </div>
                    <div class="auth-input">
                        <i class="ri-lock-line" style="color:#96ceb4"></i>
                        <input type="password" v-model="registerForm.password" placeholder="设置密码（至少6位）" @input="checkPwdStrength">
                    </div>
                    <div class="password-strength">
                        <div class="strength-bar" :class="{weak:pwdLevel>=1,medium:pwdLevel>=2,strong:pwdLevel>=3}"></div>
                        <div class="strength-bar" :class="{medium:pwdLevel>=2,strong:pwdLevel>=3}"></div>
                        <div class="strength-bar" :class="{strong:pwdLevel>=3}"></div>
                    </div>
                    <div class="auth-input">
                        <i class="ri-lock-password-line" style="color:#96ceb4"></i>
                        <input type="password" v-model="registerForm.confirm_password" placeholder="确认密码">
                    </div>
                    <button class="auth-btn" @click="doRegister" :disabled="registering" 
                        style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); box-shadow: 0 8px 25px rgba(102,126,234,0.35);">
                        {{ registering ? '注册中...' : '立即注册' }}
                    </button>
                    <div class="auth-link" style="font-size:12px;color:#999;margin-top:15px">
                        注册即表示同意<a>《用户协议》</a>和<a>《隐私政策》</a>
                    </div>
                    <div class="auth-link">
                        已有账号？<a @click="navigate('login')">去登录</a>
                    </div>
                </div>
            </div>

            <!-- 忘记密码页 -->
            <div class="page auth-bg" v-if="currentRoute === 'forgot'" style="background: #FDB59F;">
                <div class="auth-card">
                    <div class="auth-logo">
                        <div class="auth-logo-icon" style="background: linear-gradient(135deg, #d299c2, #fef9d7);">
                            <i class="ri-shield-keyhole-fill" style="color:#9b59b6"></i>
                        </div>
                        <h1 style="background: linear-gradient(135deg, #9b59b6, #8e44ad); -webkit-background-clip: text; -webkit-text-fill-color: transparent;">找回密码</h1>
                    </div>
                    <div class="auth-title">重置你的密码 🔐</div>
                    
                    <div v-if="forgotStep === 1">
                        <div class="auth-input">
                            <i class="ri-mail-line" style="color:#d299c2"></i>
                            <input type="email" v-model="forgotForm.email" placeholder="请输入注册邮箱">
                        </div>
                        <button class="auth-btn" @click="sendResetCode" :disabled="sendingCode"
                            style="background: linear-gradient(135deg, #9b59b6 0%, #8e44ad 100%); box-shadow: 0 8px 25px rgba(155,89,182,0.35);">
                            {{ sendingCode ? '发送中...' : '发送验证码' }}
                        </button>
                    </div>
                    
                    <div v-else-if="forgotStep === 2">
                        <div class="auth-input">
                            <i class="ri-shield-check-line" style="color:#d299c2"></i>
                            <input type="text" v-model="forgotForm.token" placeholder="请输入验证码">
                        </div>
                        <div class="auth-input">
                            <i class="ri-lock-line" style="color:#d299c2"></i>
                            <input type="password" v-model="forgotForm.new_password" placeholder="设置新密码">
                        </div>
                        <div class="auth-input">
                            <i class="ri-lock-password-line" style="color:#d299c2"></i>
                            <input type="password" v-model="forgotForm.confirm_password" placeholder="确认新密码">
                        </div>
                        <button class="auth-btn" @click="resetPassword" :disabled="reseting"
                            style="background: linear-gradient(135deg, #9b59b6 0%, #8e44ad 100%); box-shadow: 0 8px 25px rgba(155,89,182,0.35);">
                            {{ reseting ? '重置中...' : '确认重置' }}
                        </button>
                    </div>
                    
                    <div class="auth-link">
                        想起密码了？<a @click="navigate('login')">返回登录</a>
                    </div>
                </div>
            </div>
        </template>

        <!-- 已登录 - 主应用框架 -->
        <template v-else>
            <!-- 聊天详情页（全屏，无底部导航） -->
            <div class="page chat-page" v-if="currentRoute === 'chat'">
                <div class="chat-header">
                    <div class="back" @click="goBack"><i class="ri-arrow-left-s-line"></i></div>
                    <div class="friend-info">
                        <div class="friend-name">{{ currentFriend.nickname || '聊天' }}</div>
                    </div>
                    <div class="more"><i class="ri-more-2-fill"></i></div>
                </div>
                <div class="chat-messages" ref="msgContainer">
                    <template v-for="(msg, idx) in messages" :key="msg.id || idx">
                        <div class="msg-time" v-if="msg.isTime">{{ msg.time }}</div>
                        <div class="msg-row" :class="{mine: msg.from_user_id === currentUser.id}">
                            <div class="msg-avatar">
                                <img v-if="msg.from_user_id === currentUser.id ? currentUser.avatar : currentFriend.avatar" 
                                     :src="msg.from_user_id === currentUser.id ? currentUser.avatar : currentFriend.avatar">
                                <i v-else class="ri-user-3-fill"></i>
                            </div>
                            <!-- 文本消息 -->
                            <div class="msg-bubble" v-if="msg.type == 1">{{ msg.content }}</div>
                            <!-- 图片消息 -->
                            <div class="msg-bubble msg-image" v-else-if="msg.type == 2">
                                <div class="img-wrap">
                                    <img :src="msg.content" @click="previewImage(msg.content)" alt="图片" @error="handleImgError($event)">
                                    <div class="uploading-mask" v-if="msg.uploading">
                                        <div class="uploading-spinner"></div>
                                        <span>上传中...</span>
                                    </div>
                                </div>
                            </div>
                            <!-- 视频消息 -->
                            <div class="msg-bubble msg-video" v-else-if="msg.type == 3">
                                <div class="video-wrap">
                                    <video :src="msg.content" controls preload="metadata" playsinline webkit-playsinline></video>
                                    <div class="uploading-mask" v-if="msg.uploading">
                                        <div class="uploading-spinner"></div>
                                        <span>上传中...</span>
                                    </div>
                                </div>
                                <div class="video-name" v-if="msg.file_name">{{ msg.file_name }}</div>
                            </div>
                        </div>
                    </template>
                </div>
                <div class="chat-input-bar">
                    <div class="icon-btn" @click="triggerFileInput('image')" title="发送图片">
                        <i class="ri-image-line"></i>
                    </div>
                    <div class="icon-btn" @click="triggerFileInput('video')" title="发送视频">
                        <i class="ri-video-line"></i>
                    </div>
                    <input type="text" v-model="msgInput" placeholder="说点什么..." @keyup.enter="sendMessage" ref="msgInputEl">
                    <button class="send-btn" @click="sendMessage" :disabled="!msgInput.trim()">发送</button>
                </div>
                <!-- 隐藏的文件选择框 -->
                <input type="file" ref="imageInput" accept="image/*" style="display:none" @change="handleFileUpload('image', $event)">
                <input type="file" ref="videoInput" accept="video/*" style="display:none" @change="handleFileUpload('video', $event)">
            </div>

            <!-- 主页面（有底部导航） -->
            <template v-else>
                <!-- 顶部导航 -->
                <div class="app-header">
                    <div class="icon-btn" v-if="activeTab === 'profile'" @click="openSettingsPanel">
                        <i class="ri-settings-3-line"></i>
                    </div>
                    <div class="icon-btn" v-else-if="activeTab === 'contacts'">
                        <i class="ri-add-circle-line" @click="showAddFriend = true"></i>
                    </div>
                    <div class="icon-btn" v-else></div>
                    <div class="title">{{ headerTitle }}</div>
                    <div class="icon-btn" v-if="activeTab === 'chats'">
                        <i class="ri-search-line"></i>
                    </div>
                    <div class="icon-btn" v-else-if="activeTab === 'discover'" @click="showPublishPanel = true">
                        <i class="ri-camera-line"></i>
                    </div>
                    <div class="icon-btn" v-else></div>
                </div>

                <!-- 主内容 -->
                <div class="main-content">
                    <!-- 消息列表 -->
                    <div v-show="activeTab === 'chats'">
                        <div class="chat-item" v-for="chat in chatList" :key="chat.friend_id" @click="openChat(chat.friend_id)">
                            <div class="chat-avatar">
                                <img v-if="chat.avatar" :src="chat.avatar">
                                <i v-else class="ri-user-3-fill"></i>
                            </div>
                            <div class="chat-info">
                                <div class="chat-top">
                                    <span class="chat-name">{{ chat.nickname }}</span>
                                    <span class="chat-time">{{ formatTime(chat.last_time) }}</span>
                                </div>
                                <div class="chat-bottom">
                                    <span class="chat-msg">{{ chat.last_msg }}</span>
                                    <span class="chat-unread" v-if="chat.unread > 0">{{ chat.unread > 99 ? '99+' : chat.unread }}</span>
                                </div>
                            </div>
                        </div>
                        <div class="empty-state" v-if="chatList.length === 0">
                            <i class="ri-chat-3-line"></i>
                            <p>暂无消息，去和朋友打个招呼吧~</p>
                        </div>
                    </div>

                    <!-- 联系人 -->
                    <div v-show="activeTab === 'contacts'">
                        <div class="search-bar">
                            <div class="search-box">
                                <i class="ri-search-line"></i>
                                <input type="text" v-model="searchKeyword" placeholder="搜索好友">
                            </div>
                        </div>
                        <div class="new-friend-entry" @click="showFriendRequests = true">
                            <div class="nf-icon">
                                <i class="ri-user-add-fill"></i>
                            </div>
                            <div class="nf-text">新朋友</div>
                            <div class="nf-badge" v-if="friendRequestCount > 0">{{ friendRequestCount > 99 ? '99+' : friendRequestCount }}</div>
                            <i class="ri-arrow-right-s-line nf-arrow"></i>
                        </div>
                        <div class="contact-group-title">我的好友 ({{ filteredFriends.length }})</div>
                        <div class="contact-item" v-for="f in filteredFriends" :key="f.id">
                            <div class="contact-avatar" @click="openChat(f.id)">
                                <img v-if="f.avatar" :src="f.avatar">
                                <i v-else class="ri-user-3-fill"></i>
                            </div>
                            <div class="contact-info" @click="openChat(f.id)">
                                <div class="contact-name">{{ f.remark || f.nickname }}</div>
                                <div class="contact-sign">{{ f.signature || '这个人很懒，什么都没留下' }}</div>
                            </div>
                            <div class="contact-actions">
                                <button class="c-btn chat-btn" @click="openChat(f.id)" title="聊天">
                                    <i class="ri-chat-3-line"></i>
                                </button>
                                <button class="c-btn delete-btn" @click="deleteFriend(f)" title="删除好友">
                                    <i class="ri-delete-bin-line"></i>
                                </button>
                            </div>
                        </div>
                        <div class="empty-state" v-if="filteredFriends.length === 0 && friendList.length > 0">
                            <i class="ri-search-line"></i>
                            <p>没有找到匹配的好友</p>
                        </div>
                        <div class="empty-state" v-if="friendList.length === 0">
                            <i class="ri-user-heart-line"></i>
                            <p>还没有好友，点击右上角添加新朋友~</p>
                        </div>
                    </div>

                    <!-- 发现 -->
                    <div v-show="activeTab === 'discover'">
                        <div class="moment-list">
                            <div class="moment-empty" v-if="momentList.length === 0 && !momentLoading">
                                <i class="ri-chat-4-line"></i>
                                <p>还没有朋友圈动态<br>点击右上角相机发布第一条吧</p>
                            </div>
                            <div class="moment-item" v-for="m in momentList" :key="m.id">
                                <div class="moment-user">
                                    <div class="moment-avatar">
                                        <img v-if="m.avatar" :src="m.avatar">
                                        <i v-else class="ri-user-3-fill"></i>
                                    </div>
                                    <div>
                                        <div class="moment-name">{{ m.nickname || m.username }}</div>
                                        <div class="moment-time">{{ formatMomentTime(m.created_at) }}</div>
                                    </div>
                                </div>
                                <div class="moment-card">
                                    <div class="moment-content" v-if="m.content">{{ m.content }}</div>
                                    <div class="moment-images" :class="{ one: m.images && m.images.length === 1, two: m.images && m.images.length === 2 }" v-if="m.images && m.images.length > 0">
                                        <div class="moment-img" v-for="(img, i) in m.images" :key="i" @click="previewImage(img)">
                                            <img :src="img" @error="$event.target.style.display='none'">
                                        </div>
                                    </div>
                                    <div class="moment-actions">
                                        <div class="moment-action" :class="{ liked: m.liked }" @click="toggleMomentLike(m)">
                                            <i :class="m.liked ? 'ri-heart-fill' : 'ri-heart-line'"></i>
                                            <span v-if="m.like_count > 0">{{ m.like_count }}</span>
                                        </div>
                                        <div class="moment-action" @click="toggleCommentBox(m)">
                                            <i class="ri-chat-3-line"></i>
                                            <span v-if="m.comments_count > 0">{{ m.comments_count }}</span>
                                        </div>
                                        <div class="moment-action moment-action-delete" v-if="m.user_id == currentUser.id" @click="deleteMoment(m)">
                                            <i class="ri-delete-bin-line"></i>
                                        </div>
                                    </div>
                                    <div class="moment-comments" v-if="m.showComments">
                                        <div class="moment-comment-item" v-for="c in (m.commentList || [])" :key="c.id">
                                            <span class="cname">{{ c.nickname }}：</span>{{ c.content }}
                                        </div>
                                        <div class="moment-comment-input">
                                            <input type="text" v-model="m.commentText" placeholder="写评论..." @keyup.enter="submitComment(m)">
                                            <button @click="submitComment(m)">发送</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div style="text-align:center;padding:20px;color:rgba(255,255,255,0.4);font-size:13px;" v-if="momentLoading">加载中...</div>
                        </div>
                    </div>

                    <!-- 我的 -->
                    <div v-show="activeTab === 'profile'">
                        <div class="profile-header">
                            <div class="profile-user" @click="editProfile">
                                <div class="profile-avatar">
                                    <img v-if="currentUser.avatar" :src="currentUser.avatar">
                                    <i v-else class="ri-user-3-fill"></i>
                                </div>
                                <div class="profile-info">
                                    <h2>{{ currentUser.nickname || currentUser.username }}</h2>
                                    <p>{{ currentUser.signature || '这个人很懒，什么都没留下' }}</p>
                                </div>
                            </div>
                            <div class="profile-qr"><i class="ri-qr-code-line"></i></div>
                        </div>
                        
                        <div class="profile-stats">
                            <div class="stat-item">
                                <div class="stat-num">{{ friendList.length }}</div>
                                <div class="stat-label">好友</div>
                            </div>
                            <div class="stat-item">
                                <div class="stat-num">0</div>
                                <div class="stat-label">动态</div>
                            </div>
                            <div class="stat-item">
                                <div class="stat-num">0</div>
                                <div class="stat-label">收藏</div>
                            </div>
                        </div>

                        <div class="profile-menu">
                            <div class="menu-item">
                                <div class="menu-icon" style="background:#ff6b9d"><i class="ri-heart-fill"></i></div>
                                <div class="menu-text">我的收藏</div>
                                <i class="ri-arrow-right-s-line menu-arrow"></i>
                            </div>
                            <div class="menu-item">
                                <div class="menu-icon" style="background:#2ed573"><i class="ri-image-fill"></i></div>
                                <div class="menu-text">我的相册</div>
                                <i class="ri-arrow-right-s-line menu-arrow"></i>
                            </div>
                            <div class="menu-item">
                                <div class="menu-icon" style="background:#ffa502"><i class="ri-file-list-3-fill"></i></div>
                                <div class="menu-text">我的文件</div>
                                <i class="ri-arrow-right-s-line menu-arrow"></i>
                            </div>
                        </div>

                        <div class="profile-menu">
                            <div class="menu-item" v-if="currentUser.role == 1" @click="openAdminPanel">
                                <div class="menu-icon" style="background:linear-gradient(135deg,#667eea,#764ba2)"><i class="ri-dashboard-3-fill"></i></div>
                                <div class="menu-text">管理后台</div>
                                <span class="menu-right-text">管理员</span>
                                <i class="ri-arrow-right-s-line menu-arrow"></i>
                            </div>
                            <div class="menu-item" @click="openVerifyPopup">
                                <div class="menu-icon" style="background:#07c160"><i class="ri-shield-check-fill"></i></div>
                                <div class="menu-text">实名认证</div>
                                <span class="menu-right-text" v-if="currentUser.is_verified">
                                    <span class="verified-badge"><i class="ri-checkbox-circle-fill"></i>已认证</span>
                                </span>
                                <span class="menu-right-text" v-else>未认证</span>
                                <i class="ri-arrow-right-s-line menu-arrow"></i>
                            </div>
                            <div class="menu-item">
                                <div class="menu-icon" style="background:#667eea"><i class="ri-notification-3-fill"></i></div>
                                <div class="menu-text">消息通知</div>
                                <i class="ri-arrow-right-s-line menu-arrow"></i>
                            </div>
                            <div class="menu-item" @click="openSettingsPanel">
                                <div class="menu-icon" style="background:#a55eea"><i class="ri-shield-user-fill"></i></div>
                                <div class="menu-text">隐私设置</div>
                                <i class="ri-arrow-right-s-line menu-arrow"></i>
                            </div>
                            <div class="menu-item">
                                <div class="menu-icon" style="background:#1e90ff"><i class="ri-customer-service-2-fill"></i></div>
                                <div class="menu-text">帮助与反馈</div>
                                <i class="ri-arrow-right-s-line menu-arrow"></i>
                            </div>
                            <div class="menu-item" @click="openInfoPage('about')">
                                <div class="menu-icon" style="background:#57606f"><i class="ri-information-fill"></i></div>
                                <div class="menu-text">关于简讯</div>
                                <i class="ri-arrow-right-s-line menu-arrow"></i>
                            </div>
                            <div class="menu-item" @click="openInfoPage('privacy')">
                                <div class="menu-icon" style="background:#3742fa"><i class="ri-shield-keyhole-fill"></i></div>
                                <div class="menu-text">隐私政策</div>
                                <i class="ri-arrow-right-s-line menu-arrow"></i>
                            </div>
                            <div class="menu-item" @click="openInfoPage('manual')">
                                <div class="menu-icon" style="background:#ee5a24"><i class="ri-book-open-fill"></i></div>
                                <div class="menu-text">用户手册</div>
                                <i class="ri-arrow-right-s-line menu-arrow"></i>
                            </div>
                        </div>

                        <button class="logout-btn" @click="doLogout">
                            <i class="ri-logout-box-r-line"></i> 退出登录
                        </button>
                    </div>
                </div>

                <!-- 底部导航 -->
                <div class="app-tabbar">
                    <div class="tab-item" :class="{active: activeTab==='chats'}" @click="switchTab('chats')">
                        <i class="ri-chat-3-fill"></i>
                        <span>消息</span>
                        <div class="tab-badge" v-if="totalUnreadMsg > 0">{{ totalUnreadMsg > 99 ? '99+' : totalUnreadMsg }}</div>
                    </div>
                    <div class="tab-item" :class="{active: activeTab==='contacts'}" @click="switchTab('contacts')">
                        <i class="ri-user-heart-fill"></i>
                        <span>联系人</span>
                    </div>
                    <div class="tab-item" :class="{active: activeTab==='discover'}" @click="switchTab('discover')">
                        <i class="ri-compass-3-fill"></i>
                        <span>发现</span>
                    </div>
                    <div class="tab-item" :class="{active: activeTab==='profile'}" @click="switchTab('profile')">
                        <i class="ri-user-3-fill"></i>
                        <span>我的</span>
                    </div>
                </div>
            </template>
        </template>
    </div>

    <script>
        const { createApp, reactive, ref, computed, onMounted, watch, nextTick } = Vue;

        const app = createApp({
            setup() {
                // ===== 状态 =====
                const loading = ref(true);
                const isLoggedIn = ref(false);
                const currentRoute = ref('login');
                const activeTab = ref('chats');
                const toast = reactive({ show: false, msg: '' });

                // 用户信息
                const currentUser = reactive({
                    id: 0, username: '', nickname: '', avatar: '', email: '', signature: '',
                    real_name: '', id_card: '', id_card_masked: '', is_verified: 0, role: 0
                });

                // 编辑资料
                const showEditProfile = ref(false);
                const savingProfile = ref(false);
                const editForm = reactive({
                    nickname: '', avatar: '', old_password: '', new_password: '', confirm_password: ''
                });
                const avatarInput = ref(null);

                // 实名认证
                const showVerifyPopup = ref(false);
                const verifying = ref(false);
                const verifyForm = reactive({
                    real_name: '', id_card: ''
                });

                // 管理后台
                const showAdminPanel = ref(false);
                const adminStats = reactive({});
                const adminUserList = ref([]);
                const adminSearchKw = ref('');
                const adminPage = ref(1);
                const adminHasMore = ref(true);
                const adminLoading = ref(false);
                const expandedMenuId = ref(null);

                // 用户详情
                const showUserDetail = ref(false);
                const userDetailLoading = ref(false);
                const userDetailData = ref(null);

                // 信息页面（关于简讯/隐私政策/用户手册）
                const showInfoPage = ref(false);
                const infoPageType = ref('');
                const infoPageTitle = computed(() => {
                    const titles = { about: '关于简讯', privacy: '隐私政策', manual: '用户手册' };
                    return titles[infoPageType.value] || '';
                });

                // 朋友圈
                const momentList = ref([]);
                const momentLoading = ref(false);
                const showPublishPanel = ref(false);
                const publishing = ref(false);
                const momentForm = reactive({
                    content: '',
                    images: []
                });

                // 登录表单
                const loginForm = reactive({ username: '', password: '', remember: false });
                const logining = ref(false);

                // 注册表单
                const registerForm = reactive({ username: '', nickname: '', email: '', password: '', confirm_password: '' });
                const registering = ref(false);
                const pwdLevel = ref(0);

                // 忘记密码
                const forgotStep = ref(1);
                const forgotForm = reactive({ email: '', token: '', new_password: '', confirm_password: '' });
                const sendingCode = ref(false);
                const reseting = ref(false);

                // 聊天列表
                const chatList = ref([]);
                const totalUnread = computed(() => chatList.value.reduce((s, c) => s + (c.unread || 0), 0));
                const totalUnreadMsg = ref(0);

                // 好友列表
                const friendList = ref([]);
                const searchKeyword = ref('');
                const showAddFriend = ref(false);
                const addFriendKeyword = ref('');
                const addFriendResults = ref([]);

                // 好友申请
                const showFriendRequests = ref(false);
                const friendRequests = ref([]);
                const friendRequestCount = ref(0);
                let pollTimer = null;

                // 本地搜索过滤后的好友列表
                const filteredFriends = computed(() => {
                    if (!searchKeyword.value.trim()) return friendList.value;
                    const kw = searchKeyword.value.toLowerCase();
                    return friendList.value.filter(f => 
                        f.nickname.toLowerCase().includes(kw) ||
                        (f.remark && f.remark.toLowerCase().includes(kw)) ||
                        f.username.toLowerCase().includes(kw)
                    );
                });

                // 聊天详情
                const messages = ref([]);
                const currentFriend = reactive({ id: 0, nickname: '', avatar: '' });
                const msgInput = ref('');
                const msgContainer = ref(null);
                const msgInputEl = ref(null);
                const imageInput = ref(null);
                const videoInput = ref(null);
                const uploading = ref(false);

                // 设置弹层
                const showSettings = ref(false);

                // 设置页面（隐私设置）
                const showSettingsPanel = ref(false);
                const savingPrivacy = ref(false);
                const privacySettings = reactive({
                    moment_visible: 1,
                    allow_search: 1,
                    allow_add_friend: 1,
                    show_moment_in_discover: 1
                });

                // 发现页
                const discoverList = ref([]);

                // 页面标题
                const headerTitle = computed(() => {
                    const titles = { chats: '消息', contacts: '联系人', discover: '发现', profile: '我的' };
                    return titles[activeTab.value] || '简讯';
                });

                // ===== API请求 =====
                async function api(action, data = {}) {
                    try {
                        const res = await fetch('api.php?action=' + action, {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify(data)
                        });
                        const result = await res.json();
                        // 如果未登录，自动跳转到登录页
                        if (result.code === 401) {
                            isLoggedIn.value = false;
                            currentRoute.value = 'login';
                            location.replace('#/login');
                            stopPolling();
                        }
                        return result;
                    } catch (e) {
                        return { code: -1, msg: '网络错误' };
                    }
                }

                // Toast
                function showToast(msg, duration = 2000) {
                    toast.msg = msg;
                    toast.show = true;
                    setTimeout(() => { toast.show = false; }, duration);
                }

                // ===== 路由 =====
                function navigate(route) {
                    currentRoute.value = route;
                    // 使用 replace 替换历史记录，按返回键直接退出
                    location.replace('#/' + route);
                }

                function goBack() {
                    if (currentRoute.value === 'chat') {
                        currentRoute.value = 'home';
                        activeTab.value = 'chats';
                        location.replace('#/home');
                        loadChatList();
                    } else {
                        navigate('login');
                    }
                }

                function switchTab(tab) {
                    activeTab.value = tab;
                    // 使用 replace 替换历史记录
                    location.replace('#/' + tab);
                    if (tab === 'chats') loadChatList();
                    if (tab === 'contacts') { searchKeyword.value = ''; loadFriendList(); }
                    if (tab === 'discover') loadMomentList();
                }

                // ===== 认证相关 =====
                async function doLogin() {
                    if (!loginForm.username.trim() || !loginForm.password) {
                        showToast('请输入用户名和密码');
                        return;
                    }
                    logining.value = true;
                    const res = await api('login', { username: loginForm.username, password: loginForm.password });
                    logining.value = false;
                    if (res.code === 1) {
                        showToast('登录成功');
                        await checkLoginStatus();
                        navigate('home');
                        activeTab.value = 'chats';
                        loadChatList();
                        startPolling();
                    } else {
                        showToast(res.msg);
                    }
                }

                async function doRegister() {
                    if (!registerForm.username.trim() || !registerForm.email.trim() || !registerForm.password) {
                        showToast('请填写所有必填项');
                        return;
                    }
                    if (registerForm.password !== registerForm.confirm_password) {
                        showToast('两次密码不一致');
                        return;
                    }
                    registering.value = true;
                    const res = await api('register', registerForm);
                    registering.value = false;
                    if (res.code === 1) {
                        showToast(res.msg);
                        setTimeout(() => navigate('login'), 1000);
                    } else {
                        showToast(res.msg);
                    }
                }

                function checkPwdStrength() {
                    const pwd = registerForm.password;
                    let level = 0;
                    if (pwd.length >= 6) level++;
                    if (/[A-Za-z]/.test(pwd) && /\d/.test(pwd)) level++;
                    if (/[^A-Za-z0-9]/.test(pwd) && pwd.length >= 8) level++;
                    pwdLevel.value = level;
                }

                async function sendResetCode() {
                    if (!forgotForm.email.trim()) { showToast('请输入邮箱'); return; }
                    sendingCode.value = true;
                    const res = await api('forgot_password', { email: forgotForm.email });
                    sendingCode.value = false;
                    if (res.code === 1) {
                        showToast('验证码已发送（演示：' + res.data.token + '）');
                        forgotStep.value = 2;
                    } else {
                        showToast(res.msg);
                    }
                }

                async function resetPassword() {
                    if (forgotForm.new_password !== forgotForm.confirm_password) {
                        showToast('两次密码不一致');
                        return;
                    }
                    reseting.value = true;
                    const res = await api('reset_password', {
                        email: forgotForm.email,
                        token: forgotForm.token,
                        new_password: forgotForm.new_password
                    });
                    reseting.value = false;
                    if (res.code === 1) {
                        showToast('密码重置成功，请登录');
                        setTimeout(() => {
                            forgotStep.value = 1;
                            navigate('login');
                        }, 1000);
                    } else {
                        showToast(res.msg);
                    }
                }

                async function doLogout() {
                    if (!confirm('确定要退出登录吗？')) return;
                    await api('logout');
                    stopPolling();
                    isLoggedIn.value = false;
                    currentUser.id = 0;
                    chatList.value = [];
                    friendList.value = [];
                    friendRequests.value = [];
                    friendRequestCount.value = 0;
                    navigate('login');
                    showToast('已退出登录');
                }

                async function checkLoginStatus() {
                    const res = await api('check_login');
                    if (res.code === 1 && res.data.user) {
                        isLoggedIn.value = true;
                        Object.assign(currentUser, res.data.user);
                        return true;
                    }
                    return false;
                }

                // ===== 聊天相关 =====
                async function loadChatList() {
                    const res = await api('chat_list');
                    if (res.code === 1) chatList.value = res.data.chats || [];
                }

                let isOpeningChat = false;
                async function openChat(friendId) {
                    if (!friendId) {
                        showToast('好友ID无效');
                        return;
                    }
                    // 防止重复调用
                    if (isOpeningChat) return;
                    isOpeningChat = true;
                    
                    try {
                        const res = await api('get_messages', { friend_id: friendId });
                        if (res.code === 1) {
                            messages.value = (res.data && res.data.messages) || [];
                            const friendData = (res.data && res.data.friend) || {};
                            // 安全地更新好友信息
                            currentFriend.id = friendData.id || friendId;
                            currentFriend.nickname = friendData.nickname || '';
                            currentFriend.avatar = friendData.avatar || '';
                            currentRoute.value = 'chat';
                            // 使用 replace 替换历史记录，这样按返回键直接退出而不是回到上一级
                            location.replace('#/chat/' + friendId);
                            nextTick(() => {
                                if (msgContainer.value) {
                                    msgContainer.value.scrollTop = msgContainer.value.scrollHeight;
                                }
                            });
                            // 打开聊天后刷新未读数（因为已标记为已读）
                            pollUnreadMessages();
                        } else {
                            showToast(res.msg || '打开聊天失败');
                        }
                    } catch (e) {
                        showToast('打开聊天失败：' + e.message);
                    } finally {
                        isOpeningChat = false;
                    }
                }

                async function sendMessage() {
                    const content = msgInput.value.trim();
                    if (!content || !currentFriend.id) return;
                    
                    const newMsg = {
                        id: Date.now(),
                        from_user_id: currentUser.id,
                        to_user_id: currentFriend.id,
                        content: content,
                        type: 1,
                        created_at: new Date().toLocaleString()
                    };
                    messages.value.push(newMsg);
                    msgInput.value = '';
                    
                    nextTick(() => {
                        if (msgContainer.value) {
                            msgContainer.value.scrollTop = msgContainer.value.scrollHeight;
                        }
                    });
                    
                    await api('send_message', { to_user_id: currentFriend.id, content, type: 1 });
                    // 发送后刷新消息列表和未读数
                    pollUnreadMessages();
                }

                // 触发文件选择
                function triggerFileInput(type) {
                    if (type === 'image' && imageInput.value) {
                        imageInput.value.click();
                    } else if (type === 'video' && videoInput.value) {
                        videoInput.value.click();
                    }
                }

                // 处理文件上传
                async function handleFileUpload(type, event) {
                    const file = event.target.files[0];
                    if (!file) return;
                    
                    if (uploading.value) {
                        showToast('正在上传中，请稍候...');
                        return;
                    }
                    
                    if (!currentFriend.id) {
                        showToast('请先选择聊天对象');
                        return;
                    }
                    
                    // 生成本地预览URL，立即显示
                    const localUrl = URL.createObjectURL(file);
                    const msgType = type === 'image' ? 2 : 3;
                    const tempId = 'temp_' + Date.now();
                    
                    // 先添加一条"上传中"的消息
                    const tempMsg = {
                        id: tempId,
                        from_user_id: currentUser.id,
                        to_user_id: currentFriend.id,
                        content: localUrl,
                        type: msgType,
                        file_name: file.name,
                        file_size: file.size,
                        created_at: new Date().toLocaleString(),
                        uploading: true,
                        upload_progress: 0
                    };
                    messages.value.push(tempMsg);
                    
                    // 滚动到底部
                    nextTick(() => {
                        if (msgContainer.value) {
                            msgContainer.value.scrollTop = msgContainer.value.scrollHeight;
                        }
                    });
                    
                    uploading.value = true;
                    
                    try {
                        const formData = new FormData();
                        formData.append('file', file);
                        
                        const res = await fetch('api.php?action=upload_file&file_type=' + type, {
                            method: 'POST',
                            body: formData
                        });
                        
                        // 先读取文本，再尝试解析为JSON（防止解析失败时看不到原始内容）
                        const text = await res.text();
                        let result;
                        try {
                            result = JSON.parse(text);
                        } catch (parseErr) {
                            if (!text || text.trim().length === 0) {
                                throw new Error('服务器返回空响应 (HTTP ' + res.status + ')，请检查服务器配置或文件大小限制');
                            } else {
                                // 显示前300个字符帮助排查问题
                                throw new Error('服务器返回异常 (HTTP ' + res.status + '): ' + text.substring(0, 300));
                            }
                        }
                        
                        if (result.code === 1) {
                            // 上传成功，更新消息
                            const msgIndex = messages.value.findIndex(m => m.id === tempId);
                            if (msgIndex !== -1) {
                                messages.value[msgIndex].content = result.data.url;
                                messages.value[msgIndex].uploading = false;
                                messages.value[msgIndex].file_name = result.data.name;
                                messages.value[msgIndex].file_size = result.data.size;
                            }
                            
                            // 发送消息到服务器
                            await api('send_message', {
                                to_user_id: currentFriend.id,
                                content: result.data.path,
                                type: msgType,
                                file_name: result.data.name,
                                file_size: result.data.size
                            });
                            
                            // 发送后刷新消息列表和未读数
                            pollUnreadMessages();
                        } else {
                            // 上传失败，移除临时消息并提示
                            const msgIndex = messages.value.findIndex(m => m.id === tempId);
                            if (msgIndex !== -1) {
                                messages.value.splice(msgIndex, 1);
                            }
                            showToast(result.msg || '上传失败');
                        }
                    } catch (e) {
                        // 上传出错，移除临时消息并提示
                        const msgIndex = messages.value.findIndex(m => m.id === tempId);
                        if (msgIndex !== -1) {
                            messages.value.splice(msgIndex, 1);
                        }
                        showToast('上传失败：' + e.message);
                    } finally {
                        uploading.value = false;
                        // 释放本地预览URL
                        URL.revokeObjectURL(localUrl);
                        // 清空input，允许重复选择同一文件
                        if (event.target) event.target.value = '';
                    }
                }

                // 预览图片
                function previewImage(src) {
                    // 简单的新窗口预览
                    window.open(src, '_blank');
                }
                
                // 图片加载失败处理
                function handleImgError(event) {
                    event.target.style.display = 'none';
                    // 显示占位
                    const wrap = event.target.parentElement;
                    if (wrap) {
                        wrap.style.minHeight = '100px';
                        wrap.style.background = '#f0f0f0';
                        wrap.style.display = 'flex';
                        wrap.style.alignItems = 'center';
                        wrap.style.justifyContent = 'center';
                        wrap.innerHTML = '<span style="color:#999;font-size:12px;">图片加载失败</span>';
                    }
                }

                // ===== 好友相关 =====
                async function loadFriendList() {
                    const res = await api('friend_list');
                    if (res.code === 1) friendList.value = res.data.friends || [];
                }

                async function searchUsers() {
                    if (!searchKeyword.value.trim()) {
                        searchResults.value = [];
                        return;
                    }
                    const res = await api('search_user&keyword=' + encodeURIComponent(searchKeyword.value));
                    if (res.code === 1) searchResults.value = res.data.users || [];
                }

                async function searchAddFriend() {
                    if (!addFriendKeyword.value.trim()) {
                        addFriendResults.value = [];
                        return;
                    }
                    const res = await api('search_user&keyword=' + encodeURIComponent(addFriendKeyword.value));
                    if (res.code === 1) addFriendResults.value = res.data.users || [];
                }

                async function doAddFriend(user) {
                    const isFriend = friendList.value.some(f => f.id === user.id);
                    if (isFriend) {
                        showToast('已经是好友了');
                        return;
                    }
                    const res = await api('add_friend', { friend_id: user.id });
                    showToast(res.msg);
                    if (res.code === 1) {
                        setTimeout(() => {
                            showAddFriend.value = false;
                            loadFriendList();
                        }, 1000);
                    }
                }

                // ===== 好友申请 =====
                async function loadFriendRequests() {
                    const res = await api('friend_requests');
                    if (res.code === 1) {
                        friendRequests.value = res.data.requests || [];
                        friendRequestCount.value = res.data.count || 0;
                    }
                }

                async function handleRequest(req, action) {
                    const res = await api('handle_friend_request', { request_id: req.id, action });
                    showToast(res.msg);
                    if (res.code === 1) {
                        loadFriendRequests();
                        loadFriendList();
                    }
                }

                async function deleteFriend(friend) {
                    if (!confirm('确定删除好友 ' + (friend.remark || friend.nickname) + ' 吗？聊天记录也会一并清除。')) return;
                    const res = await api('delete_friend', { friend_id: friend.id });
                    showToast(res.msg);
                    if (res.code === 1) {
                        loadFriendList();
                        loadChatList();
                        pollUnreadMessages();
                    }
                }

                // 1秒轮询（好友申请 + 新消息）
                function startPolling() {
                    if (pollTimer) return;
                    loadFriendRequests();
                    pollUnreadMessages();
                    pollTimer = setInterval(() => {
                        if (isLoggedIn.value && document.visibilityState === 'visible') {
                            loadFriendRequests();
                            pollUnreadMessages();
                        }
                    }, 1000);
                }

                async function pollUnreadMessages() {
                    const res = await api('unread_count');
                    if (res.code === 1) {
                        totalUnreadMsg.value = res.data.total || 0;
                        // 如果在消息页，更新列表
                        if (activeTab.value === 'chats') {
                            chatList.value = res.data.chats || [];
                        }
                        // 如果在当前聊天窗口，刷新消息
                        if (currentRoute.value === 'chat' && currentFriend.id) {
                            const msgRes = await api('get_messages', { friend_id: currentFriend.id });
                            if (msgRes.code === 1 && msgRes.data.messages) {
                                // 有新消息才更新并滚到底部
                                if (msgRes.data.messages.length !== messages.value.length) {
                                    messages.value = msgRes.data.messages;
                                    nextTick(() => {
                                        if (msgContainer.value) {
                                            msgContainer.value.scrollTop = msgContainer.value.scrollHeight;
                                        }
                                    });
                                }
                            }
                        }
                    }
                }

                function stopPolling() {
                    if (pollTimer) {
                        clearInterval(pollTimer);
                        pollTimer = null;
                    }
                }

                // ===== 朋友圈 =====
                async function loadMomentList() {
                    momentLoading.value = true;
                    try {
                        const res = await fetch('api.php?action=discover_list&page=1', { method: 'GET' });
                        const result = await res.json();
                        if (result.code === 1) {
                            momentList.value = (result.data.items || []).map(m => ({
                                ...m,
                                showComments: false,
                                commentList: [],
                                commentText: ''
                            }));
                        }
                    } catch (e) {
                        console.error('加载朋友圈失败', e);
                    } finally {
                        momentLoading.value = false;
                    }
                }

                function formatMomentTime(time) {
                    if (!time) return '';
                    const d = new Date(time.replace(/-/g, '/'));
                    const now = new Date();
                    const diff = (now - d) / 1000;
                    if (diff < 60) return '刚刚';
                    if (diff < 3600) return Math.floor(diff / 60) + '分钟前';
                    if (diff < 86400) return Math.floor(diff / 3600) + '小时前';
                    if (diff < 2592000) return Math.floor(diff / 86400) + '天前';
                    return d.getMonth() + 1 + '月' + d.getDate() + '日';
                }

                // 关闭发布面板
                function closePublishPanel() {
                    showPublishPanel.value = false;
                    momentForm.content = '';
                    momentForm.images = [];
                }

                // 图片选择上传
                async function handleMomentImageUpload(event) {
                    const files = Array.from(event.target.files);
                    if (!files.length) return;
                    const remaining = 9 - momentForm.images.length;
                    const toUpload = files.slice(0, remaining);
                    
                    for (const file of toUpload) {
                        const formData = new FormData();
                        formData.append('file', file);
                        try {
                            const res = await fetch('api.php?action=upload_file&file_type=image', {
                                method: 'POST',
                                body: formData
                            });
                            const result = await res.json();
                            if (result.code === 1 && result.data.url) {
                                momentForm.images.push(result.data.url);
                            }
                        } catch (e) {
                            showToast('图片上传失败');
                        }
                    }
                    event.target.value = '';
                }

                function removeMomentImage(index) {
                    momentForm.images.splice(index, 1);
                }

                // 发布朋友圈
                async function publishMoment() {
                    if (!momentForm.content.trim() && momentForm.images.length === 0) {
                        showToast('请输入内容或选择图片');
                        return;
                    }
                    publishing.value = true;
                    try {
                        const res = await api('publish_moment', {
                            content: momentForm.content.trim(),
                            images: momentForm.images
                        });
                        if (res.code === 1) {
                            showToast('发布成功');
                            closePublishPanel();
                            await loadMomentList();
                        } else {
                            showToast(res.msg || '发布失败');
                        }
                    } catch (e) {
                        showToast('网络错误');
                    } finally {
                        publishing.value = false;
                    }
                }

                // 点赞
                async function toggleMomentLike(moment) {
                    try {
                        const res = await api('toggle_like', { moment_id: moment.id });
                        if (res.code === 1) {
                            moment.liked = res.data.liked;
                            moment.like_count = res.data.like_count;
                        }
                    } catch (e) {
                        showToast('操作失败');
                    }
                }

                // 切换评论框
                async function toggleCommentBox(moment) {
                    moment.showComments = !moment.showComments;
                    if (moment.showComments && !moment.commentList.length) {
                        try {
                            const res = await fetch('api.php?action=moment_comments&moment_id=' + moment.id, { method: 'GET' });
                            const result = await res.json();
                            if (result.code === 1) {
                                moment.commentList = result.data.comments || [];
                            }
                        } catch (e) {
                            console.error('加载评论失败', e);
                        }
                    }
                }

                // 发表评论
                async function submitComment(moment) {
                    const text = (moment.commentText || '').trim();
                    if (!text) return;
                    try {
                        const res = await api('moment_comment', { moment_id: moment.id, content: text });
                        if (res.code === 1) {
                            moment.commentText = '';
                            moment.comments_count = (moment.comments_count || 0) + 1;
                            // 刷新评论列表
                            const r = await fetch('api.php?action=moment_comments&moment_id=' + moment.id, { method: 'GET' });
                            const result = await r.json();
                            if (result.code === 1) {
                                moment.commentList = result.data.comments || [];
                            }
                        } else {
                            showToast(res.msg || '评论失败');
                        }
                    } catch (e) {
                        showToast('网络错误');
                    }
                }

                // 删除朋友圈
                async function deleteMoment(moment) {
                    if (!confirm('确定要删除这条动态吗？')) return;
                    try {
                        const res = await api('delete_moment', { moment_id: moment.id });
                        if (res.code === 1) {
                            showToast('删除成功');
                            momentList.value = momentList.value.filter(m => m.id !== moment.id);
                        } else {
                            showToast(res.msg || '删除失败');
                        }
                    } catch (e) {
                        showToast('网络错误');
                    }
                }

                // ===== 工具函数 =====
                function formatTime(time) {
                    if (!time) return '';
                    const d = new Date(time);
                    const now = new Date();
                    const diff = (now - d) / 1000;
                    if (diff < 60) return '刚刚';
                    if (diff < 3600) return Math.floor(diff / 60) + '分钟前';
                    if (d.toDateString() === now.toDateString()) {
                        return d.getHours().toString().padStart(2, '0') + ':' + d.getMinutes().toString().padStart(2, '0');
                    }
                    const yesterday = new Date(now); yesterday.setDate(yesterday.getDate() - 1);
                    if (d.toDateString() === yesterday.toDateString()) return '昨天';
                    return (d.getMonth() + 1) + '/' + d.getDate();
                }

                // 打开编辑资料
                function editProfile() {
                    editForm.nickname = currentUser.nickname || '';
                    editForm.avatar = currentUser.avatar || '';
                    editForm.old_password = '';
                    editForm.new_password = '';
                    editForm.confirm_password = '';
                    showEditProfile.value = true;
                }

                function closeEditProfile() {
                    showEditProfile.value = false;
                }

                // 触发头像上传
                function triggerAvatarUpload() {
                    if (avatarInput.value) {
                        avatarInput.value.click();
                    }
                }

                // 处理头像上传
                async function handleAvatarUpload(event) {
                    const file = event.target.files[0];
                    if (!file) return;

                    // 预览
                    const reader = new FileReader();
                    reader.onload = (e) => {
                        editForm.avatar = e.target.result;
                    };
                    reader.readAsDataURL(file);

                    // 上传到服务器
                    const formData = new FormData();
                    formData.append('file', file);

                    try {
                        const res = await fetch('api.php?action=upload_file&file_type=image', {
                            method: 'POST',
                            body: formData
                        });
                        const text = await res.text();
                        let result;
                        try {
                            result = JSON.parse(text);
                        } catch (e) {
                            showToast('上传失败：服务器响应异常');
                            return;
                        }
                        if (result.code === 1 && result.data && result.data.url) {
                            editForm.avatar = result.data.url;
                        } else {
                            showToast(result.msg || '头像上传失败');
                        }
                    } catch (e) {
                        showToast('上传失败：网络错误');
                    }

                    // 清空input，允许重复选择同一文件
                    event.target.value = '';
                }

                // 保存资料
                async function saveProfile() {
                    if (savingProfile.value) return;

                    // 验证密码修改
                    if (editForm.new_password) {
                        if (!editForm.old_password) {
                            showToast('请输入旧密码');
                            return;
                        }
                        if (editForm.new_password.length < 6) {
                            showToast('新密码长度不能少于6位');
                            return;
                        }
                        if (editForm.new_password !== editForm.confirm_password) {
                            showToast('两次输入的新密码不一致');
                            return;
                        }
                    }

                    savingProfile.value = true;
                    try {
                        const data = {
                            nickname: editForm.nickname,
                            avatar: editForm.avatar
                        };
                        if (editForm.new_password) {
                            data.old_password = editForm.old_password;
                            data.new_password = editForm.new_password;
                        }

                        const res = await api('update_profile', data);
                        if (res.code === 1) {
                            showToast('保存成功');
                            // 更新本地用户信息
                            if (editForm.nickname) currentUser.nickname = editForm.nickname;
                            if (editForm.avatar) currentUser.avatar = editForm.avatar;
                            showEditProfile.value = false;
                        } else {
                            showToast(res.msg || '保存失败');
                        }
                    } finally {
                        savingProfile.value = false;
                    }
                }

                // 打开实名认证
                function openVerifyPopup() {
                    verifyForm.real_name = '';
                    verifyForm.id_card = '';
                    showVerifyPopup.value = true;
                }

                function closeVerifyPopup() {
                    showVerifyPopup.value = false;
                }

                // 提交实名认证
                async function submitVerify() {
                    if (verifying.value) return;
                    if (currentUser.is_verified) {
                        closeVerifyPopup();
                        return;
                    }

                    if (!verifyForm.real_name.trim()) {
                        showToast('请输入真实姓名');
                        return;
                    }
                    if (!verifyForm.id_card.trim()) {
                        showToast('请输入身份证号');
                        return;
                    }
                    // 简单校验
                    if (!/^[1-9]\d{5}(18|19|20)\d{2}(0[1-9]|1[0-2])(0[1-9]|[12]\d|3[01])\d{3}[\dXx]$/.test(verifyForm.id_card)) {
                        showToast('身份证号格式不正确');
                        return;
                    }

                    verifying.value = true;
                    try {
                        const res = await api('verify_identity', {
                            real_name: verifyForm.real_name.trim(),
                            id_card: verifyForm.id_card.trim().toUpperCase()
                        });
                        if (res.code === 1) {
                            showToast('实名认证成功');
                            // 刷新用户信息
                            await checkLoginStatus();
                            showVerifyPopup.value = false;
                        } else {
                            showToast(res.msg || '认证失败');
                        }
                    } finally {
                        verifying.value = false;
                    }
                }

                // 打开管理后台
                async function openAdminPanel() {
                    if (currentUser.role != 1) {
                        showToast('无权限访问');
                        return;
                    }
                    showAdminPanel.value = true;
                    adminUserList.value = [];
                    adminPage.value = 1;
                    adminHasMore.value = true;
                    adminSearchKw.value = '';
                    expandedMenuId.value = null;
                    await loadAdminStats();
                    await loadAdminUsers();
                }

                function closeAdminPanel() {
                    showAdminPanel.value = false;
                }

                // 用户详情
                async function openUserDetail(userId) {
                    expandedMenuId.value = null;
                    userDetailLoading.value = true;
                    showUserDetail.value = true;
                    userDetailData.value = null;
                    try {
                        const res = await api('admin_user_detail&user_id=' + userId);
                        if (res.code === 1) {
                            userDetailData.value = res.data;
                        } else {
                            showToast(res.msg || '加载失败');
                        }
                    } catch (e) {
                        showToast('网络错误');
                    } finally {
                        userDetailLoading.value = false;
                    }
                }

                function closeUserDetail() {
                    showUserDetail.value = false;
                }

                // 加载统计数据
                async function loadAdminStats() {
                    const res = await api('admin_stats');
                    if (res.code === 1 && res.data) {
                        Object.assign(adminStats, res.data);
                    } else if (res.code === 403) {
                        showToast('无权限访问');
                        closeAdminPanel();
                    }
                }

                // 加载用户列表
                async function loadAdminUsers(isMore = false) {
                    if (adminLoading.value) return;
                    adminLoading.value = true;
                    try {
                        const params = new URLSearchParams({
                            action: 'admin_user_list',
                            page: adminPage.value.toString(),
                            keyword: adminSearchKw.value
                        });
                        const res = await fetch('api.php?' + params.toString(), {
                            method: 'GET',
                            headers: { 'Content-Type': 'application/json' }
                        });
                        const result = await res.json();
                        if (result.code === 1 && result.data) {
                            const list = result.data.list || [];
                            if (isMore) {
                                adminUserList.value.push(...list);
                            } else {
                                adminUserList.value = list;
                            }
                            adminHasMore.value = adminPage.value < result.data.total_pages;
                        } else if (result.code === 403) {
                            showToast('无权限访问');
                            closeAdminPanel();
                        }
                    } catch (e) {
                        showToast('网络错误');
                    } finally {
                        adminLoading.value = false;
                    }
                }

                // 搜索用户
                function searchAdminUsers() {
                    adminUserList.value = [];
                    adminPage.value = 1;
                    adminHasMore.value = true;
                    loadAdminUsers();
                }

                // 加载更多
                function loadMoreAdminUsers() {
                    if (adminHasMore.value && !adminLoading.value) {
                        adminPage.value++;
                        loadAdminUsers(true);
                    }
                }

                // 禁用/启用用户
                async function adminToggleUser(user) {
                    if (!confirm(`确定要${user.status == 1 ? '禁用' : '启用'}该用户吗？`)) return;
                    expandedMenuId.value = null;
                    const res = await api('admin_toggle_user', { user_id: user.id });
                    if (res.code === 1) {
                        showToast(res.msg);
                        user.status = user.status == 1 ? 0 : 1;
                        loadAdminStats();
                    } else {
                        showToast(res.msg || '操作失败');
                    }
                }

                // 重置密码
                async function adminResetPwd(user) {
                    const newPwd = prompt('请输入新密码（默认123456）：', '123456');
                    if (newPwd === null) return;
                    if (newPwd.length < 6) {
                        showToast('密码长度不能少于6位');
                        return;
                    }
                    expandedMenuId.value = null;
                    const res = await api('admin_reset_password', { user_id: user.id, new_password: newPwd });
                    if (res.code === 1) {
                        showToast(res.msg);
                    } else {
                        showToast(res.msg || '操作失败');
                    }
                }

                // 设置/取消管理员
                async function adminSetRole(user, role) {
                    const actionText = role == 1 ? '设为管理员' : '取消管理员';
                    if (!confirm(`确定要${actionText}吗？`)) return;
                    expandedMenuId.value = null;
                    const res = await api('admin_set_role', { user_id: user.id, role: role });
                    if (res.code === 1) {
                        showToast(res.msg);
                        user.role = role;
                    } else {
                        showToast(res.msg || '操作失败');
                    }
                }

                // 切换下拉菜单
                function toggleAdminMenu(userId) {
                    expandedMenuId.value = expandedMenuId.value === userId ? null : userId;
                }

                // 点击外部关闭菜单（监听document点击）
                function closeAdminMenu() {
                    expandedMenuId.value = null;
                }

                // 删除用户
                async function adminDeleteUser(user) {
                    if (!confirm(`确定要删除用户「${user.nickname}」吗？\n\n将删除该用户的所有数据：\n- 账号信息和头像\n- 所有聊天记录和媒体文件\n- 好友关系\n\n此操作不可恢复！`)) return;
                    expandedMenuId.value = null;
                    const res = await api('admin_delete_user', { user_id: user.id });
                    if (res.code === 1) {
                        showToast(res.msg);
                        // 从列表中移除
                        const idx = adminUserList.value.findIndex(u => u.id === user.id);
                        if (idx > -1) adminUserList.value.splice(idx, 1);
                        loadAdminStats();
                    } else {
                        showToast(res.msg || '删除失败');
                    }
                }

                // 信息页面
                function openInfoPage(type) {
                    infoPageType.value = type;
                    showInfoPage.value = true;
                }
                function closeInfoPage() {
                    showInfoPage.value = false;
                }

                // ===== 设置页面（隐私设置） =====
                async function openSettingsPanel() {
                    // 从服务器加载最新设置
                    try {
                        const res = await api('get_privacy_settings');
                        if (res.code === 1 && res.data.settings) {
                            Object.assign(privacySettings, res.data.settings);
                        }
                    } catch (e) {}
                    showSettingsPanel.value = true;
                }

                function closeSettingsPanel() {
                    showSettingsPanel.value = false;
                }

                async function savePrivacySettings() {
                    savingPrivacy.value = true;
                    try {
                        const res = await api('update_privacy_settings', {
                            moment_visible: privacySettings.moment_visible,
                            allow_search: privacySettings.allow_search,
                            allow_add_friend: privacySettings.allow_add_friend,
                            show_moment_in_discover: privacySettings.show_moment_in_discover
                        });
                        if (res.code === 1) {
                            showToast('设置已保存');
                            // 同步到 currentUser
                            currentUser.moment_visible = privacySettings.moment_visible;
                            currentUser.allow_search = privacySettings.allow_search;
                            currentUser.allow_add_friend = privacySettings.allow_add_friend;
                            currentUser.show_moment_in_discover = privacySettings.show_moment_in_discover;
                        } else {
                            showToast(res.msg || '保存失败');
                        }
                    } catch (e) {
                        showToast('网络错误');
                    } finally {
                        savingPrivacy.value = false;
                    }
                }

                // ===== 初始化路由 =====
                function initRoute() {
                    const hash = location.hash.replace('#/', '') || 'login';
                    const parts = hash.split('/');
                    const route = parts[0];
                    
                    const authRoutes = ['login', 'register', 'forgot'];
                    const mainRoutes = ['home', 'chats', 'contacts', 'discover', 'profile'];
                    
                    if (isLoggedIn.value) {
                        if (authRoutes.includes(route)) {
                            currentRoute.value = 'home';
                            activeTab.value = 'chats';
                        } else if (route === 'chat' && parts[1]) {
                            const friendId = parseInt(parts[1]);
                            // 防止重复打开同一聊天（避免hashchange导致的递归调用）
                            if (!(currentRoute.value === 'chat' && currentFriend.id === friendId)) {
                                openChat(friendId);
                            }
                        } else if (mainRoutes.includes(route)) {
                            currentRoute.value = 'home';
                            const tab = route === 'home' ? 'chats' : route;
                            activeTab.value = tab;
                            switchTab(tab);
                        } else {
                            currentRoute.value = 'home';
                            activeTab.value = 'chats';
                        }
                    } else {
                        if (mainRoutes.includes(route) || route === 'chat') {
                            currentRoute.value = 'login';
                        } else {
                            currentRoute.value = authRoutes.includes(route) ? route : 'login';
                        }
                    }
                }

                onMounted(async () => {
                    // 固定视口高度，防止移动端键盘弹出推挤页面
                    const setVh = () => {
                        const vh = window.innerHeight * 0.01;
                        document.documentElement.style.setProperty('--vh', vh + 'px');
                    };
                    setVh();
                    window.addEventListener('resize', setVh);
                    window.addEventListener('orientationchange', setVh);
                    
                    const logged = await checkLoginStatus();
                    loading.value = false;
                    initRoute();
                    if (logged) {
                        loadChatList();
                        loadFriendList();
                        loadMomentList();
                        startPolling();
                    }
                    
                    window.addEventListener('hashchange', initRoute);
                    // 页面可见性变化时控制轮询
                    document.addEventListener('visibilitychange', () => {
                        if (document.visibilityState === 'visible' && isLoggedIn.value) {
                            loadFriendRequests();
                        }
                    });
                });

                return {
                    loading, isLoggedIn, currentRoute, activeTab, toast,
                    currentUser,
                    loginForm, logining, doLogin,
                    registerForm, registering, pwdLevel, doRegister, checkPwdStrength,
                    forgotStep, forgotForm, sendingCode, reseting, sendResetCode, resetPassword,
                    navigate, goBack, switchTab, headerTitle,
                    chatList, totalUnread, totalUnreadMsg, loadChatList,
                    friendList, searchKeyword, filteredFriends,
                    showAddFriend, addFriendKeyword, addFriendResults, searchAddFriend, doAddFriend,
                    showFriendRequests, friendRequests, friendRequestCount, handleRequest, deleteFriend,
                    messages, currentFriend, msgInput, msgContainer, msgInputEl, openChat, sendMessage,
                    imageInput, videoInput, uploading, triggerFileInput, handleFileUpload, previewImage, handleImgError,
                    discoverList, showSettings,
                    // 朋友圈
                    momentList, momentLoading, showPublishPanel, publishing, momentForm,
                    loadMomentList, formatMomentTime, closePublishPanel,
                    handleMomentImageUpload, removeMomentImage, publishMoment,
                    toggleMomentLike, toggleCommentBox, submitComment, deleteMoment,
                    showEditProfile, savingProfile, editForm, avatarInput,
                    editProfile, closeEditProfile, triggerAvatarUpload, handleAvatarUpload, saveProfile,
                    showVerifyPopup, verifying, verifyForm, openVerifyPopup, closeVerifyPopup, submitVerify,
                    showAdminPanel, adminStats, adminUserList, adminSearchKw, adminHasMore, adminLoading, expandedMenuId,
                    openAdminPanel, closeAdminPanel, searchAdminUsers, loadMoreAdminUsers,
                    adminToggleUser, adminResetPwd, adminSetRole, adminDeleteUser, toggleAdminMenu, closeAdminMenu,
                    showUserDetail, userDetailLoading, userDetailData, openUserDetail, closeUserDetail,
                    showInfoPage, infoPageType, infoPageTitle, openInfoPage, closeInfoPage,
                    // 设置页面
                    showSettingsPanel, savingPrivacy, privacySettings,
                    openSettingsPanel, closeSettingsPanel, savePrivacySettings,
                    formatTime, doLogout,
                    showToast
                };
            }
        });

        app.mount('#app');
    </script>
</body>
</html>
