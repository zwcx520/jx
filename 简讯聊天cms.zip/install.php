<?php
// 简讯 安装程序
mysqli_report(MYSQLI_REPORT_OFF);
$step = isset($_GET['step']) ? (int)$_GET['step'] : 1;
$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $db_host = $_POST['db_host'] ?? 'localhost';
    $db_user = $_POST['db_user'] ?? 'root';
    $db_pass = $_POST['db_pass'] ?? '';
    $db_name = $_POST['db_name'] ?? 'jianxun_app';
    
    // 测试数据库连接
    $conn = @new mysqli($db_host, $db_user, $db_pass);
    if ($conn->connect_error) {
        $error = '数据库连接失败：' . $conn->connect_error;
    } else {
        // 创建数据库
        $conn->query("CREATE DATABASE IF NOT EXISTS `{$db_name}` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
        $conn->select_db($db_name);
        
        // 创建数据表
        $sql = "
        -- 用户表
        CREATE TABLE IF NOT EXISTS `users` (
            `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            `username` VARCHAR(50) NOT NULL UNIQUE,
            `nickname` VARCHAR(50) NOT NULL,
            `email` VARCHAR(100) NOT NULL UNIQUE,
            `password` VARCHAR(255) NOT NULL,
            `avatar` VARCHAR(255) DEFAULT '',
            `signature` VARCHAR(200) DEFAULT '',
            `real_name` VARCHAR(50) DEFAULT '' COMMENT '真实姓名',
            `id_card` VARCHAR(18) DEFAULT '' COMMENT '身份证号',
            `is_verified` TINYINT DEFAULT 0 COMMENT '是否实名认证 0否 1是',
            `role` TINYINT DEFAULT 0 COMMENT '用户角色 0普通用户 1管理员',
            `moment_visible` TINYINT DEFAULT 1 COMMENT '朋友圈权限 0所有人 1仅好友 2仅自己',
            `allow_search` TINYINT DEFAULT 1 COMMENT '是否允许被搜索 0否 1是',
            `allow_add_friend` TINYINT DEFAULT 1 COMMENT '是否允许被添加好友 0否 1是',
            `show_moment_in_discover` TINYINT DEFAULT 1 COMMENT '是否在发现页展示朋友圈 0否 1是',
            `status` TINYINT DEFAULT 1 COMMENT '1正常 0禁用',
            `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
            `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

        -- 好友关系表
        CREATE TABLE IF NOT EXISTS `friends` (
            `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            `user_id` INT UNSIGNED NOT NULL,
            `friend_id` INT UNSIGNED NOT NULL,
            `remark` VARCHAR(50) DEFAULT '',
            `status` TINYINT DEFAULT 0 COMMENT '0待验证 1已添加 2拒绝',
            `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
            UNIQUE KEY `unique_friend` (`user_id`, `friend_id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

        -- 消息表
        CREATE TABLE IF NOT EXISTS `messages` (
            `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            `from_user_id` INT UNSIGNED NOT NULL,
            `to_user_id` INT UNSIGNED NOT NULL,
            `content` TEXT NOT NULL COMMENT '文本内容或文件路径',
            `type` TINYINT DEFAULT 1 COMMENT '1文本 2图片 3视频',
            `file_name` VARCHAR(255) DEFAULT NULL COMMENT '原始文件名',
            `file_size` BIGINT DEFAULT 0 COMMENT '文件大小(字节)',
            `is_read` TINYINT DEFAULT 0 COMMENT '0未读 1已读',
            `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
            INDEX `idx_from_to` (`from_user_id`, `to_user_id`),
            INDEX `idx_to_from` (`to_user_id`, `from_user_id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

        -- 密码重置表
        CREATE TABLE IF NOT EXISTS `password_resets` (
            `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            `email` VARCHAR(100) NOT NULL,
            `token` VARCHAR(100) NOT NULL,
            `expires_at` DATETIME NOT NULL,
            `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        ";
        
        // 执行SQL
        if ($conn->multi_query($sql)) {
            do {
                $conn->store_result();
            } while ($conn->more_results() && $conn->next_result());
            
            // 创建管理员账号
            $admin_username = $_POST['admin_username'] ?? 'admin';
            $admin_password = $_POST['admin_password'] ?? '123456';
            $admin_email = $_POST['admin_email'] ?? 'admin@jianxun.com';
            $hashed_password = password_hash($admin_password, PASSWORD_DEFAULT);
            
            $stmt = $conn->prepare("INSERT IGNORE INTO users (username, nickname, email, password, avatar, role) VALUES (?, ?, ?, ?, ?, 1)");
            $default_avatar = 'assets/img/default-avatar.svg'; // 已本地化（原 dicebear 外链）
            $admin_nick = '管理员';
            $stmt->bind_param("sssss", $admin_username, $admin_nick, $admin_email, $hashed_password, $default_avatar);
            $stmt->execute();
            $stmt->close();
            
            // 写入配置文件
            $config_content = "<?php
define('DB_HOST', '{$db_host}');
define('DB_USER', '{$db_user}');
define('DB_PASS', '{$db_pass}');
define('DB_NAME', '{$db_name}');
define('SITE_NAME', '简讯');
define('SITE_DESC', '甜美的即时通讯应用');

function db_connect() {
    \$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    if (\$conn->connect_error) {
        die(\"数据库连接失败: \" . \$conn->connect_error);
    }
    \$conn->set_charset(\"utf8mb4\");
    return \$conn;
}

function is_installed() {
    return true;
}

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

function is_logged_in() {
    return isset(\$_SESSION['user_id']);
}

function current_user() {
    if (!is_logged_in()) return null;
    \$conn = db_connect();
    \$stmt = \$conn->prepare(\"SELECT id, username, nickname, avatar, email, signature, created_at FROM users WHERE id = ?\");
    \$stmt->bind_param(\"i\", \$_SESSION['user_id']);
    \$stmt->execute();
    \$result = \$stmt->get_result();
    \$user = \$result->fetch_assoc();
    \$stmt->close();
    \$conn->close();
    return \$user;
}

function e(\$str) {
    return htmlspecialchars(\$str, ENT_QUOTES, 'UTF-8');
}

function csrf_token() {
    if (empty(\$_SESSION['csrf_token'])) {
        \$_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return \$_SESSION['csrf_token'];
}

function verify_csrf(\$token) {
    return isset(\$_SESSION['csrf_token']) && hash_equals(\$_SESSION['csrf_token'], \$token);
}
?>";
            
            file_put_contents(__DIR__ . '/config.php', $config_content);
            $success = '安装成功！';
            $step = 3;
        } else {
            $error = '创建数据表失败：' . $conn->error;
        }
        $conn->close();
    }
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>安装 - 简讯</title>
    <!-- Vant UI（原 CDN: https://unpkg.com/vant@4/lib/index.css，已本地化） -->
    <link rel="stylesheet" href="assets/css/vant.css">
    <!-- Remix Icon（原 CDN: https://cdn.jsdelivr.net/npm/remixicon@3.5.0/fonts/remixicon.css，已本地化） -->
    <link href="assets/css/remixicon.css" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'PingFang SC', 'Hiragino Sans GB', 'Microsoft YaHei', sans-serif;
            background: #FDB59F;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        .install-box {
            width: 100%;
            max-width: 420px;
            background: transparent;
            backdrop-filter: none;
            border-radius: 0;
            padding: 0;
            box-shadow: none;
        }
        .logo {
            text-align: center;
            margin-bottom: 30px;
        }
        .logo i {
            font-size: 64px;
            color: #fff;
        }
        .logo h1 {
            font-size: 28px;
            margin-top: 10px;
            color: #fff;
            text-shadow: 0 2px 10px rgba(255,107,157,0.3);
        }
        .logo p {
            color: rgba(255,255,255,0.8);
            font-size: 14px;
            margin-top: 5px;
        }
        .steps {
            display: flex;
            justify-content: center;
            margin-bottom: 30px;
            gap: 10px;
        }
        .step-dot {
            width: 30px;
            height: 30px;
            border-radius: 50%;
            background: rgba(255,255,255,0.3);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 14px;
            font-weight: bold;
            color: rgba(255,255,255,0.7);
            transition: all 0.3s;
        }
        .step-dot.active {
            background: #fff;
            color: #ff6b9d;
            box-shadow: 0 4px 15px rgba(255,255,255,0.4);
        }
        .step-line {
            width: 40px;
            height: 2px;
            background: rgba(255,255,255,0.3);
            align-self: center;
        }
        .step-line.active {
            background: #fff;
        }
        .form-group {
            margin-bottom: 0;
            padding: 12px 0;
            border-bottom: 1px solid rgba(255,255,255,0.3);
        }
        .form-group label {
            display: block;
            font-size: 13px;
            color: rgba(255,255,255,0.8);
            margin-bottom: 6px;
            font-weight: 500;
        }
        .form-group input {
            width: 100%;
            height: 36px;
            padding: 0;
            border: none;
            border-radius: 0;
            font-size: 15px;
            transition: all 0.3s;
            outline: none;
            background: transparent;
            color: #fff;
        }
        .form-group input:focus {
            box-shadow: none;
        }
        .form-group input::placeholder {
            color: rgba(255,255,255,0.6);
        }
        .btn-install {
            width: 100%;
            height: 48px;
            background: rgba(255,255,255,0.25);
            color: #fff;
            border: 1px solid rgba(255,255,255,0.4);
            border-radius: 24px;
            font-size: 15px;
            font-weight: 500;
            cursor: pointer;
            margin-top: 25px;
            transition: all 0.3s;
            backdrop-filter: blur(10px);
        }
        .btn-install i {
            font-size: 16px;
            margin-right: 4px;
            vertical-align: -2px;
        }
        .btn-install:hover {
            background: rgba(255,255,255,0.35);
        }
        .btn-install:active {
            transform: scale(0.98);
        }
        .error {
            background: rgba(255,71,87,0.2);
            color: #fff;
            padding: 12px 16px;
            border-radius: 12px;
            font-size: 14px;
            margin-bottom: 20px;
            border-left: 4px solid #ff4757;
            backdrop-filter: blur(10px);
        }
        .success-box {
            text-align: center;
            padding: 20px 0;
        }
        .success-box i {
            font-size: 56px;
            color: #fff;
            text-shadow: 0 2px 15px rgba(46,213,115,0.4);
        }
        .success-box h2 {
            color: #fff;
            margin: 15px 0 10px;
        }
        .success-box p {
            color: rgba(255,255,255,0.8);
            margin-bottom: 25px;
        }
        .info-card {
            background: rgba(255,255,255,0.15);
            border-radius: 14px;
            padding: 16px;
            margin-bottom: 20px;
            backdrop-filter: blur(10px);
        }
        .info-card h4 {
            color: #fff;
            margin-bottom: 10px;
            font-size: 15px;
        }
        .info-card ul {
            list-style: none;
            padding: 0;
        }
        .info-card li {
            color: rgba(255,255,255,0.85);
            font-size: 13px;
            padding: 4px 0;
            display: flex;
            align-items: center;
        }
        .info-card li i {
            color: #fff;
            margin-right: 8px;
        }
        .section-title {
            font-size: 16px;
            font-weight: 600;
            color: #fff;
            margin-bottom: 15px;
            margin-top: 25px;
            padding-bottom: 10px;
            border-bottom: 1px solid rgba(255,255,255,0.3);
        }
    </style>
</head>
<body>
    <div class="install-box">
        <div class="logo">
            <i class="ri-chat-heart-fill"></i>
            <h1>简讯</h1>
            <p>甜美的即时通讯应用 · 安装向导</p>
        </div>
        
        <div class="steps">
            <div class="step-dot <?php echo $step >= 1 ? 'active' : ''; ?>">1</div>
            <div class="step-line <?php echo $step >= 2 ? 'active' : ''; ?>"></div>
            <div class="step-dot <?php echo $step >= 2 ? 'active' : ''; ?>">2</div>
            <div class="step-line <?php echo $step >= 3 ? 'active' : ''; ?>"></div>
            <div class="step-dot <?php echo $step >= 3 ? 'active' : ''; ?>">3</div>
        </div>

        <?php if ($error): ?>
            <div class="error"><i class="ri-error-warning-line"></i> <?php echo $error; ?></div>
        <?php endif; ?>

        <?php if ($step == 1): ?>
            <div class="section-title">环境检测</div>
            <div class="info-card">
                <h4><i class="ri-checkbox-circle-fill" style="color:#2ed573"></i> 系统要求</h4>
                <ul>
                    <li><i class="ri-check-line"></i> PHP 8.0+ 版本</li>
                    <li><i class="ri-check-line"></i> MySQL 5.7+ 数据库</li>
                    <li><i class="ri-check-line"></i> mysqli 扩展支持</li>
                    <li><i class="ri-check-line"></i> PDO 扩展支持</li>
                </ul>
            </div>
            <div class="info-card">
                <h4><i class="ri-information-line" style="color:#ff6b9d"></i> 当前环境</h4>
                <ul>
                    <li><i class="ri-check-line"></i> PHP 版本：<?php echo phpversion(); ?></li>
                    <li><i class="ri-check-line"></i> mysqli 扩展：<?php echo extension_loaded('mysqli') ? '已安装' : '未安装'; ?></li>
                </ul>
            </div>
            <button class="btn-install" onclick="location.href='?step=2'">下一步：配置数据库</button>
        
        <?php elseif ($step == 2): ?>
            <form method="POST" action="?step=2">
                <div class="section-title">数据库配置</div>
                <div class="form-group">
                    <label>数据库地址</label>
                    <input type="text" name="db_host" value="localhost" required>
                </div>
                <div class="form-group">
                    <label>数据库用户名</label>
                    <input type="text" name="db_user" value="root" required>
                </div>
                <div class="form-group">
                    <label>数据库密码</label>
                    <input type="password" name="db_pass" value="">
                </div>
                <div class="form-group">
                    <label>数据库名称</label>
                    <input type="text" name="db_name" value="jianxun_app" required>
                </div>
                
                <div class="section-title" style="margin-top:25px">管理员账号</div>
                <div class="form-group">
                    <label>管理员用户名</label>
                    <input type="text" name="admin_username" value="admin" required>
                </div>
                <div class="form-group">
                    <label>管理员密码</label>
                    <input type="text" name="admin_password" value="123456" required>
                </div>
                <div class="form-group">
                    <label>管理员邮箱</label>
                    <input type="email" name="admin_email" value="admin@jianxun.com" required>
                </div>
                
                <button type="submit" class="btn-install">
                    <i class="ri-install-fill"></i> 开始安装
                </button>
            </form>
        
        <?php elseif ($step == 3): ?>
            <div class="success-box">
                <i class="ri-checkbox-circle-fill"></i>
                <h2>安装成功！</h2>
                <p>恭喜你，简讯已成功安装完成</p>
                <div class="info-card" style="text-align:left">
                    <h4>默认管理员账号</h4>
                    <ul>
                        <li><i class="ri-user-line"></i> 用户名：admin</li>
                        <li><i class="ri-lock-line"></i> 密码：123456</li>
                    </ul>
                </div>
                <button class="btn-install" onclick="location.href='index.php#/login'">
                    <i class="ri-login-box-line"></i> 立即登录
                </button>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>
