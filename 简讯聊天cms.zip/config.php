<?php
// 简讯APP 配置文件
// 关闭mysqli异常模式，兼容PHP 8+
mysqli_report(MYSQLI_REPORT_OFF);

define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'jianxun_app');
define('SITE_NAME', '简讯APP');
define('SITE_DESC', '甜美的即时通讯应用');

// 上传配置
define('UPLOAD_DIR', __DIR__ . '/uploads');
define('UPLOAD_URL', 'uploads');
define('MAX_UPLOAD_SIZE', 1000 * 1024 * 1024); // 1000MB
define('ALLOWED_IMAGE_TYPES', ['jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp']);
define('ALLOWED_VIDEO_TYPES', ['mp4', 'webm', 'mov', 'avi', 'mkv', 'flv']);

// 连接数据库
function db_connect() {
    $conn = @new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    if ($conn->connect_error) {
        die("数据库连接失败: " . $conn->connect_error);
    }
    $conn->set_charset("utf8mb4");
    return $conn;
}

// 检查是否已安装（使用try-catch兼容PHP 8+异常模式）
function is_installed() {
    try {
        $conn = @new mysqli(DB_HOST, DB_USER, DB_PASS);
        if ($conn->connect_error) return false;
        $result = $conn->query("SELECT SCHEMA_NAME FROM INFORMATION_SCHEMA.SCHEMATA WHERE SCHEMA_NAME = '".DB_NAME."'");
        $exists = $result && $result->num_rows > 0;
        $conn->close();
        return $exists;
    } catch (Exception $e) {
        return false;
    }
}

// 启动会话
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// 数据库自动升级（检查并添加缺失的字段）
function db_upgrade() {
    if (!is_installed()) return;
    try {
        $conn = db_connect();
    } catch (Exception $e) {
        return;
    }

    // 每个操作独立 try-catch，避免一个失败导致后续全部跳过

    // 检查 messages 表是否有 file_name 字段
    try {
        $result = $conn->query("SHOW COLUMNS FROM messages LIKE 'file_name'");
        if (!$result || $result->num_rows == 0) {
            $conn->query("ALTER TABLE messages ADD COLUMN file_name VARCHAR(255) DEFAULT NULL COMMENT '原始文件名' AFTER type");
        }
    } catch (Exception $e) {}

    // 检查 messages 表是否有 file_size 字段
    try {
        $result = $conn->query("SHOW COLUMNS FROM messages LIKE 'file_size'");
        if (!$result || $result->num_rows == 0) {
            $conn->query("ALTER TABLE messages ADD COLUMN file_size BIGINT DEFAULT 0 COMMENT '文件大小(字节)' AFTER file_name");
        }
    } catch (Exception $e) {}

    // 检查 users 表是否有 real_name 字段（实名认证）
    try {
        $result = $conn->query("SHOW COLUMNS FROM users LIKE 'real_name'");
        if (!$result || $result->num_rows == 0) {
            $conn->query("ALTER TABLE users ADD COLUMN real_name VARCHAR(50) DEFAULT '' COMMENT '真实姓名' AFTER signature");
        }
    } catch (Exception $e) {}

    // 检查 users 表是否有 id_card 字段
    try {
        $result = $conn->query("SHOW COLUMNS FROM users LIKE 'id_card'");
        if (!$result || $result->num_rows == 0) {
            $conn->query("ALTER TABLE users ADD COLUMN id_card VARCHAR(18) DEFAULT '' COMMENT '身份证号' AFTER real_name");
        }
    } catch (Exception $e) {}

    // 检查 users 表是否有 is_verified 字段
    try {
        $result = $conn->query("SHOW COLUMNS FROM users LIKE 'is_verified'");
        if (!$result || $result->num_rows == 0) {
            $conn->query("ALTER TABLE users ADD COLUMN is_verified TINYINT DEFAULT 0 COMMENT '是否实名认证 0否 1是' AFTER id_card");
        }
    } catch (Exception $e) {}

    // 检查 users 表是否有 role 字段（用户角色）
    try {
        $result = $conn->query("SHOW COLUMNS FROM users LIKE 'role'");
        if (!$result || $result->num_rows == 0) {
            $conn->query("ALTER TABLE users ADD COLUMN role TINYINT DEFAULT 0 COMMENT '用户角色 0普通用户 1管理员' AFTER is_verified");
            $conn->query("UPDATE users SET role = 1 WHERE username = 'admin' LIMIT 1");
        }
    } catch (Exception $e) {}

    // 隐私设置字段：moment_visible 朋友圈权限(0所有人可见 1仅好友可见 2仅自己可见)
    try {
        $result = $conn->query("SHOW COLUMNS FROM users LIKE 'moment_visible'");
        if (!$result || $result->num_rows == 0) {
            $conn->query("ALTER TABLE users ADD COLUMN moment_visible TINYINT DEFAULT 1 COMMENT '朋友圈权限 0所有人 1仅好友 2仅自己' AFTER role");
        }
    } catch (Exception $e) {}

    // 隐私设置字段：allow_search 是否允许被搜索(0不允许 1允许)
    try {
        $result = $conn->query("SHOW COLUMNS FROM users LIKE 'allow_search'");
        if (!$result || $result->num_rows == 0) {
            $conn->query("ALTER TABLE users ADD COLUMN allow_search TINYINT DEFAULT 1 COMMENT '是否允许被搜索 0否 1是' AFTER moment_visible");
        }
    } catch (Exception $e) {}

    // 隐私设置字段：allow_add_friend 是否允许被添加好友(0不允许 1允许)
    try {
        $result = $conn->query("SHOW COLUMNS FROM users LIKE 'allow_add_friend'");
        if (!$result || $result->num_rows == 0) {
            $conn->query("ALTER TABLE users ADD COLUMN allow_add_friend TINYINT DEFAULT 1 COMMENT '是否允许被添加好友 0否 1是' AFTER allow_search");
        }
    } catch (Exception $e) {}

    // 隐私设置字段：show_moment_in_discover 是否在发现页展示朋友圈(0不展示 1展示)
    try {
        $result = $conn->query("SHOW COLUMNS FROM users LIKE 'show_moment_in_discover'");
        if (!$result || $result->num_rows == 0) {
            $conn->query("ALTER TABLE users ADD COLUMN show_moment_in_discover TINYINT DEFAULT 1 COMMENT '是否在发现页展示朋友圈 0否 1是' AFTER allow_add_friend");
        }
    } catch (Exception $e) {}

    // 创建朋友圈表（如果不存在）
    try {
        $conn->query("CREATE TABLE IF NOT EXISTS moments (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL COMMENT '发布者ID',
            content TEXT COMMENT '文字内容',
            images TEXT COMMENT '图片URL，JSON数组',
            likes TEXT DEFAULT NULL COMMENT '点赞用户ID，逗号分隔',
            comments_count INT DEFAULT 0 COMMENT '评论数',
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '发布时间',
            INDEX idx_user (user_id),
            INDEX idx_created (created_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='朋友圈动态'");
    } catch (Exception $e) {}

    // 创建朋友圈评论表
    try {
        $conn->query("CREATE TABLE IF NOT EXISTS moment_comments (
            id INT AUTO_INCREMENT PRIMARY KEY,
            moment_id INT NOT NULL COMMENT '动态ID',
            user_id INT NOT NULL COMMENT '评论者ID',
            content TEXT NOT NULL COMMENT '评论内容',
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_moment (moment_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='朋友圈评论'");
    } catch (Exception $e) {}

    $conn->close();
}

// 确保朋友圈表存在（在API调用前安全调用）
function ensure_moments_tables() {
    try {
        $conn = db_connect();
        $conn->query("CREATE TABLE IF NOT EXISTS moments (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL COMMENT '发布者ID',
            content TEXT COMMENT '文字内容',
            images TEXT COMMENT '图片URL，JSON数组',
            likes TEXT DEFAULT NULL COMMENT '点赞用户ID，逗号分隔',
            comments_count INT DEFAULT 0 COMMENT '评论数',
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '发布时间',
            INDEX idx_user (user_id),
            INDEX idx_created (created_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='朋友圈动态'");
        $conn->query("CREATE TABLE IF NOT EXISTS moment_comments (
            id INT AUTO_INCREMENT PRIMARY KEY,
            moment_id INT NOT NULL COMMENT '动态ID',
            user_id INT NOT NULL COMMENT '评论者ID',
            content TEXT NOT NULL COMMENT '评论内容',
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_moment (moment_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='朋友圈评论'");
        $conn->close();
    } catch (Exception $e) {}
}
// 已安装则自动执行升级
if (is_installed()) {
    db_upgrade();
}

// 检查登录状态
function is_logged_in() {
    return isset($_SESSION['user_id']);
}

// 获取当前用户信息
function current_user() {
    if (!is_logged_in()) return null;
    try {
        $conn = db_connect();
        $stmt = $conn->prepare("SELECT id, username, nickname, avatar, email, signature, created_at FROM users WHERE id = ?");
        $stmt->bind_param("i", $_SESSION['user_id']);
        $stmt->execute();
        $result = $stmt->get_result();
        $user = $result->fetch_assoc();
        $stmt->close();
        $conn->close();
        return $user;
    } catch (Exception $e) {
        return null;
    }
}

// 安全输出
function e($str) {
    return htmlspecialchars($str, ENT_QUOTES, 'UTF-8');
}

// 生成CSRF令牌
function csrf_token() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

// 验证CSRF令牌
function verify_csrf($token) {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}
?>
